import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { u as useAuth } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { I as Input } from "./input-C0QjszdI.js";
import { u as useCities } from "./cities-JYrO-Wlx.js";
import { P as PlaceCard } from "./PlaceCard-DHyTulll.js";
import { Plus, Home } from "lucide-react";
import "sonner";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-slot";
import "class-variance-authority";
const PAGE_SIZE = 12;
function PlacesBrowse() {
  const {
    user
  } = useAuth();
  const {
    cities: dynamicCities
  } = useCities();
  const [city, setCity] = useState("");
  const [maxRent, setMaxRent] = useState("");
  const [minRent, setMinRent] = useState("");
  const [moveInBy, setMoveInBy] = useState("");
  const [roomType, setRoomType] = useState("");
  const [furnished, setFurnished] = useState(false);
  const [billsIncluded, setBillsIncluded] = useState(false);
  const [maxMinStay, setMaxMinStay] = useState("");
  const [page, setPage] = useState(0);
  const {
    data: meProfile
  } = useQuery({
    queryKey: ["me-intent", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("profiles").select("user_intent").eq("id", user.id).maybeSingle();
      return data;
    }
  });
  const canHost = meProfile?.user_intent === "has_place" || meProfile?.user_intent === "both";
  const {
    data: placesRaw,
    isLoading
  } = useQuery({
    queryKey: ["places", city, minRent, maxRent, moveInBy, roomType, furnished, billsIncluded, maxMinStay, page],
    queryFn: async () => {
      let q = supabase.from("places").select("id, title, city, neighborhood, rent_monthly, currency, photos, room_type, host_id").eq("status", "published").order("created_at", {
        ascending: false
      }).range(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE - 1);
      if (city) q = q.eq("city", city);
      if (minRent) q = q.gte("rent_monthly", parseInt(minRent, 10));
      if (maxRent) q = q.lte("rent_monthly", parseInt(maxRent, 10));
      if (moveInBy) q = q.lte("available_from", moveInBy);
      if (roomType) q = q.eq("room_type", roomType);
      if (furnished) q = q.eq("furnished", true);
      if (billsIncluded) q = q.eq("bills_included", true);
      if (maxMinStay) q = q.or(`min_stay_months.is.null,min_stay_months.lte.${parseInt(maxMinStay, 10)}`);
      const {
        data,
        error
      } = await q;
      if (error) throw error;
      return data;
    }
  });
  const {
    data: hostProfiles
  } = useQuery({
    queryKey: ["place-hosts", placesRaw?.map((p) => p.host_id).join(",")],
    enabled: !!placesRaw && placesRaw.length > 0,
    queryFn: async () => {
      const hostIds = [...new Set(placesRaw.map((p) => p.host_id))];
      const {
        data
      } = await supabase.from("profiles").select("id, review_status").in("id", hostIds);
      return data ?? [];
    }
  });
  const approvedHostIds = useMemo(() => {
    const set = /* @__PURE__ */ new Set();
    for (const h of hostProfiles ?? []) {
      if (!h.review_status || h.review_status === "approved") set.add(h.id);
    }
    return set;
  }, [hostProfiles]);
  const filteredPlaces = useMemo(() => {
    if (!placesRaw) return [];
    if (!hostProfiles) return placesRaw;
    return placesRaw.filter((p) => approvedHostIds.has(p.host_id));
  }, [placesRaw, hostProfiles, approvedHostIds]);
  const hasMore = useMemo(() => (placesRaw?.length ?? 0) === PAGE_SIZE, [placesRaw]);
  const resetPage = () => setPage(0);
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md space-y-4 p-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: "Rooms" }),
      canHost && /* @__PURE__ */ jsx(Button, { asChild: true, size: "sm", children: /* @__PURE__ */ jsxs(Link, { to: "/places/new", children: [
        /* @__PURE__ */ jsx(Plus, { className: "me-1 h-4 w-4" }),
        " List a room"
      ] }) })
    ] }),
    !canHost && /* @__PURE__ */ jsxs("p", { className: "text-xs text-foreground/80", children: [
      "Have a place to share?",
      " ",
      /* @__PURE__ */ jsx(Link, { to: "/profile", className: "underline", children: "Update your profile" }),
      " ",
      "to list a room."
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-2 rounded-lg border border-border bg-background/95 p-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxs("select", { value: city, onChange: (e) => {
          setCity(e.target.value);
          resetPage();
        }, className: "flex-1 rounded-md border border-input bg-background px-2 py-2 text-sm", children: [
          /* @__PURE__ */ jsx("option", { value: "", children: "All cities" }),
          dynamicCities.map((c) => /* @__PURE__ */ jsx("option", { value: c, children: c }, c))
        ] }),
        /* @__PURE__ */ jsxs("select", { value: roomType, onChange: (e) => {
          setRoomType(e.target.value);
          resetPage();
        }, className: "rounded-md border border-input bg-background px-2 py-2 text-sm", children: [
          /* @__PURE__ */ jsx("option", { value: "", children: "Any room" }),
          /* @__PURE__ */ jsx("option", { value: "private", children: "Private" }),
          /* @__PURE__ */ jsx("option", { value: "shared", children: "Shared" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsx(Input, { type: "number", inputMode: "numeric", placeholder: "Min", value: minRent, onChange: (e) => {
          setMinRent(e.target.value);
          resetPage();
        }, className: "w-20" }),
        /* @__PURE__ */ jsx(Input, { type: "number", inputMode: "numeric", placeholder: "Max", value: maxRent, onChange: (e) => {
          setMaxRent(e.target.value);
          resetPage();
        }, className: "w-20" }),
        /* @__PURE__ */ jsx(Input, { type: "number", inputMode: "numeric", placeholder: "Max min-stay (mo)", value: maxMinStay, onChange: (e) => {
          setMaxMinStay(e.target.value);
          resetPage();
        }, className: "flex-1" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx("label", { className: "text-xs text-foreground/80", children: "Move in by" }),
        /* @__PURE__ */ jsx(Input, { type: "date", value: moveInBy, onChange: (e) => {
          setMoveInBy(e.target.value);
          resetPage();
        }, className: "flex-1" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-4 text-xs text-foreground/80", children: [
        /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsx("input", { type: "checkbox", checked: furnished, onChange: (e) => {
            setFurnished(e.target.checked);
            resetPage();
          } }),
          "Furnished"
        ] }),
        /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsx("input", { type: "checkbox", checked: billsIncluded, onChange: (e) => {
            setBillsIncluded(e.target.checked);
            resetPage();
          } }),
          "Bills included"
        ] })
      ] })
    ] }),
    isLoading ? /* @__PURE__ */ jsx("p", { className: "py-8 text-center text-sm text-muted-foreground", children: "Loading…" }) : (filteredPlaces?.length ?? 0) === 0 ? /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-dashed border-border bg-background/90 p-8 text-center", children: [
      /* @__PURE__ */ jsx(Home, { className: "mx-auto h-10 w-10 text-foreground/70" }),
      /* @__PURE__ */ jsx("p", { className: "mt-3 text-sm text-foreground/80", children: "No rooms match your filters yet." })
    ] }) : /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 gap-3", children: filteredPlaces.map((p) => /* @__PURE__ */ jsx(PlaceCard, { place: p }, p.id)) }),
    /* @__PURE__ */ jsxs("div", { className: "flex justify-between pt-2", children: [
      /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", disabled: page === 0, onClick: () => setPage((p) => Math.max(0, p - 1)), children: "Previous" }),
      /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", disabled: !hasMore, onClick: () => setPage((p) => p + 1), children: "Next" })
    ] })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(PlacesBrowse, {}) }) });
export {
  SplitComponent as component
};
