import { jsx, jsxs } from "react/jsx-runtime";
import { useNavigate } from "@tanstack/react-router";
import { C as Card } from "./card-RGlIzTYo.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { Users, MapPin, Wallet, ShieldAlert, Flag, ArrowLeft, Phone } from "lucide-react";
import { d as useT } from "./router-Ds3vjgN6.js";
import "react";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@tanstack/react-query";
import "./client-BAiQKvvS.js";
import "@supabase/supabase-js";
import "sonner";
import "@lovable.dev/email-js";
function SafetyPage() {
  const t = useT();
  const nav = useNavigate();
  const tips = [{
    icon: Users,
    title: t("safety.meet.title"),
    body: t("safety.meet.body")
  }, {
    icon: MapPin,
    title: t("safety.share.title"),
    body: t("safety.share.body")
  }, {
    icon: Wallet,
    title: t("safety.money.title"),
    body: t("safety.money.body")
  }, {
    icon: ShieldAlert,
    title: t("safety.samsar.title"),
    body: t("safety.samsar.body")
  }, {
    icon: Flag,
    title: t("safety.report.title"),
    body: t("safety.report.body")
  }];
  return /* @__PURE__ */ jsx("div", { className: "min-h-screen bg-background", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-2xl space-y-4 p-4 sm:p-6", children: [
    /* @__PURE__ */ jsxs(Button, { variant: "ghost", size: "sm", className: "-ms-2", onClick: () => history.length > 1 ? history.back() : nav({
      to: "/"
    }), children: [
      /* @__PURE__ */ jsx(ArrowLeft, { className: "me-1 h-4 w-4" }),
      " ",
      t("safety.back")
    ] }),
    /* @__PURE__ */ jsxs("header", { className: "space-y-2", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-3xl font-bold tracking-tight text-foreground", children: t("safety.title") }),
      /* @__PURE__ */ jsx("p", { className: "text-muted-foreground", children: t("safety.intro") })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "space-y-3", children: tips.map((tip, i) => {
      const Icon = tip.icon;
      return /* @__PURE__ */ jsxs(Card, { className: "flex gap-3 p-4", children: [
        /* @__PURE__ */ jsx("div", { className: "mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground", children: /* @__PURE__ */ jsx(Icon, { className: "h-4 w-4" }) }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsx("h2", { className: "text-base font-semibold text-foreground", children: tip.title }),
          /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted-foreground", children: tip.body })
        ] })
      ] }, i);
    }) }),
    /* @__PURE__ */ jsxs(Card, { className: "space-y-2 border-primary/30 bg-primary/5 p-4", children: [
      /* @__PURE__ */ jsxs("h2", { className: "flex items-center gap-2 text-base font-semibold text-foreground", children: [
        /* @__PURE__ */ jsx(Phone, { className: "h-4 w-4 text-primary" }),
        " ",
        t("safety.emergency.title")
      ] }),
      /* @__PURE__ */ jsxs("ul", { className: "space-y-1 text-sm text-foreground", children: [
        /* @__PURE__ */ jsx("li", { children: t("safety.emergency.police") }),
        /* @__PURE__ */ jsx("li", { children: t("safety.emergency.gendarmerie") }),
        /* @__PURE__ */ jsx("li", { children: t("safety.emergency.samu") })
      ] })
    ] })
  ] }) });
}
export {
  SafetyPage as component
};
