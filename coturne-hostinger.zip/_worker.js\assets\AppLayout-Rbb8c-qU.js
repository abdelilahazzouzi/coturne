import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { useNavigate, useLocation, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { u as useAuth, d as useT, L as LanguageSwitcher } from "./router-Ds3vjgN6.js";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { s as supabase } from "./client-BAiQKvvS.js";
import { Heart, LogOut, Sparkles, Home, MessageCircle, User } from "lucide-react";
import { c as cn } from "./utils-H80jjgLf.js";
function RequireAuth({ children, requireOnboarded = true }) {
  const { user, loading } = useAuth();
  const nav = useNavigate();
  const [checkingAal, setCheckingAal] = useState(true);
  const { data: profile, isLoading: pLoading } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
      if (error) throw error;
      return data;
    }
  });
  useEffect(() => {
    if (loading) return;
    if (!user) {
      setCheckingAal(false);
      nav({ to: "/login" });
      return;
    }
    supabase.auth.mfa.getAuthenticatorAssuranceLevel().then(({ data }) => {
      if (data?.nextLevel === "aal2" && data?.currentLevel === "aal1") {
        nav({ to: "/login" });
      } else {
        setCheckingAal(false);
        if (profile?.review_status === "pending_minor_review") {
          if (window.location.pathname !== "/pending-review") {
            nav({ to: "/pending-review" });
          }
        } else if (requireOnboarded && (!profile || !profile.onboarded)) {
          if (window.location.pathname !== "/onboarding") {
            nav({ to: "/onboarding" });
          }
        }
      }
    });
  }, [user, loading, profile, requireOnboarded, nav]);
  if (loading || user && pLoading || checkingAal) {
    return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center", children: /* @__PURE__ */ jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" }) });
  }
  if (!user) return null;
  if (requireOnboarded && (!profile || !profile.onboarded)) return null;
  return /* @__PURE__ */ jsx(Fragment, { children });
}
function AppLayout({ children }) {
  const loc = useLocation();
  const nav = useNavigate();
  const { signOut, user } = useAuth();
  const t = useT();
  const qc = useQueryClient();
  const { data: unreadTotal = 0 } = useQuery({
    queryKey: ["unread-total", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data: convos } = await supabase.from("conversations").select("id").or(`user_a.eq.${user.id},user_b.eq.${user.id}`);
      const ids = (convos ?? []).map((c) => c.id);
      if (ids.length === 0) return 0;
      const { count } = await supabase.from("messages").select("id", { count: "exact", head: true }).in("conversation_id", ids).is("read_at", null).neq("sender_id", user.id);
      return count ?? 0;
    }
  });
  useEffect(() => {
    if (!user) return;
    const channel = supabase.channel(`unread:${user.id}`).on(
      "postgres_changes",
      { event: "*", schema: "public", table: "messages" },
      () => qc.invalidateQueries({ queryKey: ["unread-total", user.id] })
    ).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, qc]);
  const tabs = [
    { to: "/discover", labelKey: "nav.discover", icon: Sparkles, badge: 0 },
    { to: "/places", labelKey: "nav.places", icon: Home, badge: 0 },
    { to: "/matches", labelKey: "nav.matches", icon: Heart, badge: 0 },
    { to: "/chats", labelKey: "nav.chats", icon: MessageCircle, badge: unreadTotal },
    { to: "/profile", labelKey: "nav.profile", icon: User, badge: 0 }
  ];
  return /* @__PURE__ */ jsxs("div", { className: "relative flex min-h-screen flex-col overflow-hidden", children: [
    /* @__PURE__ */ jsx(
      "div",
      {
        "aria-hidden": "true",
        className: "fixed inset-0 -z-10",
        style: {
          background: `linear-gradient(to bottom, color-mix(in oklab, var(--background) 12%, transparent), color-mix(in oklab, var(--background) 68%, transparent) 62%, var(--background))`
        }
      }
    ),
    /* @__PURE__ */ jsxs("header", { className: "sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background/70 px-4 py-3 backdrop-blur-md", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx("div", { className: "flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground", children: /* @__PURE__ */ jsx(Heart, { className: "h-4 w-4" }) }),
        /* @__PURE__ */ jsx(Link, { to: "/", className: "text-lg font-semibold tracking-tight", children: "Roomies" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx(LanguageSwitcher, {}),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: async () => {
              await signOut();
              nav({ to: "/login" });
            },
            className: "text-muted-foreground hover:text-foreground",
            "aria-label": t("common.signout"),
            children: /* @__PURE__ */ jsx(LogOut, { className: "h-5 w-5" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx("main", { className: "relative z-0 flex-1 pb-20", children }),
    /* @__PURE__ */ jsx("nav", { className: "fixed bottom-0 left-0 right-0 z-10 border-t border-border bg-background/88 backdrop-blur-md", children: /* @__PURE__ */ jsx("div", { className: "mx-auto flex max-w-md justify-around", children: tabs.map((tab) => {
      const active = loc.pathname === tab.to;
      const Icon = tab.icon;
      return /* @__PURE__ */ jsxs(
        Link,
        {
          to: tab.to,
          className: cn(
            "relative flex flex-1 flex-col items-center gap-1 py-3 text-xs transition-colors",
            active ? "text-primary" : "text-muted-foreground hover:text-foreground"
          ),
          children: [
            /* @__PURE__ */ jsxs("span", { className: "relative", children: [
              /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5" }),
              tab.badge > 0 && /* @__PURE__ */ jsx("span", { className: "absolute -right-2 -top-1.5 min-w-[1.1rem] rounded-full bg-primary px-1 text-[10px] font-semibold leading-[1.1rem] text-primary-foreground", children: tab.badge > 99 ? "99+" : tab.badge })
            ] }),
            t(tab.labelKey)
          ]
        },
        tab.to
      );
    }) }) })
  ] });
}
export {
  AppLayout as A,
  RequireAuth as R
};
