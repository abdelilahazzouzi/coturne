import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { u as useAuth } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { P as PlaceCard } from "./PlaceCard-DHyTulll.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { ArrowLeft } from "lucide-react";
import "react";
import "sonner";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-slot";
import "class-variance-authority";
function SavedPlaces() {
  const {
    user
  } = useAuth();
  const {
    data
  } = useQuery({
    queryKey: ["saved-places", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data: saves,
        error
      } = await supabase.from("place_saves").select("place_id, created_at").eq("user_id", user.id).order("created_at", {
        ascending: false
      });
      if (error) throw error;
      const ids = (saves ?? []).map((s) => s.place_id);
      if (ids.length === 0) return [];
      const {
        data: places
      } = await supabase.from("places").select("id, title, city, neighborhood, rent_monthly, currency, photos, room_type").in("id", ids).eq("status", "published");
      return places ?? [];
    }
  });
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md space-y-3 p-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", asChild: true, children: /* @__PURE__ */ jsx(Link, { to: "/profile", "aria-label": "Back", children: /* @__PURE__ */ jsx(ArrowLeft, { className: "h-5 w-5" }) }) }),
      /* @__PURE__ */ jsx("h1", { className: "text-xl font-semibold", children: "Saved places" })
    ] }),
    (data?.length ?? 0) === 0 ? /* @__PURE__ */ jsx("p", { className: "py-12 text-center text-sm text-muted-foreground", children: "No saved places yet. Tap the bookmark on a listing to save it." }) : /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 gap-3", children: data.map((p) => /* @__PURE__ */ jsx(PlaceCard, { place: p }, p.id)) })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(SavedPlaces, {}) }) });
export {
  SplitComponent as component
};
