import { c as createServerRpc } from "./createServerRpc-BoW7UWBc.js";
import { r as requireSupabaseAuth } from "./auth-middleware-d8RM-K96.js";
import { a as createServerFn } from "./server-qG6n3Utp.js";
import "@supabase/supabase-js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
async function assertAdmin(supabase, userId) {
  const {
    data,
    error
  } = await supabase.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
  if (error) throw new Response("Forbidden", {
    status: 403
  });
  if (!data) throw new Response("Forbidden", {
    status: 403
  });
}
const decideMinorReview_createServerFn_handler = createServerRpc({
  id: "49380aad1e4856f1443b65254d4c724c214218137546ce9ab1cadd1cfaf00e87",
  name: "decideMinorReview",
  filename: "src/lib/admin.functions.ts"
}, (opts) => decideMinorReview.__executeServer(opts));
const decideMinorReview = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => {
  if (!input || typeof input.id !== "string" || typeof input.approve !== "boolean") {
    throw new Response("Bad request", {
      status: 400
    });
  }
  return input;
}).handler(decideMinorReview_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  await assertAdmin(supabase, userId);
  const update = data.approve ? {
    review_status: "approved",
    onboarded: true
  } : {
    review_status: "rejected",
    onboarded: false
  };
  const {
    error
  } = await supabase.from("profiles").update(update).eq("id", data.id);
  if (error) {
    console.error("[decideMinorReview] DB error:", error);
    throw new Response("Update failed", {
      status: 400
    });
  }
  return {
    ok: true
  };
});
export {
  decideMinorReview_createServerFn_handler
};
