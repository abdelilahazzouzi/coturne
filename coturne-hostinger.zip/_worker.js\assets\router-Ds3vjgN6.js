import { QueryClientProvider, QueryClient } from "@tanstack/react-query";
import { createRootRouteWithContext, Outlet, HeadContent, Scripts, useRouter, Link, createFileRoute, lazyRouteComponent, createRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useEffect, createContext, useContext } from "react";
import { s as supabase } from "./client-BAiQKvvS.js";
import { Toaster as Toaster$1 } from "sonner";
import { sendLovableEmail } from "@lovable.dev/email-js";
import { createClient } from "@supabase/supabase-js";
const appCss = "/assets/styles-BSxJCyIM.css";
const Ctx = createContext({ user: null, session: null, loading: true, signOut: async () => {
} });
function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      setSession(s);
      if (event === "PASSWORD_RECOVERY") {
        window.location.href = "/reset-password";
      }
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    return () => sub.subscription.unsubscribe();
  }, []);
  return /* @__PURE__ */ jsx(
    Ctx.Provider,
    {
      value: {
        user: session?.user ?? null,
        session,
        loading,
        signOut: async () => {
          await supabase.auth.signOut();
        }
      },
      children
    }
  );
}
const useAuth = () => useContext(Ctx);
const Toaster = ({ ...props }) => {
  return /* @__PURE__ */ jsx(
    Toaster$1,
    {
      className: "toaster group",
      toastOptions: {
        classNames: {
          toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
        }
      },
      ...props
    }
  );
};
const dict = {
  // ── Brand / generic ──────────────────────────────────────────────────────
  "brand": { fr: "Roomies", ar: "Roomies" },
  "lang.fr": { fr: "Français", ar: "الفرنسية" },
  "lang.ar": { fr: "Arabe", ar: "العربية" },
  "lang.switch": { fr: "Langue", ar: "اللغة" },
  // Common actions
  "common.back": { fr: "Retour", ar: "رجوع" },
  "common.cancel": { fr: "Annuler", ar: "إلغاء" },
  "common.save": { fr: "Enregistrer", ar: "حفظ" },
  "common.saving": { fr: "Enregistrement…", ar: "جارٍ الحفظ…" },
  "common.saved": { fr: "Enregistré", ar: "تم الحفظ" },
  "common.loading": { fr: "Chargement…", ar: "جارٍ التحميل…" },
  "common.continue": { fr: "Continuer", ar: "متابعة" },
  "common.submit": { fr: "Envoyer", ar: "إرسال" },
  "common.next": { fr: "Suivant", ar: "التالي" },
  "common.previous": { fr: "Précédent", ar: "السابق" },
  "common.signout": { fr: "Déconnexion", ar: "تسجيل الخروج" },
  "common.signin": { fr: "Se connecter", ar: "تسجيل الدخول" },
  "common.signup": { fr: "S'inscrire", ar: "إنشاء حساب" },
  "common.email": { fr: "E-mail", ar: "البريد الإلكتروني" },
  "common.password": { fr: "Mot de passe", ar: "كلمة المرور" },
  "common.phone": { fr: "Téléphone", ar: "الهاتف" },
  "common.copy": { fr: "Copier", ar: "نسخ" },
  "common.copied": { fr: "{label} copié", ar: "تم نسخ {label}" },
  "common.copyFail": { fr: "Copie impossible", ar: "تعذّر النسخ" },
  "common.yes": { fr: "Oui", ar: "نعم" },
  "common.no": { fr: "Non", ar: "لا" },
  "common.any": { fr: "Indifférent", ar: "أيّ" },
  // Nav
  "nav.discover": { fr: "Découvrir", ar: "اكتشف" },
  "nav.places": { fr: "Logements", ar: "السكن" },
  "nav.matches": { fr: "Matchs", ar: "التطابقات" },
  "nav.chats": { fr: "Discussions", ar: "المحادثات" },
  "nav.profile": { fr: "Profil", ar: "الملف" },
  // ── 404 / Errors ─────────────────────────────────────────────────────────
  "404.title": { fr: "Page introuvable", ar: "الصفحة غير موجودة" },
  "404.desc": { fr: "La page que vous cherchez n'existe pas ou a été déplacée.", ar: "الصفحة التي تبحث عنها غير موجودة أو تم نقلها." },
  "404.home": { fr: "Retour à l'accueil", ar: "العودة إلى الرئيسية" },
  "err.title": { fr: "Cette page n'a pas pu se charger", ar: "تعذّر تحميل هذه الصفحة" },
  "err.desc": { fr: "Une erreur est survenue de notre côté. Vous pouvez réessayer ou revenir à l'accueil.", ar: "حدث خطأ من جهتنا. يمكنك إعادة المحاولة أو العودة إلى الرئيسية." },
  "err.retry": { fr: "Réessayer", ar: "إعادة المحاولة" },
  // ── Landing (index) ──────────────────────────────────────────────────────
  "landing.cta.signin": { fr: "Se connecter", ar: "تسجيل الدخول" },
  "landing.cta.start": { fr: "Commencer", ar: "ابدأ الآن" },
  "landing.badge": { fr: "Fait au Maroc, pour le Maroc", ar: "صُنع في المغرب، لأجل المغرب" },
  "landing.hero.h1.part1": { fr: "Zéro", ar: "بدون" },
  "landing.hero.h1.samsar": { fr: "samsar", ar: "سمسار" },
  "landing.hero.h1.part2": { fr: ". Zéro commission.", ar: "، بدون عمولة." },
  "landing.hero.h1.part3": { fr: "Juste des colocataires compatibles.", ar: "فقط شركاء سكن متوافقون." },
  "landing.hero.sub": { fr: "Fini les groupes Facebook interminables et les samsara qui demandent un mois de loyer pour une simple mise en relation. Roomies vous matche selon votre style de vie à Casablanca, Rabat, Marrakech et Tanger.", ar: "تهنا من كروبات فيسبوك اللي كتعيي والسماسرة اللي كايطلبو شهر ديال الكرا غير باش يلاقوك. Roomies كايقلب ليك على الكولاك اللي كايتفاهم معاك في كازا، الرباط، طنجة، ومراكش." },
  "landing.hero.cta.start": { fr: "Commencer gratuitement", ar: "ابدأ فابور" },
  "landing.hero.cta.have": { fr: "J'ai déjà un compte", ar: "لدي حساب بالفعل" },
  "landing.feature.nobroker": { fr: "Sans samsar", ar: "بدون سمسار" },
  "landing.feature.nobroker.desc": { fr: "Gratuit pour toujours. Personne ne vous prend un mois de loyer.", ar: "مجاني للأبد. لا أحد يقتطع كراء شهر منك." },
  "landing.feature.gender": { fr: "Même sexe par défaut", ar: "نفس الجنس افتراضياً" },
  "landing.feature.gender.desc": { fr: "Conçu comme une app de colocation, pas de rencontre.", ar: "مصمَّمة لشركاء السكن، وليست تطبيق مواعدة." },
  "landing.feature.score": { fr: "Un score, pas un feeling", ar: "نتيجة، لا انطباعات" },
  "landing.feature.score.desc": { fr: "Style de vie, budget et culture notés de 0 à 100 dès le départ.", ar: "نمط الحياة والميزانية والثقافة بدرجة من 0 إلى 100 منذ البداية." },
  "landing.why.kicker": { fr: "Pourquoi Roomies", ar: "لماذا Roomies" },
  "landing.why.body": { fr: "Un ami à Casablanca a passé des semaines à courir entre les groupes Facebook et les samsara qui voulaient un mois de loyer pour un simple contact. Roomies est l'outil qu'il aurait voulu : rapide, gratuit, basé sur la compatibilité — pas sur les commissions.", ar: "واحد صاحبي فكازا دوز أسابيع بين كروبات فيسبوك والسماسرة اللي كايطلبو شهر دالكرا غير باش يلاقوك. Roomies هو الحل اللي كان محتاج: سريع، فابور، ومبني على التوافق — ماشي على العمولات." },
  "landing.how.title": { fr: "Comment ça marche", ar: "كيف يعمل" },
  "landing.how.sub": { fr: "Du profil au bail en trois étapes simples.", ar: "من البروفايل للكونطرا ديال الكرا فثلاثة دالخطوات ساهلين." },
  "landing.step1.title": { fr: "Créez votre profil", ar: "قاد البروفايل ديالك" },
  "landing.step1.desc": { fr: "Partagez votre budget, votre ville, votre mode de vie et votre date d'emménagement pour qu'on sache ce que vous cherchez.", ar: "شارك الميزانية ديالك، مدينتك، واللايف ستايل ديالك باش نعرفو بالضبط علاش كتقلب." },
  "landing.step2.title": { fr: "Parcourez & matchez", ar: "قلب وماتشي" },
  "landing.step2.desc": { fr: "Faites défiler des colocataires compatibles dans votre zone. Nous les classons par affinité pour faire remonter les meilleurs.", ar: "شوف الكولاك اللي كايتفاهمو معاك فمنطقتك. كانرتبوهم على حساب التوافق باش يبانو ليك الأحسن فالأول." },
  "landing.step3.title": { fr: "Discutez & emménagez", ar: "هضرو وسكنو" },
  "landing.step3.desc": { fr: "En cas de match mutuel, démarrez la discussion. Vérifiez-vous, puis trouvez un logement ensemble.", ar: "ملي يكون إعجاب متبادل، بداو الهضرة. تعرفو على بعضياتكم، ومن بعد قلبو على سكن مجموعين." },
  "landing.features.title": { fr: "Conçu pour les colocataires", ar: "مصمَّم لشركاء السكن" },
  "landing.features.sub": { fr: "Pas de rencontre. Pas de location. Juste des gens qui cherchent une chambre et une bonne entente.", ar: "ليس مواعدة. ليس عقارات. فقط أشخاص يبحثون عن غرفة وتوافق جيد." },
  "landing.f.email": { fr: "E-mails vérifiés", ar: "بريد إلكتروني موثّق" },
  "landing.f.email.desc": { fr: "Chaque utilisateur vérifie son e-mail, donc les profils sont réels.", ar: "كل مستخدم يوثّق بريده الإلكتروني، فالملفات حقيقية." },
  "landing.f.smart": { fr: "Matching intelligent", ar: "تطابق ذكي" },
  "landing.f.smart.desc": { fr: "Notre score pondère le budget, la localisation et la compatibilité de mode de vie.", ar: "خوارزميتنا توازن بين الميزانية والموقع وأسلوب الحياة." },
  "landing.f.twoway": { fr: "Match à double sens", ar: "تطابق متبادل" },
  "landing.f.twoway.desc": { fr: "Connexion uniquement si les deux côtés sont intéressés. Pas de messages froids gênants.", ar: "اتصال فقط إذا أُعجب الطرفان. لا رسائل باردة محرجة." },
  "landing.f.city": { fr: "Par ville d'abord", ar: "حسب المدينة أولاً" },
  "landing.f.city.desc": { fr: "Les filtres commencent par votre ville pour ne voir que des gens avec qui vous pourriez vivre.", ar: "تبدأ الفلاتر بمدينتك لترى فقط من يمكن أن تسكن معه." },
  "landing.f.chat": { fr: "Chat intégré", ar: "محادثة داخل التطبيق" },
  "landing.f.chat.desc": { fr: "Échangez avec vos matchs sans donner votre numéro avant d'être prêt(e).", ar: "تواصل مع تطابقاتك دون مشاركة رقمك حتى تكون مستعداً." },
  "landing.f.profiles": { fr: "Profils détaillés", ar: "ملفات مفصّلة" },
  "landing.f.profiles.desc": { fr: "Voyez d'avance les préférences fumeur, le rythme de sommeil, le niveau social, etc.", ar: "اطّلع مسبقاً على عادات التدخين، النوم، التفاعل الاجتماعي وأكثر." },
  "landing.cta.title": { fr: "Prêt(e) à trouver votre colocataire ?", ar: "هل أنت مستعد للعثور على شريك سكنك؟" },
  "landing.cta.sub": { fr: "Rejoignez les milliers de personnes qui ont trouvé leur prochain colocataire sur Roomies. Moins d'une minute pour commencer.", ar: "انضم إلى آلاف الأشخاص الذين وجدوا شريك سكنهم على Roomies. أقل من دقيقة للبدء." },
  "landing.cta.create": { fr: "Créer un compte gratuit", ar: "أنشئ حساباً مجانياً" },
  "landing.footer.rights": { fr: "© {year} Roomies. Tous droits réservés.", ar: "© {year} Roomies. كل الحقوق محفوظة." },
  // ── Auth ─────────────────────────────────────────────────────────────────
  "auth.welcomeBack": { fr: "Bon retour", ar: "مرحباً بعودتك" },
  "auth.oneTap": { fr: "Un tap et c'est parti", ar: "نقرة واحدة وأنت في الداخل" },
  "auth.createTitle": { fr: "Créez votre compte", ar: "أنشئ حسابك" },
  "auth.oneTapMatch": { fr: "Un tap et vous matchez", ar: "نقرة واحدة وتبدأ التطابق" },
  "auth.google.signin": { fr: "Continuer avec Google", ar: "تابع بحساب Google" },
  "auth.google.signup": { fr: "S'inscrire avec Google", ar: "سجّل بحساب Google" },
  "auth.google.connecting": { fr: "Connexion…", ar: "جارٍ الاتصال…" },
  "auth.orEmail": { fr: "ou par e-mail", ar: "أو عبر البريد" },
  "auth.forgot": { fr: "Mot de passe oublié ?", ar: "نسيت كلمة المرور؟" },
  "auth.signinEmail": { fr: "Se connecter par e-mail", ar: "تسجيل الدخول بالبريد" },
  "auth.signingIn": { fr: "Connexion…", ar: "جارٍ تسجيل الدخول…" },
  "auth.firstName": { fr: "Prénom", ar: "الاسم" },
  "auth.creating": { fr: "Création…", ar: "جارٍ الإنشاء…" },
  "auth.createEmail": { fr: "Créer un compte par e-mail", ar: "إنشاء حساب بالبريد" },
  "auth.alreadyHave": { fr: "Vous avez déjà un compte ?", ar: "لديك حساب بالفعل؟" },
  "auth.newHere": { fr: "Nouveau ici ?", ar: "جديد هنا؟" },
  "auth.createAccount": { fr: "Créer un compte", ar: "إنشاء حساب" },
  "auth.createdToast": { fr: "Compte créé — bienvenue !", ar: "تم إنشاء الحساب — مرحباً بك!" },
  "auth.invalidCredentials": { fr: "E-mail ou mot de passe incorrect", ar: "البريد الإلكتروني أو كلمة المرور غير صحيحة" },
  "auth.passwordRequired": { fr: "Le mot de passe est requis", ar: "كلمة المرور مطلوبة" },
  "auth.emailInUse": { fr: "Cette adresse e-mail est déjà utilisée", ar: "هذا البريد الإلكتروني مستخدم بالفعل" },
  "fp.title": { fr: "Réinitialiser votre mot de passe", ar: "إعادة تعيين كلمة المرور" },
  "fp.sub": { fr: "Nous vous enverrons un lien sécurisé pour en définir un nouveau.", ar: "سنرسل لك رابطاً آمناً لتعيين كلمة مرور جديدة." },
  "fp.enterEmail": { fr: "Veuillez saisir votre e-mail", ar: "الرجاء إدخال بريدك الإلكتروني" },
  "fp.sent.success": { fr: "Vérifiez vos e-mails pour le lien de réinitialisation", ar: "تحقّق من بريدك الإلكتروني" },
  "fp.sent.line1": { fr: "Si un compte existe pour {email}, un lien est en route.", ar: "إن وُجد حساب مرتبط بـ {email}، فالرابط في طريقه إليك." },
  "fp.sent.line2": { fr: "Il peut mettre 1 à 5 minutes à arriver.", ar: "قد يستغرق وصوله من 1 إلى 5 دقائق." },
  "fp.sending": { fr: "Envoi…", ar: "جارٍ الإرسال…" },
  "fp.send": { fr: "Envoyer le lien", ar: "إرسال الرابط" },
  "fp.remember": { fr: "Vous vous en souvenez ?", ar: "تذكّرت كلمة المرور؟" },
  "fp.back": { fr: "Retour à la connexion", ar: "العودة لتسجيل الدخول" },
  "rp.title": { fr: "Définir un nouveau mot de passe", ar: "تعيين كلمة مرور جديدة" },
  "rp.verifying": { fr: "Vérification de votre lien…", ar: "جارٍ التحقّق من الرابط…" },
  "rp.invalid": { fr: "Ce lien est invalide ou expiré.", ar: "هذا الرابط غير صالح أو منتهي." },
  "rp.requestNew": { fr: "Demander un nouveau lien", ar: "طلب رابط جديد" },
  "rp.newPwd": { fr: "Nouveau mot de passe", ar: "كلمة المرور الجديدة" },
  "rp.confirmPwd": { fr: "Confirmer le mot de passe", ar: "تأكيد كلمة المرور" },
  "rp.tooShort": { fr: "Le mot de passe doit faire au moins 6 caractères", ar: "يجب أن تكون كلمة المرور 6 أحرف على الأقل" },
  "rp.mismatch": { fr: "Les mots de passe ne correspondent pas", ar: "كلمتا المرور غير متطابقتين" },
  "rp.updated": { fr: "Mot de passe mis à jour. Veuillez vous reconnecter.", ar: "تم تحديث كلمة المرور. الرجاء تسجيل الدخول." },
  "rp.update": { fr: "Mettre à jour le mot de passe", ar: "تحديث كلمة المرور" },
  // ── Verify phone ─────────────────────────────────────────────────────────
  "verify.intl": { fr: "Utilisez le format international, ex. +212612345678", ar: "استعمل التنسيق الدولي، مثال: +212612345678" },
  "verify.noSms": { fr: "Le SMS n'est pas encore configuré. Demandez à l'admin d'activer l'auth par téléphone.", ar: "خدمة الرسائل لم تُفعّل بعد. اطلب من المسؤول تفعيل المصادقة عبر الهاتف." },
  "verify.codeSent": { fr: "Code envoyé", ar: "تم إرسال الرمز" },
  "verify.verified": { fr: "Téléphone vérifié", ar: "تم توثيق الهاتف" },
  "verify.titleEnter": { fr: "Vérifiez votre numéro", ar: "وثّق رقم هاتفك" },
  "verify.titleCode": { fr: "Saisissez le code", ar: "أدخل الرمز" },
  "verify.subEnter": { fr: "Un petit pas pour que Roomies reste fiable.", ar: "خطوة صغيرة لتبقى Roomies آمنة وموثوقة." },
  "verify.subCode": { fr: "Nous avons envoyé un code à 6 chiffres au {phone}", ar: "أرسلنا رمزاً من 6 أرقام إلى {phone}" },
  "verify.phoneLabel": { fr: "Numéro de téléphone", ar: "رقم الهاتف" },
  "verify.sending": { fr: "Envoi…", ar: "جارٍ الإرسال…" },
  "verify.sendCode": { fr: "Envoyer le code", ar: "إرسال الرمز" },
  "verify.skip": { fr: "Plus tard", ar: "ليس الآن" },
  "verify.verifying": { fr: "Vérification…", ar: "جارٍ التحقّق…" },
  "verify.verify": { fr: "Vérifier", ar: "تحقّق" },
  "verify.useOther": { fr: "Utiliser un autre numéro", ar: "استخدام رقم آخر" },
  // ── Pending review ───────────────────────────────────────────────────────
  "pending.title": { fr: "Votre profil est en révision", ar: "ملفك قيد المراجعة" },
  "pending.body": { fr: "Comme vous avez moins de 18 ans, notre équipe vérifie manuellement votre profil avant qu'il soit visible. Vous recevrez un e-mail dès qu'il est approuvé. Merci pour votre patience.", ar: "بما أنك دون الثامنة عشرة، يراجع فريقنا ملفك يدوياً قبل نشره. ستصلك رسالة عند الموافقة. شكراً لصبرك." },
  "pending.home": { fr: "Retour à l'accueil", ar: "العودة للرئيسية" },
  // ── Onboarding ───────────────────────────────────────────────────────────
  "ob.step": { fr: "Étape {n} sur {total}", ar: "الخطوة {n} من {total}" },
  "ob.step.about": { fr: "À propos de vous", ar: "عنك" },
  "ob.step.where": { fr: "Lieu & budget", ar: "المكان والميزانية" },
  "ob.step.lifestyle": { fr: "Style de vie", ar: "نمط الحياة" },
  "ob.step.culture": { fr: "Compatibilité culturelle", ar: "التوافق الثقافي" },
  "ob.step.bio": { fr: "Bio & contact", ar: "النبذة والاتصال" },
  "ob.continueHint": { fr: "Veuillez remplir tous les champs de cette étape pour continuer.", ar: "يرجى ملء جميع الحقول للمتابعة." },
  "ob.finish": { fr: "Terminer", ar: "إنهاء" },
  "ob.savedSuccess": { fr: "Profil enregistré !", ar: "تم حفظ الملف!" },
  "ob.submittedReview": { fr: "Profil envoyé pour révision", ar: "تم إرسال الملف للمراجعة" },
  "ob.cannotSave": { fr: "Impossible d'enregistrer le profil", ar: "تعذّر حفظ الملف" },
  "ob.displayName": { fr: "Nom affiché", ar: "الاسم الظاهر" },
  "ob.age": { fr: "Âge", ar: "العمر" },
  "ob.gender": { fr: "Genre", ar: "الجنس" },
  "ob.gender.female": { fr: "Femme", ar: "أنثى" },
  "ob.gender.male": { fr: "Homme", ar: "ذكر" },
  "ob.gender.nonbinary": { fr: "Non-binaire", ar: "غير ثنائي" },
  "ob.gender.other": { fr: "Autre", ar: "آخر" },
  "ob.gender.note": { fr: "Roomies ne matche que des colocataires du même sexe. Les photos des femmes ne sont visibles que par d'autres femmes.", ar: "Roomies تربط فقط بين شركاء سكن من نفس الجنس. صور الإناث لا تظهر إلا للإناث." },
  "ob.occupation": { fr: "Profession", ar: "المهنة" },
  "ob.occupation.ph": { fr: "Étudiant, designer, infirmier…", ar: "طالب، مصمّم، ممرّض…" },
  "ob.city": { fr: "Ville", ar: "المدينة" },
  "ob.city.search": { fr: "Rechercher une ville…", ar: "ابحث عن مدينة…" },
  "ob.city.none": { fr: "Aucune ville trouvée.", ar: "لم نجد أي مدينة." },
  "ob.city.select": { fr: "Sélectionnez une ville…", ar: "اختر مدينة…" },
  "ob.budgetRange": { fr: "Fourchette de budget (par mois)", ar: "نطاق الميزانية (شهرياً)" },
  "ob.budget.from": { fr: "De", ar: "من" },
  "ob.budget.mo": { fr: "/mois", ar: "/شهر" },
  "ob.smoking": { fr: "Tabac", ar: "التدخين" },
  "ob.smoking.no": { fr: "Non", ar: "لا" },
  "ob.smoking.occasionally": { fr: "Occasionnellement", ar: "أحياناً" },
  "ob.smoking.yes": { fr: "Oui", ar: "نعم" },
  "ob.drinking": { fr: "Alcool", ar: "الكحول" },
  "ob.drinking.no": { fr: "Non", ar: "لا" },
  "ob.drinking.socially": { fr: "En société", ar: "اجتماعياً" },
  "ob.drinking.often": { fr: "Souvent", ar: "كثيراً" },
  "ob.sleep": { fr: "Rythme de sommeil", ar: "نمط النوم" },
  "ob.sleep.early": { fr: "Lève-tôt", ar: "مبكّر" },
  "ob.sleep.late": { fr: "Noctambule", ar: "متأخّر" },
  "ob.sleep.flexible": { fr: "Flexible", ar: "مرن" },
  "ob.social": { fr: "Vie sociale", ar: "الحياة الاجتماعية" },
  "ob.social.homebody": { fr: "Casanier", ar: "بيتوتي" },
  "ob.social.balanced": { fr: "Équilibré", ar: "متوازن" },
  "ob.social.social": { fr: "Très sociable", ar: "اجتماعي جداً" },
  "ob.pets": { fr: "Animaux", ar: "الحيوانات الأليفة" },
  "ob.pets.none": { fr: "Pas d'animal", ar: "بدون حيوان" },
  "ob.pets.have": { fr: "J'en ai un", ar: "لدي حيوان" },
  "ob.pets.ok_with": { fr: "OK avec les animaux", ar: "لا مانع لدي" },
  "ob.cleanliness": { fr: "Propreté ({v}/5)", ar: "النظافة ({v}/5)" },
  "ob.cultureNote": { fr: "Toutes optionnelles, mais y répondre nous aide à trouver quelqu'un avec qui vous vivrez bien.", ar: "كلها اختيارية، لكنها تساعدنا على إيجاد من يناسبك حقاً." },
  "ob.guests": { fr: "Invités à la maison", ar: "الضيوف في البيت" },
  "ob.alcoholHouse": { fr: "Alcool dans le logement", ar: "الكحول في البيت" },
  "ob.prayer": { fr: "Prière à la maison", ar: "الصلاة في البيت" },
  "ob.food": { fr: "Partage de nourriture", ar: "مشاركة الطعام" },
  "ob.languages": { fr: "Langues parlées", ar: "اللغات" },
  "ob.bio": { fr: "Bio", ar: "نبذة" },
  "ob.bio.ph": { fr: "Quelques phrases sur vous et ce que vous cherchez…", ar: "بعض الجمل عنك وعمّا تبحث…" },
  "ob.contactEmail": { fr: "E-mail de contact", ar: "بريد التواصل" },
  "ob.phone.opt": { fr: "Téléphone (optionnel)", ar: "الهاتف (اختياري)" },
  "ob.handle.opt": { fr: "Autre contact (optionnel)", ar: "وسيلة اتصال أخرى (اختياري)" },
  "ob.handle.ph": { fr: "@telegram, WhatsApp, Instagram…", ar: "@تيليغرام، واتساب، إنستغرام…" },
  "ob.shareContact": { fr: "Partager mes contacts avec mes matchs confirmés. Modifiable à tout moment.", ar: "شارك معلومات التواصل مع تطابقاتي المؤكدة. يمكن التغيير في أي وقت." },
  "ob.contactReq": { fr: "Au moins l'e-mail ou le téléphone est requis pour que vos matchs puissent vous joindre.", ar: "البريد أو الهاتف مطلوب على الأقل ليتمكّن تطابقاتك من التواصل معك." },
  "ob.select.ph": { fr: "Sélectionner…", ar: "اختر…" },
  // Guests / alcohol / prayer / food enum labels
  "opt.guests.rarely": { fr: "Rarement", ar: "نادراً" },
  "opt.guests.occasionally": { fr: "Occasionnellement", ar: "أحياناً" },
  "opt.guests.often": { fr: "Souvent", ar: "كثيراً" },
  "opt.alcohol.not_ok": { fr: "Pas OK", ar: "غير مقبول" },
  "opt.alcohol.discreet": { fr: "OK si discret", ar: "مقبول بتحفّظ" },
  "opt.alcohol.fine": { fr: "OK", ar: "لا بأس" },
  "opt.prayer.yes": { fr: "Oui, je prie à la maison", ar: "نعم، أصلّي في البيت" },
  "opt.prayer.no": { fr: "Je ne prie pas", ar: "لا أصلّي في البيت" },
  "opt.prayer.no_pref": { fr: "Sans préférence", ar: "بدون تفضيل" },
  "opt.food.share_all": { fr: "Tout partager", ar: "نتقاسم كل شيء" },
  "opt.food.share_some": { fr: "Partager une partie", ar: "نتقاسم بعض الأشياء" },
  "opt.food.separate": { fr: "Séparé", ar: "كل واحد لحاله" },
  // Tag labels rendered in profile/discover
  "tag.smoking.no": { fr: "Non-fumeur", ar: "غير مدخّن" },
  "tag.smoking.yes": { fr: "Fumeur", ar: "مدخّن" },
  "tag.smoking.occasionally": { fr: "Fume occasionnellement", ar: "يدخّن أحياناً" },
  "tag.drinking.no": { fr: "Pas d'alcool", ar: "بدون كحول" },
  "tag.drinking.often": { fr: "Boit souvent", ar: "يشرب كثيراً" },
  "tag.drinking.socially": { fr: "Boit en société", ar: "يشرب اجتماعياً" },
  "tag.sleep.early": { fr: "Lève-tôt", ar: "مبكّر" },
  "tag.sleep.late": { fr: "Noctambule", ar: "متأخّر" },
  "tag.sleep.flexible": { fr: "Sommeil flexible", ar: "نوم مرن" },
  "tag.social.homebody": { fr: "Casanier", ar: "بيتوتي" },
  "tag.social.social": { fr: "Très sociable", ar: "اجتماعي جداً" },
  "tag.social.balanced": { fr: "Équilibré", ar: "متوازن" },
  "tag.pets.have": { fr: "A un animal", ar: "لديه حيوان" },
  "tag.pets.ok_with": { fr: "OK avec les animaux", ar: "لا مانع من الحيوانات" },
  "tag.pets.none": { fr: "Pas d'animal", ar: "بدون حيوان" },
  "tag.cleanliness": { fr: "Propreté {v}/5", ar: "النظافة {v}/5" },
  "tag.guests": { fr: "Invités : {v}", ar: "الضيوف: {v}" },
  "tag.alcohol": { fr: "Alcool : {v}", ar: "الكحول: {v}" },
  "tag.prayer.yes": { fr: "Prie à la maison", ar: "يصلّي في البيت" },
  "tag.prayer.no": { fr: "Ne prie pas à la maison", ar: "لا يصلّي في البيت" },
  "tag.prayer.no_pref": { fr: "Prière : sans préférence", ar: "الصلاة: بدون تفضيل" },
  "tag.food": { fr: "Nourriture : {v}", ar: "الطعام: {v}" },
  "tag.languages": { fr: "Parle {v}", ar: "يتحدث {v}" },
  // ── Discover ─────────────────────────────────────────────────────────────
  "disc.title": { fr: "Découvrir", ar: "اكتشف" },
  "disc.filters": { fr: "Filtres", ar: "الفلاتر" },
  "disc.allCaught": { fr: "Vous avez tout vu", ar: "اطّلعت على الجميع" },
  "disc.allCaught.sub": { fr: "Aucun autre profil ne correspond à vos filtres pour le moment.", ar: "لا توجد ملفات أخرى مطابقة لفلاترك حالياً." },
  "disc.loosen": { fr: "Assouplir les filtres", ar: "خفّف الفلاتر" },
  "disc.match.toast": { fr: "C'est un match !", ar: "إنه تطابق!" },
  "disc.match.toast.sub": { fr: "Voyez votre onglet Matchs.", ar: "تحقّق من علامة التطابقات." },
  "disc.budget": { fr: "Budget (par mois)", ar: "الميزانية (شهرياً)" },
  "disc.ageMin": { fr: "Âge min.", ar: "الحد الأدنى للعمر" },
  "disc.ageMax": { fr: "Âge max.", ar: "الحد الأقصى للعمر" },
  "disc.sameGender": { fr: "Roomies ne montre que des colocataires du même sexe. Ce n'est pas une app de rencontre.", ar: "Roomies تعرض فقط شركاء سكن من نفس الجنس. هذه ليست تطبيق مواعدة." },
  "disc.chip.smoking": { fr: "Tabac", ar: "التدخين" },
  "disc.chip.pets": { fr: "Animaux", ar: "الحيوانات" },
  "disc.chip.sleep": { fr: "Sommeil", ar: "النوم" },
  "disc.chip.social": { fr: "Social", ar: "اجتماعي" },
  "disc.reset": { fr: "Réinitialiser", ar: "إعادة تعيين" },
  "disc.anyCity": { fr: "Toutes les villes", ar: "كل المدن" },
  "disc.maxDistance": { fr: "Distance maximum", ar: "المسافة القصوى" },
  "disc.match": { fr: "match", ar: "تطابق" },
  "disc.budgetLabel": { fr: "Budget :", ar: "الميزانية:" },
  "disc.viewFull": { fr: "Voir le profil complet", ar: "عرض الملف الكامل" },
  "disc.pass": { fr: "Passer", ar: "تجاهل" },
  "disc.like": { fr: "J'aime", ar: "إعجاب" },
  // ── Matches ──────────────────────────────────────────────────────────────
  "matches.title": { fr: "Vos matchs", ar: "تطابقاتك" },
  "matches.empty": { fr: "Aucun match pour l'instant", ar: "لا توجد تطابقات بعد" },
  "matches.empty.sub": { fr: "Continuez à swiper ! Dès qu'une personne que vous avez aimée vous aime aussi, elle apparaîtra ici.", ar: "تابع التصفّح! عند تبادل الإعجاب، يظهر الشخص هنا." },
  "matches.message": { fr: "Envoyer un message à {name}", ar: "أرسل رسالة إلى {name}" },
  // ── Chats list ───────────────────────────────────────────────────────────
  "chats.title": { fr: "Discussions", ar: "المحادثات" },
  "chats.empty": { fr: "Aucune discussion pour l'instant", ar: "لا توجد محادثات بعد" },
  "chats.empty.sub": { fr: "Quand vous matchez avec quelqu'un, vous pouvez démarrer une conversation ici.", ar: "عند التطابق مع شخص، يمكنك بدء محادثة هنا." },
  "chats.noMessages": { fr: "Aucun message — dites bonjour !", ar: "لا توجد رسائل — قل مرحباً!" },
  // ── Chat ────────────────────────────────────────────────────────────────
  "chat.access": { fr: "Vous n'avez pas accès à cette conversation.", ar: "ليس لديك حق الوصول إلى هذه المحادثة." },
  "chat.sayHi": { fr: "Dites bonjour à {name} — brisez la glace !", ar: "قل مرحباً لـ{name} — اكسر الجمود!" },
  "chat.match": { fr: "votre match", ar: "تطابقك" },
  "chat.placeholder": { fr: "Écrire un message…", ar: "اكتب رسالة…" },
  "chat.share": { fr: "Partager un logement", ar: "شارك سكناً" },
  "chat.propose": { fr: "Proposer une visite", ar: "اقتراح زيارة" },
  // Share-place sheet
  "sps.title": { fr: "Partager un logement", ar: "شارك سكناً" },
  "sps.none": { fr: "Vous n'avez aucun logement publié.", ar: "ليس لديك أي سكن منشور." },
  "sps.list": { fr: "Publier un logement", ar: "أضف إعلان سكن" },
  // Propose-viewing sheet
  "pvs.title": { fr: "Proposer une visite", ar: "اقتراح زيارة" },
  "pvs.date": { fr: "Date", ar: "التاريخ" },
  "pvs.time": { fr: "Heure", ar: "الساعة" },
  "pvs.pickDate": { fr: "Choisir une date", ar: "اختر تاريخاً" },
  "pvs.send": { fr: "Envoyer la proposition", ar: "إرسال الاقتراح" },
  "pvs.failed": { fr: "Échec", ar: "فشل" },
  // Viewing bubble
  "vb.title": { fr: "Visite", ar: "زيارة" },
  "vb.status.accepted": { fr: "acceptée", ar: "مقبولة" },
  "vb.status.declined": { fr: "refusée", ar: "مرفوضة" },
  "vb.status.cancelled": { fr: "annulée", ar: "ملغاة" },
  "vb.status.proposed": { fr: "proposée", ar: "مقترحة" },
  "vb.cancel": { fr: "Annuler", ar: "إلغاء" },
  "vb.accept": { fr: "Accepter", ar: "قبول" },
  "vb.decline": { fr: "Refuser", ar: "رفض" },
  "vb.msg.proposed": { fr: "Visite proposée pour {when}", ar: "اقتُرحت زيارة بتاريخ {when}" },
  "vb.msg.accepted": { fr: "Visite acceptée pour {when}", ar: "قُبلت الزيارة بتاريخ {when}" },
  "vb.msg.declined": { fr: "Visite refusée pour {when}", ar: "رُفضت الزيارة بتاريخ {when}" },
  "vb.msg.cancelled": { fr: "Visite annulée pour {when}", ar: "ألغيت الزيارة بتاريخ {when}" },
  "prb.shared": { fr: "Logement partagé", ar: "تمت مشاركة سكن" },
  "prb.room": { fr: "Chambre", ar: "غرفة" },
  // ── Profile (self) ───────────────────────────────────────────────────────
  "profile.about": { fr: "À propos de vous", ar: "عنك" },
  "profile.name": { fr: "Nom affiché", ar: "الاسم الظاهر" },
  "profile.bio": { fr: "Bio", ar: "نبذة" },
  "profile.contactHandle": { fr: "Contact affiché aux matchs", ar: "وسيلة الاتصال للتطابقات" },
  "profile.contactHandle.ph": { fr: "@nom ou numéro WhatsApp", ar: "@المعرّف أو رقم واتساب" },
  "profile.saveChanges": { fr: "Enregistrer", ar: "حفظ التغييرات" },
  "profile.photoUpdated": { fr: "Photo mise à jour", ar: "تم تحديث الصورة" },
  "profile.privacy": { fr: "Confidentialité", ar: "الخصوصية" },
  "profile.showPhone": { fr: "Afficher mon numéro aux matchs", ar: "إظهار رقمي للتطابقات" },
  "profile.showPhone.on": { fr: "Une fois activé, vos matchs voient votre numéro vérifié.", ar: "عند التفعيل، يرى تطابقاتك رقمك الموثّق." },
  "profile.showPhone.verifyFirst": { fr: "Vérifiez d'abord votre téléphone pour activer cette option.", ar: "وثّق هاتفك أولاً لتفعيل هذا الخيار." },
  "profile.phoneVisible": { fr: "Téléphone visible aux matchs", ar: "الهاتف مرئي للتطابقات" },
  "profile.phoneHidden": { fr: "Téléphone masqué", ar: "الهاتف مخفي" },
  "profile.situation": { fr: "Votre situation", ar: "وضعيتك" },
  "profile.situation.sub": { fr: "Détermine si vous pouvez publier une chambre sur Logements.", ar: "يحدّد إن كنت تستطيع نشر غرفة في قسم السكن." },
  "profile.situation.searching": { fr: "Je cherche", ar: "أبحث" },
  "profile.situation.has": { fr: "J'ai un logement", ar: "لدي سكن" },
  "profile.situation.both": { fr: "Les deux", ar: "الاثنين" },
  "profile.myListings": { fr: "Mes annonces", ar: "إعلاناتي" },
  "profile.saved": { fr: "Enregistrés", ar: "المحفوظ" },
  "profile.preferences": { fr: "Préférences", ar: "التفضيلات" },
  "profile.editLifestyle": { fr: "Modifier mes préférences de vie", ar: "تعديل تفضيلات نمط الحياة" },
  "profile.verifyTrust": { fr: "Vérifiez votre téléphone pour gagner en confiance", ar: "وثّق هاتفك لتعزيز الثقة" },
  "profile.verifyTrust.sub": { fr: "Les profils vérifiés reçoivent plus de matchs.", ar: "الملفات الموثّقة تحصل على تطابقات أكثر." },
  "profile.verifyNow": { fr: "Vérifier maintenant", ar: "وثّق الآن" },
  "profile.notifications": { fr: "Notifications", ar: "الإشعارات" },
  "profile.matchEmail": { fr: "Nouveaux matchs", ar: "تطابقات جديدة" },
  "profile.matchEmail.desc": { fr: "Recevoir un e-mail quand vous faites un nouveau match.", ar: "تلقي بريد عند إجراء تطابق جديد." },
  "profile.messageEmail": { fr: "Nouveaux messages", ar: "رسائل جديدة" },
  "profile.messageEmail.desc": { fr: "Recevoir un e-mail quand vous avez un message non lu.", ar: "تلقي بريد عند وجود رسالة غير مقروءة." },
  "profile.mfa.title": { fr: "Authentification à deux facteurs (2FA)", ar: "المصادقة ثنائية العامل (2FA)" },
  "profile.mfa.enabled": { fr: "La 2FA est activée", ar: "تم تفعيل المصادقة ثنائية العامل" },
  "profile.mfa.disabled": { fr: "La 2FA est désactivée", ar: "تم تعطيل المصادقة ثنائية العامل" },
  "profile.mfa.desc": { fr: "Ajoutez une couche de sécurité supplémentaire à votre compte en exigeant un code de vérification.", ar: "أضف طبقة حماية إضافية لحسابك بطلب رمز تحقق عند تسجيل الدخول." },
  "profile.mfa.desc.enabled": { fr: "Votre compte est sécurisé avec une application d'authentification TOTP.", ar: "حسابك مؤمن بواسطة تطبيق مصادقة TOTP." },
  "profile.mfa.enroll": { fr: "Activer la 2FA", ar: "تفعيل المصادقة ثنائية العامل" },
  "profile.mfa.disable": { fr: "Désactiver", ar: "تعطيل" },
  "profile.mfa.scanHint": { fr: "Scannez le code QR avec votre application d'authentification ou saisissez la clé secrète manuellement.", ar: "امسح رمز QR باستخدام تطبيق المصادقة أو أدخل المفتاح السري يدويًا." },
  "profile.mfa.secret": { fr: "Clé secrète (saisie manuelle)", ar: "المفتاح السري (إدخال يدوي)" },
  "profile.mfa.code": { fr: "Code de vérification", ar: "رمز التحقق" },
  "profile.mfa.verify": { fr: "Vérifier", ar: "تحقق" },
  "profile.mfa.verifying": { fr: "Vérification…", ar: "جارٍ التحقق…" },
  // ── Profile detail (other) ───────────────────────────────────────────────
  "pd.notFound": { fr: "Profil introuvable.", ar: "الملف غير موجود." },
  "pd.welcome.title": { fr: "Votre profil est en ligne", ar: "ملفك مفعّل" },
  "pd.welcome.sub": { fr: "Voici ce que les autres verront. Prêt(e) à rencontrer des colocataires ?", ar: "هكذا سيراك الآخرون. هل أنت مستعد للقاء شركاء سكن؟" },
  "pd.welcome.start": { fr: "Commencer à découvrir", ar: "ابدأ الاكتشاف" },
  "pd.welcome.edit": { fr: "Modifier le profil", ar: "تعديل الملف" },
  "pd.viewing": { fr: "Profil de {name}", ar: "ملف {name}" },
  "pd.budget": { fr: "Budget :", ar: "الميزانية:" },
  "pd.compat.title": { fr: "Compatibilité avec vous", ar: "التوافق معك" },
  "pd.compat.sub": { fr: "Basée sur le style de vie, le budget et la compatibilité culturelle.", ar: "بناءً على نمط الحياة والميزانية والتوافق الثقافي." },
  "pd.matched": { fr: "Vous êtes en match !", ar: "أنتما متطابقان!" },
  "pd.message": { fr: "Message", ar: "مراسلة" },
  "pd.handle": { fr: "Contact", ar: "حساب" },
  "pd.noContactYet": { fr: "Ce match n'a pas encore partagé ses contacts — dites bonjour dans le chat !", ar: "هذا التطابق لم يشارك معلومات الاتصال بعد — قل مرحباً في المحادثة!" },
  "pd.privateContacts": { fr: "Cette personne a gardé ses contacts privés. Vous pouvez toujours lui écrire ici.", ar: "احتفظ هذا الشخص بمعلوماته خاصة. يمكنك مراسلته هنا." },
  "pd.report": { fr: "Signaler", ar: "إبلاغ" },
  "pd.block": { fr: "Bloquer", ar: "حظر" },
  "pd.blocked": { fr: "Utilisateur bloqué", ar: "تم حظر المستخدم" },
  "pd.report.title": { fr: "Signaler l'utilisateur", ar: "إبلاغ عن المستخدم" },
  "pd.report.reason.inappropriate": { fr: "Contenu inapproprié", ar: "محتوى غير لائق" },
  "pd.report.reason.fake": { fr: "Faux profil", ar: "ملف مزيّف" },
  "pd.report.reason.harassment": { fr: "Harcèlement", ar: "تحرّش" },
  "pd.report.reason.spam": { fr: "Spam", ar: "رسائل مزعجة" },
  "pd.report.reason.other": { fr: "Autre", ar: "آخر" },
  "pd.report.details.ph": { fr: "Ajouter des détails (optionnel)", ar: "أضف تفاصيل (اختياري)" },
  "pd.report.submit": { fr: "Envoyer", ar: "إرسال" },
  "pd.report.thanks": { fr: "Signalement envoyé. Merci d'aider à garder Roomies sûr.", ar: "تم إرسال البلاغ. شكراً لمساعدتك في الحفاظ على Roomies." },
  // ── My listings / saved ──────────────────────────────────────────────────
  "ml.title": { fr: "Mes annonces", ar: "إعلاناتي" },
  "ml.new": { fr: "Nouveau", ar: "جديد" },
  "ml.empty": { fr: "Vous n'avez encore publié aucune chambre.", ar: "لم تنشر أي غرفة بعد." },
  "ml.status.draft": { fr: "brouillon", ar: "مسوّدة" },
  "ml.status.published": { fr: "publié", ar: "منشور" },
  "ml.status.paused": { fr: "en pause", ar: "متوقّف" },
  "sv.title": { fr: "Logements enregistrés", ar: "السكن المحفوظ" },
  "sv.empty": { fr: "Aucun logement enregistré. Appuyez sur le marque-page d'une annonce pour la sauvegarder.", ar: "لا يوجد سكن محفوظ. اضغط على رمز الحفظ في الإعلان لحفظه." },
  // ── Places list ──────────────────────────────────────────────────────────
  "pl.title": { fr: "Chambres", ar: "الغرف" },
  "pl.list": { fr: "Publier une chambre", ar: "نشر غرفة" },
  "pl.canHostHint": { fr: "Vous avez un logement à partager ?", ar: "هل لديك سكن للمشاركة؟" },
  "pl.updateProfile": { fr: "Mettez à jour votre profil", ar: "حدّث ملفك" },
  "pl.toList": { fr: "pour publier une chambre.", ar: "لنشر غرفة." },
  "pl.allCities": { fr: "Toutes les villes", ar: "كل المدن" },
  "pl.anyRoom": { fr: "Tout type", ar: "أي نوع" },
  "pl.private": { fr: "Privée", ar: "خاصة" },
  "pl.shared": { fr: "Partagée", ar: "مشتركة" },
  "pl.min": { fr: "Min", ar: "الحد الأدنى" },
  "pl.max": { fr: "Max", ar: "الحد الأقصى" },
  "pl.maxStay": { fr: "Durée min. max (mois)", ar: "أقصى مدة دنيا (شهر)" },
  "pl.moveBy": { fr: "Emménagement avant le", ar: "السكن قبل" },
  "pl.furnished": { fr: "Meublé", ar: "مفروش" },
  "pl.bills": { fr: "Charges incluses", ar: "الفواتير مشمولة" },
  "pl.none": { fr: "Aucune chambre ne correspond à vos filtres.", ar: "لا توجد غرف تطابق فلاترك." },
  // Place card
  "pc.noPhoto": { fr: "Pas de photo", ar: "بدون صورة" },
  "pc.privateRoom": { fr: "Chambre privée", ar: "غرفة خاصة" },
  "pc.sharedRoom": { fr: "Chambre partagée", ar: "غرفة مشتركة" },
  // Place detail
  "pdt.notFound": { fr: "Annonce introuvable.", ar: "الإعلان غير موجود." },
  "pdt.backToRooms": { fr: "Retour aux chambres", ar: "العودة إلى الغرف" },
  "pdt.edit": { fr: "Modifier", ar: "تعديل" },
  "pdt.save": { fr: "Enregistrer", ar: "حفظ" },
  "pdt.saved": { fr: "Enregistré", ar: "محفوظ" },
  "pdt.perMo": { fr: "/mois", ar: "/شهر" },
  "pdt.privateRoom": { fr: "Chambre privée", ar: "غرفة خاصة" },
  "pdt.sharedRoom": { fr: "Chambre partagée", ar: "غرفة مشتركة" },
  "pdt.furnished": { fr: "Meublé", ar: "مفروش" },
  "pdt.bills": { fr: "Charges incluses", ar: "الفواتير مشمولة" },
  "pdt.minStay": { fr: "Min {n} mois", ar: "حد أدنى {n} شهر" },
  "pdt.availFrom": { fr: "Disponible à partir du {date}", ar: "متاح ابتداءً من {date}" },
  "pdt.about": { fr: "À propos de ce logement", ar: "عن هذا السكن" },
  "pdt.hostedBy": { fr: "Proposé par", ar: "صاحب الإعلان" },
  "pdt.messageHost": { fr: "Envoyer un message", ar: "أرسل رسالة" },
  "pdt.interestSent": { fr: "Intérêt envoyé ! Vous pourrez discuter dès qu'il/elle vous likera en retour.", ar: "تم إرسال اهتمامك! ستتمكن من المحادثة بمجرد رد الإعجاب." },
  // Place editor
  "pe.edit": { fr: "Modifier l'annonce", ar: "تعديل الإعلان" },
  "pe.new": { fr: "Publier une chambre", ar: "نشر غرفة" },
  "pe.photos": { fr: "Photos ({n}/6)", ar: "الصور ({n}/6)" },
  "pe.max6": { fr: "Maximum 6 photos", ar: "حد أقصى 6 صور" },
  "pe.title": { fr: "Titre", ar: "العنوان" },
  "pe.title.ph": { fr: "Chambre lumineuse au centre de Casablanca", ar: "غرفة مشرقة في وسط الدار البيضاء" },
  "pe.city": { fr: "Ville", ar: "المدينة" },
  "pe.neighborhood": { fr: "Quartier", ar: "الحي" },
  "pe.neighborhood.ph": { fr: "Maarif", ar: "المعاريف" },
  "pe.rent": { fr: "Loyer / mois", ar: "الكراء / شهر" },
  "pe.currency": { fr: "Devise", ar: "العملة" },
  "pe.availFrom": { fr: "Disponible à partir du", ar: "متاح ابتداءً من" },
  "pe.minStay": { fr: "Durée min. (mois)", ar: "المدة الدنيا (شهر)" },
  "pe.roomType": { fr: "Type de chambre", ar: "نوع الغرفة" },
  "pe.private": { fr: "Privée", ar: "خاصة" },
  "pe.shared": { fr: "Partagée", ar: "مشتركة" },
  "pe.furnished": { fr: "Meublé", ar: "مفروش" },
  "pe.bills": { fr: "Charges incluses", ar: "الفواتير مشمولة" },
  "pe.description": { fr: "Description", ar: "الوصف" },
  "pe.description.ph": { fr: "Parlez aux futurs colocataires du logement, de l'ambiance et de ce que vous cherchez.", ar: "تحدّث لشركاء السكن المحتملين عن المسكن والأجواء وما تبحث عنه." },
  "pe.required": { fr: "Le titre, la ville et le loyer sont obligatoires.", ar: "العنوان، المدينة والكراء مطلوبة." },
  "pe.saveDraft": { fr: "Enregistrer brouillon", ar: "حفظ كمسودة" },
  "pe.publish": { fr: "Publier", ar: "نشر" },
  "pe.savePublish": { fr: "Enregistrer & publier", ar: "حفظ ونشر" },
  "pe.published": { fr: "Publié !", ar: "تم النشر!" },
  "pe.draftSaved": { fr: "Enregistré en brouillon", ar: "تم الحفظ كمسودة" },
  "pe.remove": { fr: "Supprimer", ar: "حذف" },
  "pe.cannotPublish": { fr: "Votre profil doit être approuvé avant de publier une annonce.", ar: "يجب الموافقة على ملفك قبل نشر إعلان." },
  "pe.photosPremiumTitle": { fr: "Photos · Premium", ar: "الصور · مميّز" },
  "pe.photosPremiumBody": { fr: "L'ajout de photos arrive bientôt avec Roomies Premium. En attendant, votre annonce affichera un visuel propre par défaut.", ar: "إضافة الصور قادمة قريباً مع Roomies Premium. في انتظار ذلك، سيظهر إعلانك بتصميم افتراضي أنيق." },
  "pe.upgradePremium": { fr: "Bientôt disponible", ar: "قريباً" },
  "place.photosComingSoon": { fr: "Photos bientôt disponibles", ar: "الصور قريباً" },
  // ── Admin ────────────────────────────────────────────────────────────────
  "admin.checking": { fr: "Vérification…", ar: "جارٍ التحقّق…" },
  "admin.only": { fr: "Réservé aux admins", ar: "للمسؤولين فقط" },
  "admin.only.sub": { fr: "Vous n'avez pas accès à cette page.", ar: "ليس لديك صلاحية الوصول." },
  "admin.minor.title": { fr: "File de révision des mineurs", ar: "قائمة مراجعة القاصرين" },
  "admin.minor.sub": { fr: "Les profils des utilisateurs de moins de 18 ans sont retenus ici jusqu'à approbation ou refus.", ar: "تُحتجز ملفات من هم دون 18 سنة هنا حتى الموافقة أو الرفض." },
  "admin.minor.empty": { fr: "La file est vide.", ar: "القائمة فارغة." },
  "admin.noName": { fr: "(sans nom)", ar: "(بدون اسم)" },
  "admin.age": { fr: "Âge {n}", ar: "العمر {n}" },
  "admin.reject": { fr: "Refuser", ar: "رفض" },
  "admin.approve": { fr: "Approuver", ar: "قبول" },
  "admin.approved": { fr: "Profil approuvé", ar: "تمت الموافقة على الملف" },
  "admin.rejected": { fr: "Profil refusé", ar: "تم رفض الملف" },
  "admin.reports": { fr: "Signalements", ar: "البلاغات" },
  "admin.reports.empty": { fr: "Aucun signalement pour l'instant.", ar: "لا توجد بلاغات." },
  "admin.reportedBy": { fr: "a signalé", ar: "أبلغ عن" },
  // ── Chat misc ────────────────────────────────────────────────────────────
  "chat.back": { fr: "Retour", ar: "رجوع" },
  "chat.loading": { fr: "Chargement…", ar: "جارٍ التحميل…" },
  "chat.menu": { fr: "Options", ar: "خيارات" },
  "chat.safety": { fr: "Conseils de sécurité", ar: "نصائح السلامة" },
  "chat.unavailable": { fr: "Cet utilisateur n'est plus disponible.", ar: "هذا المستخدم لم يعد متاحاً." },
  // ── Safety page ──────────────────────────────────────────────────────────
  "safety.title": { fr: "Rester en sécurité sur Roomies", ar: "ابقَ آمناً على Roomies" },
  "safety.intro": { fr: "Roomies vous met en relation avec des inconnus. Suivez ces conseils simples avant chaque rencontre ou visite.", ar: "Roomies يربطك بأشخاص لا تعرفهم. اتبع هذه النصائح البسيطة قبل كل لقاء أو زيارة." },
  "safety.meet.title": { fr: "Rencontrez d'abord en public", ar: "التقِ أولاً في مكان عام" },
  "safety.meet.body": { fr: "Pour un premier contact, proposez un café ou un lieu animé. Ne montez dans aucun appartement seul(e) lors du tout premier rendez-vous.", ar: "للقاء الأول، اقترح مقهى أو مكاناً مزدحماً. لا تدخل أي شقة وحدك في الموعد الأول." },
  "safety.share.title": { fr: "Partagez votre position", ar: "شارك موقعك" },
  "safety.share.body": { fr: "Avant une visite, envoyez l'adresse et l'heure à un proche, et partagez votre position en direct via WhatsApp ou Google Maps.", ar: "قبل أي زيارة، أرسل العنوان والوقت لشخص تثق به، وشارك موقعك المباشر عبر واتساب أو خرائط جوجل." },
  "safety.money.title": { fr: "Ne payez jamais à l'avance", ar: "لا تدفع أبداً مقدماً" },
  "safety.money.body": { fr: "Aucun loyer, aucune caution, aucun « frais de réservation » avant d'avoir visité le logement et signé un contrat écrit. Aucune exception.", ar: "لا كراء ولا تأمين ولا «رسوم حجز» قبل زيارة السكن وتوقيع عقد مكتوب. بدون استثناء." },
  "safety.samsar.title": { fr: "Méfiez-vous des samsara", ar: "احذر السماسرة" },
  "safety.samsar.body": { fr: "Roomies est gratuit. Si quelqu'un demande une commission, un mois de loyer pour « vous présenter », ou des frais en cash, signalez-le immédiatement.", ar: "Roomies مجاني. إذا طلب أحد عمولة أو كراء شهر مقابل «التعريف» أو رسوماً نقدية، أبلغ عنه فوراً." },
  "safety.report.title": { fr: "Signalez & bloquez sans hésiter", ar: "أبلغ واحظر دون تردد" },
  "safety.report.body": { fr: "Comportement déplacé, demande d'argent, photo trompeuse ? Utilisez les boutons Signaler et Bloquer sur le profil. Notre équipe vérifie chaque signalement.", ar: "سلوك مزعج، طلب مال، صورة مضلّلة؟ استخدم زرّي «إبلاغ» و«حظر» في الملف. فريقنا يراجع كل بلاغ." },
  "safety.emergency.title": { fr: "Numéros d'urgence", ar: "أرقام الطوارئ" },
  "safety.emergency.police": { fr: "Police : 19", ar: "الشرطة: 19" },
  "safety.emergency.gendarmerie": { fr: "Gendarmerie : 177", ar: "الدرك: 177" },
  "safety.emergency.samu": { fr: "SAMU : 141", ar: "الإسعاف: 141" },
  "safety.back": { fr: "Retour", ar: "رجوع" },
  "landing.footer.safety": { fr: "Conseils de sécurité", ar: "نصائح السلامة" },
  "chat.safetyBanner.title": { fr: "Avant votre première rencontre", ar: "قبل لقائكما الأول" },
  "chat.safetyBanner.body": { fr: "Rencontrez-vous d'abord en public, partagez votre position avec un proche, et ne payez jamais avant d'avoir visité et signé.", ar: "التقيا أولاً في مكان عام، شارك موقعك مع شخص تثق به، ولا تدفع أبداً قبل الزيارة والتوقيع." },
  "chat.safetyBanner.cta": { fr: "Voir les conseils", ar: "عرض النصائح" },
  "chat.safetyBanner.dismiss": { fr: "J'ai compris", ar: "فهمت" }
};
const LocaleCtx = createContext(null);
function readInitial() {
  if (typeof window === "undefined") return "fr";
  try {
    const v = window.localStorage.getItem("locale");
    if (v === "ar" || v === "fr") return v;
  } catch {
  }
  if (typeof navigator !== "undefined") {
    const lang = (navigator.language || "").toLowerCase();
    if (lang.startsWith("ar")) return "ar";
  }
  return "fr";
}
function LocaleProvider({ children }) {
  const [locale, setLocaleState] = useState("fr");
  useEffect(() => {
    const initial = readInitial();
    setLocaleState(initial);
  }, []);
  useEffect(() => {
    if (typeof document === "undefined") return;
    document.documentElement.lang = locale;
    document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";
  }, [locale]);
  const setLocale = (l) => {
    setLocaleState(l);
    try {
      window.localStorage.setItem("locale", l);
    } catch {
    }
  };
  const t = (key, vars) => {
    const entry = dict[key];
    let s = entry ? entry[locale] : key;
    if (vars) {
      for (const [k, v] of Object.entries(vars)) {
        s = s.replace(new RegExp(`\\{${k}\\}`, "g"), String(v));
      }
    }
    return s;
  };
  return /* @__PURE__ */ jsx(LocaleCtx.Provider, { value: { locale, setLocale, t }, children });
}
function useLocale() {
  const ctx = useContext(LocaleCtx);
  if (!ctx) throw new Error("useLocale must be used inside LocaleProvider");
  return ctx;
}
function useT() {
  return useLocale().t;
}
function LanguageSwitcher() {
  const { locale, setLocale } = useLocale();
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center rounded-full border border-border bg-card p-0.5 text-xs", children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        onClick: () => setLocale("fr"),
        className: `rounded-full px-2.5 py-1 font-medium transition-colors ${locale === "fr" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`,
        "aria-pressed": locale === "fr",
        children: "FR"
      }
    ),
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        onClick: () => setLocale("ar"),
        className: `rounded-full px-2.5 py-1 font-medium transition-colors ${locale === "ar" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`,
        "aria-pressed": locale === "ar",
        children: "ع"
      }
    )
  ] });
}
function NotFoundContent() {
  const t = useT();
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: t("404.title") }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: t("404.desc") }),
    /* @__PURE__ */ jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: t("404.home")
      }
    ) })
  ] }) });
}
function NotFoundComponent() {
  return /* @__PURE__ */ jsx(LocaleProvider, { children: /* @__PURE__ */ jsx(NotFoundContent, {}) });
}
function ErrorContent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  const t = useT();
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: t("err.title") }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: t("err.desc") }),
    error && /* @__PURE__ */ jsxs("div", { className: "mt-4 rounded-md border border-destructive/20 bg-destructive/5 p-3 text-left text-xs font-mono text-destructive max-w-md mx-auto overflow-auto max-h-40", children: [
      /* @__PURE__ */ jsx("strong", { children: "Error:" }),
      " ",
      error.message || String(error)
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: t("err.retry")
        }
      ),
      /* @__PURE__ */ jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: t("404.home")
        }
      )
    ] })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  return /* @__PURE__ */ jsx(LocaleProvider, { children: /* @__PURE__ */ jsx(ErrorContent, { error, reset }) });
}
const Route$o = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Roomies — Trouvez un colocataire au Maroc" },
      { name: "description", content: "Roomies vous aide à trouver un colocataire compatible à Casablanca, Rabat, Marrakech et dans toutes les villes du Maroc — sans groupes Facebook ni frais de samsar." },
      { property: "og:site_name", content: "Roomies" },
      { property: "og:type", content: "website" },
      { name: "theme-color", content: "#c4654a" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-title", content: "Roomies" },
      { name: "apple-mobile-web-app-status-bar-style", content: "default" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/75b67cca-473f-4a2e-92be-743dc6a80a5c/id-preview-e63f952e--dde9e189-5a27-431e-bea0-3315487aa092.lovable.app-1778539265164.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/75b67cca-473f-4a2e-92be-743dc6a80a5c/id-preview-e63f952e--dde9e189-5a27-431e-bea0-3315487aa092.lovable.app-1778539265164.png" }
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss
      },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/icon-512.png" },
      { rel: "icon", type: "image/png", href: "/icon-512.png" }
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "WebSite",
              name: "Roomies",
              url: "https://smartko.shop"
            },
            {
              "@type": "Organization",
              name: "Roomies",
              url: "https://smartko.shop"
            }
          ]
        })
      }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxs("html", { lang: "fr", children: [
    /* @__PURE__ */ jsxs("head", { children: [
      /* @__PURE__ */ jsx(HeadContent, {}),
      /* @__PURE__ */ jsx(
        "script",
        {
          dangerouslySetInnerHTML: {
            __html: `
              if (window.location.hostname.includes("lovable.app") && window.location.hash.includes("type=recovery")) {
                window.location.href = "https://smartko.shop/reset-password" + window.location.hash;
              }
            `
          }
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$o.useRouteContext();
  return /* @__PURE__ */ jsx(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsx(LocaleProvider, { children: /* @__PURE__ */ jsxs(AuthProvider, { children: [
    /* @__PURE__ */ jsx(Outlet, {}),
    /* @__PURE__ */ jsx(Toaster, {})
  ] }) }) });
}
const $$splitComponentImporter$l = () => import("./verify-DL-Sjs2y.js");
const Route$n = createFileRoute("/verify")({
  head: () => ({
    meta: [{
      title: "Vérifier votre numéro — Roomies"
    }, {
      name: "description",
      content: "Confirmez votre numéro pour obtenir le badge vérifié et débloquer le contact direct avec vos matchs."
    }, {
      property: "og:title",
      content: "Vérifier votre numéro — Roomies"
    }, {
      property: "og:description",
      content: "Confirmez votre numéro pour obtenir le badge vérifié et débloquer le contact direct avec vos matchs."
    }, {
      property: "og:url",
      content: "https://smartko.shop/verify"
    }],
    links: [{
      rel: "canonical",
      href: "https://smartko.shop/verify"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$l, "component")
});
const BASE_URL = "https://smartko.shop";
const Route$m = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries = [
          { path: "/", changefreq: "weekly", priority: "1.0" },
          { path: "/discover", changefreq: "weekly", priority: "0.9" },
          { path: "/login", changefreq: "monthly", priority: "0.5" },
          { path: "/signup", changefreq: "monthly", priority: "0.7" },
          { path: "/forgot-password", changefreq: "yearly", priority: "0.3" }
        ];
        const urls = entries.map(
          (e) => [
            `  <url>`,
            `    <loc>${BASE_URL}${e.path}</loc>`,
            e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
            e.priority ? `    <priority>${e.priority}</priority>` : null,
            `  </url>`
          ].filter(Boolean).join("\n")
        );
        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`
        ].join("\n");
        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600"
          }
        });
      }
    }
  }
});
const $$splitComponentImporter$k = () => import("./signup-qZhWN7nQ.js");
const Route$l = createFileRoute("/signup")({
  head: () => ({
    meta: [{
      title: "Créer un compte Roomies"
    }, {
      name: "description",
      content: "Inscrivez-vous sur Roomies en moins d'une minute et commencez à matcher avec des colocataires compatibles dans votre ville."
    }, {
      property: "og:title",
      content: "Créer un compte Roomies"
    }, {
      property: "og:description",
      content: "Inscrivez-vous sur Roomies en moins d'une minute et commencez à matcher avec des colocataires compatibles dans votre ville."
    }, {
      property: "og:url",
      content: "https://smartko.shop/signup"
    }],
    links: [{
      rel: "canonical",
      href: "https://smartko.shop/signup"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$k, "component")
});
const $$splitComponentImporter$j = () => import("./safety-D56lz2-J.js");
const Route$k = createFileRoute("/safety")({
  head: () => ({
    meta: [{
      title: "Conseils de sécurité — Roomies"
    }, {
      name: "description",
      content: "Comment rencontrer un futur colocataire en toute sécurité, repérer les samsara et éviter les arnaques sur Roomies."
    }, {
      property: "og:title",
      content: "Conseils de sécurité — Roomies"
    }, {
      property: "og:description",
      content: "Comment rencontrer un futur colocataire en toute sécurité, repérer les samsara et éviter les arnaques."
    }, {
      property: "og:url",
      content: "https://smartko.shop/safety"
    }],
    links: [{
      rel: "canonical",
      href: "https://smartko.shop/safety"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$j, "component")
});
const $$splitComponentImporter$i = () => import("./reset-password-DdELkP7A.js");
const Route$j = createFileRoute("/reset-password")({
  head: () => ({
    meta: [{
      title: "Définir un nouveau mot de passe — Roomies"
    }, {
      name: "robots",
      content: "noindex"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$i, "component")
});
const $$splitComponentImporter$h = () => import("./profile-BaBWeZau.js");
const Route$i = createFileRoute("/profile")({
  head: () => ({
    meta: [{
      title: "Your profile — Roomies"
    }, {
      name: "description",
      content: "Manage your Roomies profile: photo, bio, contact details, and what you share with matches."
    }, {
      property: "og:title",
      content: "Your profile — Roomies"
    }, {
      property: "og:description",
      content: "Manage your Roomies profile: photo, bio, contact details, and what you share with matches."
    }, {
      property: "og:url",
      content: "https://smartko.shop/profile"
    }],
    links: [{
      rel: "canonical",
      href: "https://smartko.shop/profile"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$h, "component")
});
const $$splitComponentImporter$g = () => import("./places-BuBGaGF4.js");
const Route$h = createFileRoute("/places")({
  head: () => ({
    meta: [{
      title: "Browse rooms — Roomies"
    }, {
      name: "description",
      content: "Find a room offered by other roommates. Filter by city and budget."
    }, {
      property: "og:title",
      content: "Browse rooms — Roomies"
    }, {
      property: "og:description",
      content: "Find a room offered by other roommates. Filter by city and budget."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$g, "component")
});
const $$splitComponentImporter$f = () => import("./pending-review-BwOJ0EuZ.js");
const Route$g = createFileRoute("/pending-review")({
  head: () => ({
    meta: [{
      title: "Profil en révision — Roomies"
    }, {
      name: "robots",
      content: "noindex, nofollow"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$f, "component")
});
const $$splitComponentImporter$e = () => import("./onboarding-B1np_xTr.js");
const Route$f = createFileRoute("/onboarding")({
  head: () => ({
    meta: [{
      title: "Set up your profile — Roomies"
    }, {
      name: "description",
      content: "Tell us about yourself, your budget, and your lifestyle so Roomies can match you with compatible roommates."
    }, {
      property: "og:title",
      content: "Set up your profile — Roomies"
    }, {
      property: "og:description",
      content: "Tell us about yourself, your budget, and your lifestyle so Roomies can match you with compatible roommates."
    }, {
      property: "og:url",
      content: "https://smartko.shop/onboarding"
    }],
    links: [{
      rel: "canonical",
      href: "https://smartko.shop/onboarding"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$e, "component")
});
const $$splitComponentImporter$d = () => import("./matches-BmXZNis7.js");
const Route$e = createFileRoute("/matches")({
  head: () => ({
    meta: [{
      title: "Vos matchs — Roomies"
    }, {
      name: "description",
      content: "Découvrez les colocataires qui vous ont aussi liké(e). Ouvrez un match pour voir son profil et ses contacts."
    }, {
      property: "og:title",
      content: "Vos matchs — Roomies"
    }, {
      property: "og:description",
      content: "Découvrez les colocataires qui vous ont aussi liké(e). Ouvrez un match pour voir son profil et ses contacts."
    }, {
      property: "og:url",
      content: "https://smartko.shop/matches"
    }],
    links: [{
      rel: "canonical",
      href: "https://smartko.shop/matches"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$d, "component")
});
const $$splitComponentImporter$c = () => import("./login-D7K7tbYK.js");
const Route$d = createFileRoute("/login")({
  head: () => ({
    meta: [{
      title: "Connexion — Roomies"
    }, {
      name: "description",
      content: "Connectez-vous à Roomies pour continuer à découvrir, discuter avec vos matchs et mettre à jour votre profil colocataire."
    }, {
      property: "og:title",
      content: "Connexion — Roomies"
    }, {
      property: "og:description",
      content: "Connectez-vous à Roomies pour continuer à découvrir, discuter avec vos matchs et mettre à jour votre profil colocataire."
    }, {
      property: "og:url",
      content: "https://smartko.shop/login"
    }],
    links: [{
      rel: "canonical",
      href: "https://smartko.shop/login"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$c, "component")
});
const $$splitComponentImporter$b = () => import("./forgot-password-BT8xNlLi.js");
const Route$c = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [{
      title: "Mot de passe oublié — Roomies"
    }, {
      name: "description",
      content: "Réinitialisez votre mot de passe Roomies. Nous vous enverrons un lien sécurisé par e-mail."
    }, {
      property: "og:title",
      content: "Mot de passe oublié — Roomies"
    }, {
      property: "og:description",
      content: "Réinitialisez votre mot de passe Roomies. Nous vous enverrons un lien sécurisé par e-mail."
    }, {
      property: "og:url",
      content: "https://smartko.shop/forgot-password"
    }],
    links: [{
      rel: "canonical",
      href: "https://smartko.shop/forgot-password"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$b, "component")
});
const $$splitComponentImporter$a = () => import("./discover-CQpW59xV.js");
const Route$b = createFileRoute("/discover")({
  head: () => ({
    meta: [{
      title: "Discover roommates — Roomies"
    }, {
      name: "description",
      content: "Browse compatible roommate profiles in your city. Filter by budget, lifestyle, and habits, then like to match."
    }, {
      property: "og:title",
      content: "Discover roommates — Roomies"
    }, {
      property: "og:description",
      content: "Browse compatible roommate profiles in your city. Filter by budget, lifestyle, and habits, then like to match."
    }, {
      property: "og:url",
      content: "https://smartko.shop/discover"
    }],
    links: [{
      rel: "canonical",
      href: "https://smartko.shop/discover"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$a, "component")
});
const $$splitComponentImporter$9 = () => import("./chats-VPkM03LM.js");
const Route$a = createFileRoute("/chats")({
  head: () => ({
    meta: [{
      title: "Vos discussions — Roomies"
    }, {
      name: "description",
      content: "Toutes vos conversations avec vos matchs."
    }, {
      name: "robots",
      content: "noindex"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
const $$splitComponentImporter$8 = () => import("./admin-Yg9PM8Bc.js");
const Route$9 = createFileRoute("/admin")({
  head: () => ({
    meta: [{
      title: "Admin reports — Roomies"
    }, {
      name: "description",
      content: "Review user reports and moderate Roomies activity. Restricted to administrators."
    }, {
      name: "robots",
      content: "noindex, nofollow"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
const $$splitComponentImporter$7 = () => import("./index-CZ0eos1Z.js");
const Route$8 = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "Roomies — Zéro samsar. Colocataires compatibles au Maroc."
    }, {
      name: "description",
      content: "Zéro commission. Zéro samsar. Roomies vous matche avec des colocataires compatibles et vérifiés à Casablanca, Rabat, Marrakech et partout au Maroc — selon votre style de vie."
    }, {
      property: "og:title",
      content: "Roomies — Zéro samsar. Colocataires compatibles au Maroc."
    }, {
      property: "og:description",
      content: "Zéro commission. Zéro samsar. Roomies vous matche avec des colocataires compatibles à Casablanca, Rabat, Marrakech et partout au Maroc."
    }, {
      property: "og:url",
      content: "https://smartko.shop/"
    }],
    links: [{
      rel: "canonical",
      href: "https://smartko.shop/"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
const $$splitComponentImporter$6 = () => import("./profile_._id-D_e1-w6y.js");
const Route$7 = createFileRoute("/profile_/$id")({
  validateSearch: (search) => ({
    welcome: search.welcome === 1 || search.welcome === "1" ? 1 : void 0
  }),
  head: ({
    params
  }) => ({
    meta: [{
      title: "Roommate profile — Roomies"
    }, {
      name: "description",
      content: "View this Roomies member's lifestyle, budget, and contact details to decide if you'd be a good roommate fit."
    }, {
      property: "og:title",
      content: "Roommate profile — Roomies"
    }, {
      property: "og:description",
      content: "View this Roomies member's lifestyle, budget, and contact details to decide if you'd be a good roommate fit."
    }, {
      property: "og:type",
      content: "profile"
    }, {
      property: "og:url",
      content: `https://smartko.shop/profile/${params.id}`
    }],
    links: [{
      rel: "canonical",
      href: `https://smartko.shop/profile/${params.id}`
    }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "ProfilePage",
        mainEntity: {
          "@type": "Person",
          identifier: params.id,
          description: "Roomies member profile"
        }
      })
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./profile.saved-DnFELoSg.js");
const Route$6 = createFileRoute("/profile/saved")({
  head: () => ({
    meta: [{
      title: "Saved places — Roomies"
    }, {
      name: "robots",
      content: "noindex"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./profile.listings-DpLz6g4D.js");
const Route$5 = createFileRoute("/profile/listings")({
  head: () => ({
    meta: [{
      title: "My listings — Roomies"
    }, {
      name: "robots",
      content: "noindex"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./places.new-B5qXFp9N.js");
const Route$4 = createFileRoute("/places/new")({
  head: () => ({
    meta: [{
      title: "List a room — Roomies"
    }, {
      name: "robots",
      content: "noindex"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./places._id-DVJ1VLA0.js");
const Route$3 = createFileRoute("/places/$id")({
  head: () => ({
    meta: [{
      title: "Room details — Roomies"
    }, {
      name: "robots",
      content: "noindex"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./chat._id-NtUhKbfK.js");
const Route$2 = createFileRoute("/chat/$id")({
  head: () => ({
    meta: [{
      title: "Chat — Roomies"
    }, {
      name: "robots",
      content: "noindex"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./places._id.edit-BWV1s6sM.js");
const Route$1 = createFileRoute("/places/$id/edit")({
  head: () => ({
    meta: [{
      title: "Edit listing — Roomies"
    }, {
      name: "robots",
      content: "noindex"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const MAX_RETRIES = 5;
const DEFAULT_BATCH_SIZE = 10;
const DEFAULT_SEND_DELAY_MS = 200;
const DEFAULT_AUTH_TTL_MINUTES = 15;
const DEFAULT_TRANSACTIONAL_TTL_MINUTES = 60;
function isRateLimited(error) {
  if (error && typeof error === "object" && "status" in error) {
    return error.status === 429;
  }
  return error instanceof Error && error.message.includes("429");
}
function isForbidden(error) {
  if (error && typeof error === "object" && "status" in error) {
    return error.status === 403;
  }
  return error instanceof Error && error.message.includes("403");
}
function getRetryAfterSeconds(error) {
  if (error && typeof error === "object" && "retryAfterSeconds" in error) {
    return error.retryAfterSeconds ?? 60;
  }
  return 60;
}
async function moveToDlq(supabase2, queue, msg, reason) {
  const payload = msg.message;
  await supabase2.from("email_send_log").insert({
    message_id: payload.message_id,
    template_name: payload.label || queue,
    recipient_email: payload.to,
    status: "dlq",
    error_message: reason
  });
  const { error } = await supabase2.rpc("move_to_dlq", {
    source_queue: queue,
    dlq_name: `${queue}_dlq`,
    message_id: msg.msg_id,
    payload
  });
  if (error) {
    console.error("Failed to move message to DLQ", { queue, msg_id: msg.msg_id, reason, error });
  }
}
const Route = createFileRoute("/lovable/email/queue/process")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const authHeader = request.headers.get("Authorization");
        if (!authHeader?.startsWith("Bearer ")) {
          return Response.json({ error: "Unauthorized" }, { status: 401 });
        }
        const token = authHeader.slice("Bearer ".length).trim();
        if (token === "invalid-server-config-token") {
          return Response.json(
            { error: "Server configuration error" },
            { status: 500 }
          );
        }
        const apiKey = process.env.LOVABLE_API_KEY;
        const supabaseUrl = "https://nzevdzkirznlagightap.supabase.co";
        const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
        if (!apiKey || !supabaseUrl || !supabaseServiceKey) {
          console.error("Missing required environment variables");
          return Response.json(
            { error: "Server configuration error" },
            { status: 500 }
          );
        }
        if (token !== supabaseServiceKey) {
          return Response.json({ error: "Forbidden" }, { status: 403 });
        }
        const supabase2 = createClient(supabaseUrl, supabaseServiceKey);
        const { data: state } = await supabase2.from("email_send_state").select("retry_after_until, batch_size, send_delay_ms, auth_email_ttl_minutes, transactional_email_ttl_minutes").single();
        if (state?.retry_after_until && new Date(state.retry_after_until) > /* @__PURE__ */ new Date()) {
          return Response.json({ skipped: true, reason: "rate_limited" });
        }
        const batchSize = state?.batch_size ?? DEFAULT_BATCH_SIZE;
        const sendDelayMs = state?.send_delay_ms ?? DEFAULT_SEND_DELAY_MS;
        const ttlMinutes = {
          auth_emails: state?.auth_email_ttl_minutes ?? DEFAULT_AUTH_TTL_MINUTES,
          transactional_emails: state?.transactional_email_ttl_minutes ?? DEFAULT_TRANSACTIONAL_TTL_MINUTES
        };
        let totalProcessed = 0;
        for (const queue of ["auth_emails", "transactional_emails"]) {
          const { data: messages, error: readError } = await supabase2.rpc("read_email_batch", {
            queue_name: queue,
            batch_size: batchSize,
            vt: 30
          });
          if (readError) {
            console.error("Failed to read email batch", { queue, error: readError });
            continue;
          }
          if (!messages?.length) continue;
          const messageIds = Array.from(
            new Set(
              messages.map(
                (msg) => msg?.message?.message_id && typeof msg.message.message_id === "string" ? msg.message.message_id : null
              ).filter((id) => Boolean(id))
            )
          );
          const failedAttemptsByMessageId = /* @__PURE__ */ new Map();
          if (messageIds.length > 0) {
            const { data: failedRows, error: failedRowsError } = await supabase2.from("email_send_log").select("message_id").in("message_id", messageIds).eq("status", "failed");
            if (failedRowsError) {
              console.error("Failed to load failed-attempt counters", {
                queue,
                error: failedRowsError
              });
            } else {
              for (const row of failedRows ?? []) {
                const messageId = row?.message_id;
                if (typeof messageId !== "string" || !messageId) continue;
                failedAttemptsByMessageId.set(
                  messageId,
                  (failedAttemptsByMessageId.get(messageId) ?? 0) + 1
                );
              }
            }
          }
          for (let i = 0; i < messages.length; i++) {
            const msg = messages[i];
            const payload = msg.message;
            const failedAttempts = payload?.message_id && typeof payload.message_id === "string" ? failedAttemptsByMessageId.get(payload.message_id) ?? 0 : msg.read_ct ?? 0;
            const queuedAt = payload.queued_at ?? msg.enqueued_at;
            if (queuedAt) {
              const ageMs = Date.now() - new Date(queuedAt).getTime();
              const maxAgeMs = ttlMinutes[queue] * 60 * 1e3;
              if (ageMs > maxAgeMs) {
                console.warn("Email expired (TTL exceeded)", {
                  queue,
                  msg_id: msg.msg_id,
                  queued_at: queuedAt,
                  ttl_minutes: ttlMinutes[queue]
                });
                await moveToDlq(supabase2, queue, msg, `TTL exceeded (${ttlMinutes[queue]} minutes)`);
                continue;
              }
            }
            if (failedAttempts >= MAX_RETRIES) {
              await moveToDlq(supabase2, queue, msg, `Max retries (${MAX_RETRIES}) exceeded (attempted ${failedAttempts} times)`);
              continue;
            }
            if (payload.message_id) {
              const { data: alreadySent } = await supabase2.from("email_send_log").select("id").eq("message_id", payload.message_id).eq("status", "sent").maybeSingle();
              if (alreadySent) {
                console.warn("Skipping duplicate send (already sent)", {
                  queue,
                  msg_id: msg.msg_id,
                  message_id: payload.message_id
                });
                const { error: dupDelError } = await supabase2.rpc("delete_email", {
                  queue_name: queue,
                  message_id: msg.msg_id
                });
                if (dupDelError) {
                  console.error("Failed to delete duplicate message from queue", { queue, msg_id: msg.msg_id, error: dupDelError });
                }
                continue;
              }
            }
            try {
              await sendLovableEmail(
                {
                  run_id: payload.run_id,
                  to: payload.to,
                  from: payload.from,
                  sender_domain: payload.sender_domain,
                  subject: payload.subject,
                  html: payload.html,
                  text: payload.text,
                  purpose: payload.purpose,
                  label: payload.label,
                  idempotency_key: payload.idempotency_key,
                  unsubscribe_token: payload.unsubscribe_token,
                  message_id: payload.message_id
                },
                { apiKey, sendUrl: process.env.LOVABLE_SEND_URL }
              );
              await supabase2.from("email_send_log").insert({
                message_id: payload.message_id,
                template_name: payload.label || queue,
                recipient_email: payload.to,
                status: "sent"
              });
              const { error: delError } = await supabase2.rpc("delete_email", {
                queue_name: queue,
                message_id: msg.msg_id
              });
              if (delError) {
                console.error("Failed to delete sent message from queue", { queue, msg_id: msg.msg_id, error: delError });
              }
              totalProcessed++;
            } catch (error) {
              const errorMsg = error instanceof Error ? error.message : String(error);
              console.error("Email send failed", {
                queue,
                msg_id: msg.msg_id,
                read_ct: msg.read_ct,
                failed_attempts: failedAttempts,
                error: errorMsg
              });
              if (isRateLimited(error)) {
                await supabase2.from("email_send_log").insert({
                  message_id: payload.message_id,
                  template_name: payload.label || queue,
                  recipient_email: payload.to,
                  status: "failed",
                  error_message: errorMsg.slice(0, 1e3)
                });
                const retryAfterSecs = getRetryAfterSeconds(error);
                await supabase2.from("email_send_state").update({
                  retry_after_until: new Date(
                    Date.now() + retryAfterSecs * 1e3
                  ).toISOString(),
                  updated_at: (/* @__PURE__ */ new Date()).toISOString()
                }).eq("id", 1);
                return Response.json({ processed: totalProcessed, stopped: "rate_limited" });
              }
              if (isForbidden(error)) {
                await moveToDlq(supabase2, queue, msg, errorMsg.slice(0, 1e3));
                return Response.json({ processed: totalProcessed, stopped: "forbidden" });
              }
              await supabase2.from("email_send_log").insert({
                message_id: payload.message_id,
                template_name: payload.label || queue,
                recipient_email: payload.to,
                status: "failed",
                error_message: errorMsg.slice(0, 1e3)
              });
              if (payload?.message_id && typeof payload.message_id === "string") {
                failedAttemptsByMessageId.set(payload.message_id, failedAttempts + 1);
              }
            }
            if (i < messages.length - 1) {
              await new Promise((r) => setTimeout(r, sendDelayMs));
            }
          }
        }
        return Response.json({ processed: totalProcessed });
      }
    }
  }
});
const VerifyRoute = Route$n.update({
  id: "/verify",
  path: "/verify",
  getParentRoute: () => Route$o
});
const SitemapDotxmlRoute = Route$m.update({
  id: "/sitemap.xml",
  path: "/sitemap.xml",
  getParentRoute: () => Route$o
});
const SignupRoute = Route$l.update({
  id: "/signup",
  path: "/signup",
  getParentRoute: () => Route$o
});
const SafetyRoute = Route$k.update({
  id: "/safety",
  path: "/safety",
  getParentRoute: () => Route$o
});
const ResetPasswordRoute = Route$j.update({
  id: "/reset-password",
  path: "/reset-password",
  getParentRoute: () => Route$o
});
const ProfileRoute = Route$i.update({
  id: "/profile",
  path: "/profile",
  getParentRoute: () => Route$o
});
const PlacesRoute = Route$h.update({
  id: "/places",
  path: "/places",
  getParentRoute: () => Route$o
});
const PendingReviewRoute = Route$g.update({
  id: "/pending-review",
  path: "/pending-review",
  getParentRoute: () => Route$o
});
const OnboardingRoute = Route$f.update({
  id: "/onboarding",
  path: "/onboarding",
  getParentRoute: () => Route$o
});
const MatchesRoute = Route$e.update({
  id: "/matches",
  path: "/matches",
  getParentRoute: () => Route$o
});
const LoginRoute = Route$d.update({
  id: "/login",
  path: "/login",
  getParentRoute: () => Route$o
});
const ForgotPasswordRoute = Route$c.update({
  id: "/forgot-password",
  path: "/forgot-password",
  getParentRoute: () => Route$o
});
const DiscoverRoute = Route$b.update({
  id: "/discover",
  path: "/discover",
  getParentRoute: () => Route$o
});
const ChatsRoute = Route$a.update({
  id: "/chats",
  path: "/chats",
  getParentRoute: () => Route$o
});
const AdminRoute = Route$9.update({
  id: "/admin",
  path: "/admin",
  getParentRoute: () => Route$o
});
const IndexRoute = Route$8.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$o
});
const ProfileIdRoute = Route$7.update({
  id: "/profile_/$id",
  path: "/profile/$id",
  getParentRoute: () => Route$o
});
const ProfileSavedRoute = Route$6.update({
  id: "/saved",
  path: "/saved",
  getParentRoute: () => ProfileRoute
});
const ProfileListingsRoute = Route$5.update({
  id: "/listings",
  path: "/listings",
  getParentRoute: () => ProfileRoute
});
const PlacesNewRoute = Route$4.update({
  id: "/new",
  path: "/new",
  getParentRoute: () => PlacesRoute
});
const PlacesIdRoute = Route$3.update({
  id: "/$id",
  path: "/$id",
  getParentRoute: () => PlacesRoute
});
const ChatIdRoute = Route$2.update({
  id: "/chat/$id",
  path: "/chat/$id",
  getParentRoute: () => Route$o
});
const PlacesIdEditRoute = Route$1.update({
  id: "/edit",
  path: "/edit",
  getParentRoute: () => PlacesIdRoute
});
const LovableEmailQueueProcessRoute = Route.update({
  id: "/lovable/email/queue/process",
  path: "/lovable/email/queue/process",
  getParentRoute: () => Route$o
});
const PlacesIdRouteChildren = {
  PlacesIdEditRoute
};
const PlacesIdRouteWithChildren = PlacesIdRoute._addFileChildren(
  PlacesIdRouteChildren
);
const PlacesRouteChildren = {
  PlacesIdRoute: PlacesIdRouteWithChildren,
  PlacesNewRoute
};
const PlacesRouteWithChildren = PlacesRoute._addFileChildren(PlacesRouteChildren);
const ProfileRouteChildren = {
  ProfileListingsRoute,
  ProfileSavedRoute
};
const ProfileRouteWithChildren = ProfileRoute._addFileChildren(ProfileRouteChildren);
const rootRouteChildren = {
  IndexRoute,
  AdminRoute,
  ChatsRoute,
  DiscoverRoute,
  ForgotPasswordRoute,
  LoginRoute,
  MatchesRoute,
  OnboardingRoute,
  PendingReviewRoute,
  PlacesRoute: PlacesRouteWithChildren,
  ProfileRoute: ProfileRouteWithChildren,
  ResetPasswordRoute,
  SafetyRoute,
  SignupRoute,
  SitemapDotxmlRoute,
  VerifyRoute,
  ChatIdRoute,
  ProfileIdRoute,
  LovableEmailQueueProcessRoute
};
const routeTree = Route$o._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  LanguageSwitcher as L,
  Route$7 as R,
  Route$3 as a,
  Route$2 as b,
  Route$1 as c,
  useT as d,
  router as r,
  useAuth as u
};
