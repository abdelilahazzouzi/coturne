import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { s as supabase } from "./client-BAiQKvvS.js";
import { u as useAuth, d as useT } from "./router-Ds3vjgN6.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { I as Input } from "./input-C0QjszdI.js";
import { T as Textarea } from "./textarea-DSyJ1nlY.js";
import { L as Label } from "./label-JU3yqRBo.js";
import { u as useCities, D as DEFAULT_CITIES } from "./cities-JYrO-Wlx.js";
import { toast } from "sonner";
import { Lock, Sparkles } from "lucide-react";
const empty = {
  title: "",
  description: "",
  city: DEFAULT_CITIES[0],
  neighborhood: "",
  rent_monthly: 2e3,
  currency: "MAD",
  available_from: "",
  min_stay_months: null,
  room_type: "private",
  furnished: false,
  bills_included: false,
  photos: [],
  status: "draft"
};
function PlaceEditor({ initial }) {
  const { user } = useAuth();
  const nav = useNavigate();
  const t = useT();
  const { cities: dynamicCities } = useCities();
  const [form, setForm] = useState(initial ?? empty);
  const [saving, setSaving] = useState(false);
  const isEdit = !!initial?.id;
  const { data: meProfile } = useQuery({
    queryKey: ["me-review-status", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("review_status").eq("id", user.id).maybeSingle();
      return data;
    }
  });
  const canPublish = !meProfile?.review_status || meProfile.review_status === "approved";
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const save = async (status) => {
    if (!user) return;
    if (!form.title.trim() || !form.city || !form.rent_monthly) {
      toast.error("Title, city and rent are required.");
      return;
    }
    if (status === "published" && !canPublish) {
      toast.error(t("pe.cannotPublish") ?? "Your profile must be approved before publishing a listing.");
      return;
    }
    setSaving(true);
    const payload = {
      host_id: user.id,
      title: form.title.trim(),
      description: form.description.trim(),
      city: form.city,
      neighborhood: form.neighborhood.trim() || null,
      rent_monthly: form.rent_monthly,
      currency: form.currency,
      available_from: form.available_from || null,
      min_stay_months: form.min_stay_months,
      room_type: form.room_type,
      furnished: form.furnished,
      bills_included: form.bills_included,
      photos: form.photos,
      status
    };
    if (isEdit) {
      const { error } = await supabase.from("places").update(payload).eq("id", form.id);
      setSaving(false);
      if (error) return toast.error(error.message);
      toast.success("Saved");
      nav({ to: "/places/$id", params: { id: form.id } });
    } else {
      const { data, error } = await supabase.from("places").insert(payload).select("id").single();
      setSaving(false);
      if (error) return toast.error(error.message);
      toast.success(status === "published" ? "Published!" : "Saved as draft");
      nav({ to: "/places/$id", params: { id: data.id } });
    }
  };
  const onSubmit = (e) => {
    e.preventDefault();
    if (saving) return;
    save("published");
  };
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md space-y-6 p-5 sm:p-6", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: isEdit ? "Edit listing" : "List a room" }),
    /* @__PURE__ */ jsx("div", { className: "rounded-2xl border border-border bg-gradient-to-br from-primary/5 to-accent/20 p-5", children: /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
      /* @__PURE__ */ jsx("div", { className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary", children: /* @__PURE__ */ jsx(Lock, { className: "h-5 w-5" }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 text-sm font-semibold", children: [
          /* @__PURE__ */ jsx(Sparkles, { className: "h-3.5 w-3.5 text-primary" }),
          t("pe.photosPremiumTitle") ?? "Photos · Premium"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-1.5 text-xs text-muted-foreground", children: t("pe.photosPremiumBody") ?? "Listing photos are coming soon with Roomies Premium. For now your listing will use a clean default visual." }),
        /* @__PURE__ */ jsx(
          Button,
          {
            type: "button",
            variant: "outline",
            size: "sm",
            disabled: true,
            className: "mt-3",
            children: t("pe.upgradePremium") ?? "Coming soon"
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("form", { onSubmit, className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "pe-title", children: "Title" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            id: "pe-title",
            autoFocus: true,
            value: form.title,
            onChange: (e) => set("title", e.target.value),
            placeholder: "Sunny room in central Casablanca",
            maxLength: 120
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "pe-city", children: "City" }),
          /* @__PURE__ */ jsx(
            "select",
            {
              id: "pe-city",
              value: form.city,
              onChange: (e) => set("city", e.target.value),
              className: "w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
              children: dynamicCities.map((c) => /* @__PURE__ */ jsx("option", { value: c, children: c }, c))
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "pe-neigh", children: "Neighborhood" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "pe-neigh",
              value: form.neighborhood,
              onChange: (e) => set("neighborhood", e.target.value),
              placeholder: "Maarif"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "pe-rent", children: "Rent / month" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "pe-rent",
              type: "number",
              inputMode: "numeric",
              value: form.rent_monthly,
              onChange: (e) => set("rent_monthly", parseInt(e.target.value) || 0)
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "pe-curr", children: "Currency" }),
          /* @__PURE__ */ jsxs(
            "select",
            {
              id: "pe-curr",
              value: form.currency,
              onChange: (e) => set("currency", e.target.value),
              className: "w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
              children: [
                /* @__PURE__ */ jsx("option", { value: "MAD", children: "MAD" }),
                /* @__PURE__ */ jsx("option", { value: "EUR", children: "EUR" }),
                /* @__PURE__ */ jsx("option", { value: "USD", children: "USD" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "pe-from", children: "Available from" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "pe-from",
              type: "date",
              value: form.available_from,
              onChange: (e) => set("available_from", e.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "pe-stay", children: "Min stay (months)" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "pe-stay",
              type: "number",
              inputMode: "numeric",
              value: form.min_stay_months ?? "",
              onChange: (e) => set("min_stay_months", e.target.value ? parseInt(e.target.value) : null)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Room type" }),
        /* @__PURE__ */ jsx("div", { className: "flex gap-2", children: ["private", "shared"].map((rt) => /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            onClick: () => set("room_type", rt),
            className: `flex-1 rounded-md border px-3 py-2 text-sm capitalize ${form.room_type === rt ? "border-primary bg-primary/10 text-primary" : "border-border"}`,
            children: rt
          },
          rt
        )) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-5", children: [
        /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-sm", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "checkbox",
              checked: form.furnished,
              onChange: (e) => set("furnished", e.target.checked)
            }
          ),
          "Furnished"
        ] }),
        /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-sm", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "checkbox",
              checked: form.bills_included,
              onChange: (e) => set("bills_included", e.target.checked)
            }
          ),
          "Bills included"
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "pe-desc", children: "Description" }),
        /* @__PURE__ */ jsx(
          Textarea,
          {
            id: "pe-desc",
            value: form.description,
            onChange: (e) => set("description", e.target.value),
            rows: 5,
            placeholder: "Tell potential roommates about the place, the vibe, and what you're looking for.",
            maxLength: 2e3
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-3 pb-6 pt-2", children: [
        /* @__PURE__ */ jsx(
          Button,
          {
            type: "button",
            variant: "outline",
            className: "flex-1",
            onClick: () => save("draft"),
            disabled: saving,
            children: saving ? "Saving…" : "Save draft"
          }
        ),
        /* @__PURE__ */ jsx(
          Button,
          {
            type: "submit",
            className: "flex-1",
            disabled: saving,
            children: saving ? "Saving…" : isEdit ? "Save & publish" : "Publish"
          }
        )
      ] })
    ] })
  ] });
}
export {
  PlaceEditor as P
};
