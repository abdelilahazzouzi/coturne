import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, useRef, useId } from "react";
import { useQuery } from "@tanstack/react-query";
import { u as useAuth, d as useT, L as LanguageSwitcher } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { AnimatePresence, motion } from "motion/react";
import { X, Heart, ArrowRight, ShieldCheck, Users, UserCheck, MapPin, MessageCircle } from "lucide-react";
import "sonner";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
function useOutsideClick(ref, callback) {
  useEffect(() => {
    const listener = (event) => {
      if (!ref.current || ref.current.contains(event.target)) return;
      callback(event);
    };
    document.addEventListener("mousedown", listener);
    document.addEventListener("touchstart", listener);
    return () => {
      document.removeEventListener("mousedown", listener);
      document.removeEventListener("touchstart", listener);
    };
  }, [ref, callback]);
}
function ExpandableFeatureCards({ items }) {
  const [active, setActive] = useState(null);
  const ref = useRef(null);
  const id = useId();
  useEffect(() => {
    const onKeyDown = (e) => {
      if (e.key === "Escape") setActive(null);
    };
    if (active) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "auto";
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [active]);
  useOutsideClick(ref, () => setActive(null));
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(AnimatePresence, { children: active && /* @__PURE__ */ jsx(
      motion.div,
      {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
        className: "fixed inset-0 z-40 bg-background/70 backdrop-blur-sm"
      }
    ) }),
    /* @__PURE__ */ jsx(AnimatePresence, { children: active && /* @__PURE__ */ jsxs("div", { className: "fixed inset-0 z-50 grid place-items-center p-4", children: [
      /* @__PURE__ */ jsx(
        motion.button,
        {
          layout: true,
          initial: { opacity: 0 },
          animate: { opacity: 1 },
          exit: { opacity: 0, transition: { duration: 0.05 } },
          className: "absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full bg-card text-foreground shadow lg:hidden",
          onClick: () => setActive(null),
          "aria-label": "Close",
          children: /* @__PURE__ */ jsx(X, { className: "h-4 w-4" })
        },
        `button-${active.title}-${id}`
      ),
      /* @__PURE__ */ jsxs(
        motion.div,
        {
          layoutId: `card-${active.title}-${id}`,
          ref,
          className: "flex h-full w-full max-w-[500px] flex-col overflow-hidden rounded-3xl border border-border bg-card sm:h-auto sm:max-h-[90vh]",
          children: [
            /* @__PURE__ */ jsx(
              motion.div,
              {
                layoutId: `image-${active.title}-${id}`,
                className: "flex h-40 w-full items-center justify-center bg-gradient-to-br from-primary/15 to-accent/40 text-primary",
                children: /* @__PURE__ */ jsx("div", { className: "[&_svg]:h-12 [&_svg]:w-12", children: active.icon })
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-4 p-6", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-4", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    motion.h3,
                    {
                      layoutId: `title-${active.title}-${id}`,
                      className: "text-lg font-semibold text-foreground",
                      children: active.title
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    motion.p,
                    {
                      layoutId: `description-${active.description}-${id}`,
                      className: "mt-1 text-sm text-muted-foreground",
                      children: active.description
                    }
                  )
                ] }),
                active.ctaHref ? /* @__PURE__ */ jsx(
                  motion.a,
                  {
                    layoutId: `button-${active.title}-${id}`,
                    href: active.ctaHref,
                    target: "_blank",
                    rel: "noreferrer",
                    className: "rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90",
                    children: active.ctaText
                  }
                ) : /* @__PURE__ */ jsx(
                  motion.button,
                  {
                    layoutId: `button-${active.title}-${id}`,
                    onClick: () => {
                      active.ctaOnClick?.();
                      setActive(null);
                    },
                    className: "rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90",
                    children: active.ctaText
                  }
                )
              ] }),
              /* @__PURE__ */ jsx(
                motion.div,
                {
                  initial: { opacity: 0 },
                  animate: { opacity: 1 },
                  exit: { opacity: 0 },
                  className: "overflow-y-auto pr-1 text-sm leading-relaxed text-foreground/80",
                  children: active.content
                }
              )
            ] })
          ]
        }
      )
    ] }) }),
    /* @__PURE__ */ jsx("ul", { className: "mx-auto w-full max-w-2xl space-y-2", children: items.map((card) => /* @__PURE__ */ jsxs(
      motion.li,
      {
        layoutId: `card-${card.title}-${id}`,
        onClick: () => setActive(card),
        className: "flex cursor-pointer flex-col items-start gap-3 rounded-xl border border-border bg-card/90 p-4 backdrop-blur hover:bg-accent/40 sm:flex-row sm:items-center sm:justify-between",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx(
              motion.div,
              {
                layoutId: `image-${card.title}-${id}`,
                className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent text-primary",
                children: card.icon
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "text-left", children: [
              /* @__PURE__ */ jsx(
                motion.h3,
                {
                  layoutId: `title-${card.title}-${id}`,
                  className: "text-sm font-semibold text-foreground",
                  children: card.title
                }
              ),
              /* @__PURE__ */ jsx(
                motion.p,
                {
                  layoutId: `description-${card.description}-${id}`,
                  className: "text-xs text-muted-foreground",
                  children: card.description
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsx(
            motion.button,
            {
              layoutId: `button-${card.title}-${id}`,
              className: "rounded-full border border-border bg-background px-4 py-1.5 text-xs font-semibold text-foreground hover:bg-primary hover:text-primary-foreground hover:border-primary transition-colors",
              children: card.ctaText
            }
          )
        ]
      },
      card.title
    )) })
  ] });
}
function LandingPage() {
  const {
    user,
    loading
  } = useAuth();
  const nav = useNavigate();
  const t = useT();
  const {
    data: profile,
    isLoading: pLoading
  } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("profiles").select("onboarded, review_status").eq("id", user.id).maybeSingle();
      if (error) throw error;
      return data;
    }
  });
  useEffect(() => {
    if (loading || !user) return;
    if (pLoading) return;
    if (profile?.review_status === "pending_minor_review") {
      nav({
        to: "/pending-review"
      });
    } else if (!profile || !profile.onboarded) {
      nav({
        to: "/onboarding"
      });
    } else {
      nav({
        to: "/discover"
      });
    }
  }, [user, loading, profile, pLoading, nav]);
  if (loading || user && pLoading || user) {
    return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background", children: /* @__PURE__ */ jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" }) });
  }
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsx("header", { className: "sticky top-0 z-10 border-b border-border bg-background/80 backdrop-blur", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto flex max-w-5xl items-center justify-between px-4 py-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx("div", { className: "flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground", children: /* @__PURE__ */ jsx(Heart, { className: "h-4 w-4" }) }),
        /* @__PURE__ */ jsx("span", { className: "text-lg font-semibold tracking-tight", children: "Roomies" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(LanguageSwitcher, {}),
        /* @__PURE__ */ jsx(Link, { to: "/login", className: "rounded-md px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground", children: t("landing.cta.signin") }),
        /* @__PURE__ */ jsx(Link, { to: "/signup", className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90", children: t("landing.cta.start") })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx("section", { id: "hero", className: "relative overflow-hidden border-b border-border bg-background px-4 pt-16 pb-20 sm:pt-24 sm:pb-28", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-3xl text-center", children: [
      /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-2 rounded-full border border-border bg-card/80 backdrop-blur px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground", children: [
        /* @__PURE__ */ jsx("span", { className: "h-1.5 w-1.5 rounded-full bg-primary" }),
        t("landing.badge")
      ] }),
      /* @__PURE__ */ jsxs("h1", { className: "mt-6 text-4xl font-bold tracking-tight text-foreground sm:text-6xl", children: [
        t("landing.hero.h1.part1"),
        " ",
        /* @__PURE__ */ jsx("span", { className: "text-primary", children: t("landing.hero.h1.samsar") }),
        t("landing.hero.h1.part2"),
        /* @__PURE__ */ jsx("br", { className: "hidden sm:block" }),
        t("landing.hero.h1.part3")
      ] }),
      /* @__PURE__ */ jsx("p", { className: "mx-auto mt-6 max-w-xl text-lg font-medium text-foreground/80", children: t("landing.hero.sub") }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 flex flex-wrap items-center justify-center gap-3", children: [
        /* @__PURE__ */ jsxs(Link, { to: "/signup", className: "inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 text-base font-semibold text-primary-foreground transition-colors hover:bg-primary/90 shadow-lg shadow-primary/20", children: [
          t("landing.hero.cta.start"),
          /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })
        ] }),
        /* @__PURE__ */ jsx(Link, { to: "/login", className: "inline-flex items-center justify-center rounded-full border border-border bg-card/90 backdrop-blur px-6 py-3 text-base font-semibold text-foreground transition-colors hover:bg-accent", children: t("landing.hero.cta.have") })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "mt-10", children: /* @__PURE__ */ jsx(ExpandableFeatureCards, { items: [{
        title: t("landing.feature.nobroker"),
        description: t("landing.feature.nobroker.desc"),
        ctaText: t("landing.hero.cta.start"),
        ctaHref: "/signup",
        icon: /* @__PURE__ */ jsx(ShieldCheck, {}),
        content: /* @__PURE__ */ jsxs("p", { children: [
          t("landing.feature.nobroker.desc"),
          " ",
          t("landing.why.body")
        ] })
      }, {
        title: t("landing.feature.gender"),
        description: t("landing.feature.gender.desc"),
        ctaText: t("landing.hero.cta.start"),
        ctaHref: "/signup",
        icon: /* @__PURE__ */ jsx(Users, {}),
        content: /* @__PURE__ */ jsxs("p", { children: [
          t("landing.feature.gender.desc"),
          " ",
          t("landing.f.twoway.desc")
        ] })
      }, {
        title: t("landing.feature.score"),
        description: t("landing.feature.score.desc"),
        ctaText: t("landing.hero.cta.start"),
        ctaHref: "/signup",
        icon: /* @__PURE__ */ jsx(Heart, {}),
        content: /* @__PURE__ */ jsxs("p", { children: [
          t("landing.feature.score.desc"),
          " ",
          t("landing.f.smart.desc")
        ] })
      }] }) })
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "border-t border-border bg-accent/30 px-4 py-12", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-3xl text-center", children: [
      /* @__PURE__ */ jsx("p", { className: "text-xs font-semibold uppercase tracking-wider text-primary", children: t("landing.why.kicker") }),
      /* @__PURE__ */ jsx("p", { className: "mt-3 text-base text-foreground sm:text-lg", children: t("landing.why.body") })
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "border-t border-border px-4 py-16 sm:py-20", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-5xl", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-center text-3xl font-bold tracking-tight text-foreground", children: t("landing.how.title") }),
      /* @__PURE__ */ jsx("p", { className: "mx-auto mt-3 max-w-lg text-center text-muted-foreground", children: t("landing.how.sub") }),
      /* @__PURE__ */ jsxs("div", { className: "mt-12 grid gap-8 sm:grid-cols-3", children: [
        /* @__PURE__ */ jsx(StepCard, { number: "1", icon: /* @__PURE__ */ jsx(UserCheck, { className: "h-6 w-6" }), title: t("landing.step1.title"), description: t("landing.step1.desc") }),
        /* @__PURE__ */ jsx(StepCard, { number: "2", icon: /* @__PURE__ */ jsx(MapPin, { className: "h-6 w-6" }), title: t("landing.step2.title"), description: t("landing.step2.desc") }),
        /* @__PURE__ */ jsx(StepCard, { number: "3", icon: /* @__PURE__ */ jsx(MessageCircle, { className: "h-6 w-6" }), title: t("landing.step3.title"), description: t("landing.step3.desc") })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "border-t border-border px-4 py-16 sm:py-20", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-5xl", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-center text-3xl font-bold tracking-tight text-foreground", children: t("landing.features.title") }),
      /* @__PURE__ */ jsx("p", { className: "mx-auto mt-3 max-w-lg text-center text-muted-foreground", children: t("landing.features.sub") }),
      /* @__PURE__ */ jsxs("div", { className: "mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3", children: [
        /* @__PURE__ */ jsx(FeatureCard, { icon: /* @__PURE__ */ jsx(ShieldCheck, { className: "h-5 w-5" }), title: t("landing.f.email"), description: t("landing.f.email.desc") }),
        /* @__PURE__ */ jsx(FeatureCard, { icon: /* @__PURE__ */ jsx(Heart, { className: "h-5 w-5" }), title: t("landing.f.smart"), description: t("landing.f.smart.desc") }),
        /* @__PURE__ */ jsx(FeatureCard, { icon: /* @__PURE__ */ jsx(Users, { className: "h-5 w-5" }), title: t("landing.f.twoway"), description: t("landing.f.twoway.desc") }),
        /* @__PURE__ */ jsx(FeatureCard, { icon: /* @__PURE__ */ jsx(MapPin, { className: "h-5 w-5" }), title: t("landing.f.city"), description: t("landing.f.city.desc") }),
        /* @__PURE__ */ jsx(FeatureCard, { icon: /* @__PURE__ */ jsx(MessageCircle, { className: "h-5 w-5" }), title: t("landing.f.chat"), description: t("landing.f.chat.desc") }),
        /* @__PURE__ */ jsx(FeatureCard, { icon: /* @__PURE__ */ jsx(UserCheck, { className: "h-5 w-5" }), title: t("landing.f.profiles"), description: t("landing.f.profiles.desc") })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "border-t border-border px-4 py-16 sm:py-20", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-2xl rounded-3xl p-8 text-center text-primary-foreground sm:p-12", style: {
      backgroundImage: "linear-gradient(135deg, var(--primary), var(--primary-glow))"
    }, children: [
      /* @__PURE__ */ jsx("h2", { className: "text-3xl font-bold tracking-tight sm:text-4xl", children: t("landing.cta.title") }),
      /* @__PURE__ */ jsx("p", { className: "mx-auto mt-4 max-w-md text-primary-foreground/90", children: t("landing.cta.sub") }),
      /* @__PURE__ */ jsx("div", { className: "mt-8 flex flex-wrap items-center justify-center gap-3", children: /* @__PURE__ */ jsxs(Link, { to: "/signup", className: "inline-flex items-center justify-center gap-2 rounded-full bg-primary-foreground px-6 py-3 text-base font-semibold text-primary transition-transform hover:scale-105 active:scale-95", children: [
        t("landing.cta.create"),
        /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsx("footer", { className: "border-t border-border px-4 py-8", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto flex max-w-5xl flex-col items-center justify-between gap-4 sm:flex-row", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx("div", { className: "flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground", children: /* @__PURE__ */ jsx(Heart, { className: "h-3 w-3" }) }),
        /* @__PURE__ */ jsx("span", { className: "text-sm font-semibold", children: "Roomies" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 text-sm text-muted-foreground", children: [
        /* @__PURE__ */ jsx(Link, { to: "/safety", className: "hover:text-foreground", children: t("landing.footer.safety") }),
        /* @__PURE__ */ jsx(Link, { to: "/login", className: "hover:text-foreground", children: t("common.signin") }),
        /* @__PURE__ */ jsx(Link, { to: "/signup", className: "hover:text-foreground", children: t("common.signup") })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: t("landing.footer.rights", {
        year: (/* @__PURE__ */ new Date()).getFullYear()
      }) })
    ] }) })
  ] });
}
function StepCard({
  number,
  icon,
  title,
  description
}) {
  return /* @__PURE__ */ jsxs("div", { className: "relative rounded-2xl border border-border bg-card p-6 text-center", children: [
    /* @__PURE__ */ jsx("div", { className: "absolute -top-3 left-1/2 -translate-x-1/2 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground", children: number }),
    /* @__PURE__ */ jsx("div", { className: "mx-auto mt-3 flex h-10 w-10 items-center justify-center rounded-full bg-accent text-accent-foreground", children: icon }),
    /* @__PURE__ */ jsx("h3", { className: "mt-4 text-lg font-semibold text-foreground", children: title }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: description })
  ] });
}
function FeatureCard({
  icon,
  title,
  description
}) {
  return /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border border-border bg-card p-5", children: [
    /* @__PURE__ */ jsx("div", { className: "flex h-9 w-9 items-center justify-center rounded-full bg-accent text-accent-foreground", children: icon }),
    /* @__PURE__ */ jsx("h3", { className: "mt-4 text-base font-semibold text-foreground", children: title }),
    /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: description })
  ] });
}
export {
  LandingPage as component
};
