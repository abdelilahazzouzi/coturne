import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import * as React from "react";
import { useState, useEffect, useRef } from "react";
import { u as useAuth, b as Route, d as useT } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { B as Button, b as buttonVariants } from "./button-DWfIo_Ug.js";
import * as DropdownMenuPrimitive from "@radix-ui/react-dropdown-menu";
import { ChevronRight, Check, Circle, X, Home, ChevronLeftIcon, ChevronRightIcon, ChevronDownIcon, CalendarIcon, MapPin, CalendarClock, Loader2, FileText, Download, ChevronUp, ChevronDown, CheckCircle2, ArrowLeft, MoreVertical, ShieldAlert, Ban, Paperclip, Send } from "lucide-react";
import { c as cn } from "./utils-H80jjgLf.js";
import { toast } from "sonner";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { cva } from "class-variance-authority";
import { format } from "date-fns";
import { getDefaultClassNames, DayPicker } from "react-day-picker";
import { P as Popover, b as PopoverTrigger, a as PopoverContent } from "./popover-Cx-UuE1R.js";
import { I as Input } from "./input-C0QjszdI.js";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-popover";
const DropdownMenu = DropdownMenuPrimitive.Root;
const DropdownMenuTrigger = DropdownMenuPrimitive.Trigger;
const DropdownMenuSubTrigger = React.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ jsxs(
  DropdownMenuPrimitive.SubTrigger,
  {
    ref,
    className: cn(
      "flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
      inset && "pl-8",
      className
    ),
    ...props,
    children: [
      children,
      /* @__PURE__ */ jsx(ChevronRight, { className: "ml-auto" })
    ]
  }
));
DropdownMenuSubTrigger.displayName = DropdownMenuPrimitive.SubTrigger.displayName;
const DropdownMenuSubContent = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DropdownMenuPrimitive.SubContent,
  {
    ref,
    className: cn(
      "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)",
      className
    ),
    ...props
  }
));
DropdownMenuSubContent.displayName = DropdownMenuPrimitive.SubContent.displayName;
const DropdownMenuContent = React.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ jsx(DropdownMenuPrimitive.Portal, { children: /* @__PURE__ */ jsx(
  DropdownMenuPrimitive.Content,
  {
    ref,
    sideOffset,
    className: cn(
      "z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
      "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)",
      className
    ),
    ...props
  }
) }));
DropdownMenuContent.displayName = DropdownMenuPrimitive.Content.displayName;
const DropdownMenuItem = React.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ jsx(
  DropdownMenuPrimitive.Item,
  {
    ref,
    className: cn(
      "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0",
      inset && "pl-8",
      className
    ),
    ...props
  }
));
DropdownMenuItem.displayName = DropdownMenuPrimitive.Item.displayName;
const DropdownMenuCheckboxItem = React.forwardRef(({ className, children, checked, ...props }, ref) => /* @__PURE__ */ jsxs(
  DropdownMenuPrimitive.CheckboxItem,
  {
    ref,
    className: cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    ),
    checked,
    ...props,
    children: [
      /* @__PURE__ */ jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsx(DropdownMenuPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsx(Check, { className: "h-4 w-4" }) }) }),
      children
    ]
  }
));
DropdownMenuCheckboxItem.displayName = DropdownMenuPrimitive.CheckboxItem.displayName;
const DropdownMenuRadioItem = React.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxs(
  DropdownMenuPrimitive.RadioItem,
  {
    ref,
    className: cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    ),
    ...props,
    children: [
      /* @__PURE__ */ jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsx(DropdownMenuPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsx(Circle, { className: "h-2 w-2 fill-current" }) }) }),
      children
    ]
  }
));
DropdownMenuRadioItem.displayName = DropdownMenuPrimitive.RadioItem.displayName;
const DropdownMenuLabel = React.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ jsx(
  DropdownMenuPrimitive.Label,
  {
    ref,
    className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
    ...props
  }
));
DropdownMenuLabel.displayName = DropdownMenuPrimitive.Label.displayName;
const DropdownMenuSeparator = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DropdownMenuPrimitive.Separator,
  {
    ref,
    className: cn("-mx-1 my-1 h-px bg-muted", className),
    ...props
  }
));
DropdownMenuSeparator.displayName = DropdownMenuPrimitive.Separator.displayName;
const Sheet = DialogPrimitive.Root;
const SheetTrigger = DialogPrimitive.Trigger;
const SheetPortal = DialogPrimitive.Portal;
const SheetOverlay = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DialogPrimitive.Overlay,
  {
    className: cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    ),
    ...props,
    ref
  }
));
SheetOverlay.displayName = DialogPrimitive.Overlay.displayName;
const sheetVariants = cva(
  "fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out",
  {
    variants: {
      side: {
        top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
        bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
        left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
        right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
      }
    },
    defaultVariants: {
      side: "right"
    }
  }
);
const SheetContent = React.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ jsxs(SheetPortal, { children: [
  /* @__PURE__ */ jsx(SheetOverlay, {}),
  /* @__PURE__ */ jsxs(DialogPrimitive.Content, { ref, className: cn(sheetVariants({ side }), className), ...props, children: [
    /* @__PURE__ */ jsxs(DialogPrimitive.Close, { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary", children: [
      /* @__PURE__ */ jsx(X, { className: "h-4 w-4" }),
      /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Close" })
    ] }),
    children
  ] })
] }));
SheetContent.displayName = DialogPrimitive.Content.displayName;
const SheetHeader = ({ className, ...props }) => /* @__PURE__ */ jsx("div", { className: cn("flex flex-col space-y-2 text-center sm:text-left", className), ...props });
SheetHeader.displayName = "SheetHeader";
const SheetTitle = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DialogPrimitive.Title,
  {
    ref,
    className: cn("text-lg font-semibold text-foreground", className),
    ...props
  }
));
SheetTitle.displayName = DialogPrimitive.Title.displayName;
const SheetDescription = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DialogPrimitive.Description,
  {
    ref,
    className: cn("text-sm text-muted-foreground", className),
    ...props
  }
));
SheetDescription.displayName = DialogPrimitive.Description.displayName;
function SharePlaceSheet({
  conversationId,
  trigger
}) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const { data: places, isLoading } = useQuery({
    queryKey: ["my-published-places", user?.id],
    enabled: !!user && open,
    queryFn: async () => {
      const { data, error } = await supabase.from("places").select("id, title, city, rent_monthly, currency, photos").eq("host_id", user.id).eq("status", "published").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    }
  });
  const share = async (p) => {
    if (!user || sending) return;
    setSending(true);
    const { error } = await supabase.from("messages").insert({
      conversation_id: conversationId,
      sender_id: user.id,
      body: p.title,
      kind: "place_ref",
      metadata: {
        place_id: p.id,
        title: p.title,
        city: p.city,
        rent_monthly: p.rent_monthly,
        currency: p.currency,
        photo: p.photos[0] ?? null
      }
    });
    setSending(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setOpen(false);
  };
  return /* @__PURE__ */ jsxs(Sheet, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsx(SheetTrigger, { asChild: true, children: trigger }),
    /* @__PURE__ */ jsxs(SheetContent, { side: "bottom", className: "max-h-[80vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsx(SheetHeader, { children: /* @__PURE__ */ jsx(SheetTitle, { children: "Share a place" }) }),
      /* @__PURE__ */ jsx("div", { className: "mt-4 space-y-2", children: isLoading ? /* @__PURE__ */ jsx("p", { className: "py-6 text-center text-sm text-muted-foreground", children: "Loading…" }) : (places?.length ?? 0) === 0 ? /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-dashed border-border p-6 text-center", children: [
        /* @__PURE__ */ jsx(Home, { className: "mx-auto h-8 w-8 text-muted-foreground" }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "You have no published rooms." }),
        /* @__PURE__ */ jsx(Button, { asChild: true, size: "sm", className: "mt-3", onClick: () => setOpen(false), children: /* @__PURE__ */ jsx(Link, { to: "/places/new", children: "List a room" }) })
      ] }) : places.map((p) => /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => share(p),
          disabled: sending,
          className: "flex w-full items-center gap-3 rounded-lg border border-border p-2 text-left hover:bg-accent",
          children: [
            /* @__PURE__ */ jsx("div", { className: "h-14 w-14 shrink-0 overflow-hidden rounded-md bg-muted", children: p.photos[0] ? /* @__PURE__ */ jsx("img", { src: p.photos[0], alt: p.title, className: "h-full w-full object-cover" }) : null }),
            /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsx("div", { className: "truncate text-sm font-semibold", children: p.title }),
              /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
                p.city,
                " • ",
                p.rent_monthly,
                " ",
                p.currency
              ] })
            ] })
          ]
        },
        p.id
      )) })
    ] })
  ] });
}
function Calendar({
  className,
  classNames,
  showOutsideDays = true,
  captionLayout = "label",
  buttonVariant = "ghost",
  formatters,
  components,
  ...props
}) {
  const defaultClassNames = getDefaultClassNames();
  return /* @__PURE__ */ jsx(
    DayPicker,
    {
      showOutsideDays,
      className: cn(
        "bg-background group/calendar p-3 [--cell-size:2rem] [[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent",
        String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`,
        String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`,
        className
      ),
      captionLayout,
      formatters: {
        formatMonthDropdown: (date) => date.toLocaleString("default", { month: "short" }),
        ...formatters
      },
      classNames: {
        root: cn("w-fit", defaultClassNames.root),
        months: cn("relative flex flex-col gap-4 md:flex-row", defaultClassNames.months),
        month: cn("flex w-full flex-col gap-4", defaultClassNames.month),
        nav: cn(
          "absolute inset-x-0 top-0 flex w-full items-center justify-between gap-1",
          defaultClassNames.nav
        ),
        button_previous: cn(
          buttonVariants({ variant: buttonVariant }),
          "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50",
          defaultClassNames.button_previous
        ),
        button_next: cn(
          buttonVariants({ variant: buttonVariant }),
          "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50",
          defaultClassNames.button_next
        ),
        month_caption: cn(
          "flex h-(--cell-size) w-full items-center justify-center px-(--cell-size)",
          defaultClassNames.month_caption
        ),
        dropdowns: cn(
          "flex h-(--cell-size) w-full items-center justify-center gap-1.5 text-sm font-medium",
          defaultClassNames.dropdowns
        ),
        dropdown_root: cn(
          "has-focus:border-ring border-input shadow-xs has-focus:ring-ring/50 has-focus:ring-[3px] relative rounded-md border",
          defaultClassNames.dropdown_root
        ),
        dropdown: cn("bg-popover absolute inset-0 opacity-0", defaultClassNames.dropdown),
        caption_label: cn(
          "select-none font-medium",
          captionLayout === "label" ? "text-sm" : "[&>svg]:text-muted-foreground flex h-8 items-center gap-1 rounded-md pl-2 pr-1 text-sm [&>svg]:size-3.5",
          defaultClassNames.caption_label
        ),
        table: "w-full border-collapse",
        weekdays: cn("flex", defaultClassNames.weekdays),
        weekday: cn(
          "text-muted-foreground flex-1 select-none rounded-md text-[0.8rem] font-normal",
          defaultClassNames.weekday
        ),
        week: cn("mt-2 flex w-full", defaultClassNames.week),
        week_number_header: cn("w-(--cell-size) select-none", defaultClassNames.week_number_header),
        week_number: cn(
          "text-muted-foreground select-none text-[0.8rem]",
          defaultClassNames.week_number
        ),
        day: cn(
          "group/day relative aspect-square h-full w-full select-none p-0 text-center [&:first-child[data-selected=true]_button]:rounded-l-md [&:last-child[data-selected=true]_button]:rounded-r-md",
          defaultClassNames.day
        ),
        range_start: cn("bg-accent rounded-l-md", defaultClassNames.range_start),
        range_middle: cn("rounded-none", defaultClassNames.range_middle),
        range_end: cn("bg-accent rounded-r-md", defaultClassNames.range_end),
        today: cn(
          "bg-accent text-accent-foreground rounded-md data-[selected=true]:rounded-none",
          defaultClassNames.today
        ),
        outside: cn(
          "text-muted-foreground aria-selected:text-muted-foreground",
          defaultClassNames.outside
        ),
        disabled: cn("text-muted-foreground opacity-50", defaultClassNames.disabled),
        hidden: cn("invisible", defaultClassNames.hidden),
        ...classNames
      },
      components: {
        Root: ({ className: className2, rootRef, ...props2 }) => {
          return /* @__PURE__ */ jsx("div", { "data-slot": "calendar", ref: rootRef, className: cn(className2), ...props2 });
        },
        Chevron: ({ className: className2, orientation, ...props2 }) => {
          if (orientation === "left") {
            return /* @__PURE__ */ jsx(ChevronLeftIcon, { className: cn("size-4", className2), ...props2 });
          }
          if (orientation === "right") {
            return /* @__PURE__ */ jsx(ChevronRightIcon, { className: cn("size-4", className2), ...props2 });
          }
          return /* @__PURE__ */ jsx(ChevronDownIcon, { className: cn("size-4", className2), ...props2 });
        },
        DayButton: CalendarDayButton,
        WeekNumber: ({ children, ...props2 }) => {
          return /* @__PURE__ */ jsx("td", { ...props2, children: /* @__PURE__ */ jsx("div", { className: "flex size-(--cell-size) items-center justify-center text-center", children }) });
        },
        ...components
      },
      ...props
    }
  );
}
function CalendarDayButton({
  className,
  day,
  modifiers,
  ...props
}) {
  const defaultClassNames = getDefaultClassNames();
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (modifiers.focused) ref.current?.focus();
  }, [modifiers.focused]);
  return /* @__PURE__ */ jsx(
    Button,
    {
      ref,
      variant: "ghost",
      size: "icon",
      "data-day": day.date.toLocaleDateString(),
      "data-selected-single": modifiers.selected && !modifiers.range_start && !modifiers.range_end && !modifiers.range_middle,
      "data-range-start": modifiers.range_start,
      "data-range-end": modifiers.range_end,
      "data-range-middle": modifiers.range_middle,
      className: cn(
        "data-[selected-single=true]:bg-primary data-[selected-single=true]:text-primary-foreground data-[range-middle=true]:bg-accent data-[range-middle=true]:text-accent-foreground data-[range-start=true]:bg-primary data-[range-start=true]:text-primary-foreground data-[range-end=true]:bg-primary data-[range-end=true]:text-primary-foreground group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-ring/50 flex aspect-square h-auto w-full min-w-(--cell-size) flex-col gap-1 font-normal leading-none data-[range-end=true]:rounded-md data-[range-middle=true]:rounded-none data-[range-start=true]:rounded-md group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:ring-[3px] [&>span]:text-xs [&>span]:opacity-70",
        defaultClassNames.day,
        className
      ),
      ...props
    }
  );
}
function ProposeViewingSheet({
  conversationId,
  defaultPlaceId,
  trigger
}) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState();
  const [time, setTime] = useState("18:00");
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    if (!user || !date || busy) return;
    setBusy(true);
    const [h, mm] = time.split(":").map((n) => parseInt(n, 10));
    const when = new Date(date);
    when.setHours(h || 0, mm || 0, 0, 0);
    const { data: v, error } = await supabase.from("viewings").insert({
      conversation_id: conversationId,
      place_id: defaultPlaceId ?? null,
      proposed_by: user.id,
      proposed_for: when.toISOString()
    }).select("id").single();
    if (error || !v) {
      setBusy(false);
      toast.error(error?.message ?? "Failed");
      return;
    }
    const { error: mErr } = await supabase.from("messages").insert({
      conversation_id: conversationId,
      sender_id: user.id,
      body: `Proposed a viewing for ${format(when, "PPp")}`,
      kind: "viewing",
      metadata: { viewing_id: v.id, action: "proposed", proposed_for: when.toISOString() }
    });
    setBusy(false);
    if (mErr) {
      toast.error(mErr.message);
      return;
    }
    setOpen(false);
    setDate(void 0);
  };
  const onSubmit = (e) => {
    e.preventDefault();
    if (!date || busy) return;
    submit();
  };
  return /* @__PURE__ */ jsxs(Sheet, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsx(SheetTrigger, { asChild: true, children: trigger }),
    /* @__PURE__ */ jsxs(SheetContent, { side: "bottom", children: [
      /* @__PURE__ */ jsx(SheetHeader, { children: /* @__PURE__ */ jsx(SheetTitle, { children: "Propose a viewing" }) }),
      /* @__PURE__ */ jsxs("form", { onSubmit, className: "mt-5 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx("label", { className: "block text-xs text-muted-foreground", children: "Date" }),
          /* @__PURE__ */ jsxs(Popover, { children: [
            /* @__PURE__ */ jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
              Button,
              {
                type: "button",
                variant: "outline",
                className: cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground"),
                children: [
                  /* @__PURE__ */ jsx(CalendarIcon, { className: "me-2 h-4 w-4" }),
                  date ? format(date, "PPP") : /* @__PURE__ */ jsx("span", { children: "Pick a date" })
                ]
              }
            ) }),
            /* @__PURE__ */ jsx(PopoverContent, { className: "w-auto p-0", align: "start", children: /* @__PURE__ */ jsx(
              Calendar,
              {
                mode: "single",
                selected: date,
                onSelect: setDate,
                disabled: (d) => d < new Date((/* @__PURE__ */ new Date()).setHours(0, 0, 0, 0)),
                initialFocus: true,
                className: cn("p-3 pointer-events-auto")
              }
            ) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx("label", { htmlFor: "pv-time", className: "block text-xs text-muted-foreground", children: "Time" }),
          /* @__PURE__ */ jsx(Input, { id: "pv-time", type: "time", value: time, onChange: (e) => setTime(e.target.value) })
        ] }),
        /* @__PURE__ */ jsx(Button, { type: "submit", className: "w-full", disabled: !date || busy, children: busy ? "Sending…" : "Send proposal" })
      ] })
    ] })
  ] });
}
function PlaceRefBubble({ metadata, mine }) {
  const m = metadata ?? {};
  if (!m.place_id) return /* @__PURE__ */ jsx("span", { className: "text-xs italic opacity-70", children: "Shared a place" });
  return /* @__PURE__ */ jsxs(
    Link,
    {
      to: "/places/$id",
      params: { id: m.place_id },
      className: cn(
        "block w-56 overflow-hidden rounded-lg border",
        mine ? "border-primary-foreground/20 bg-primary-foreground/10" : "border-border bg-background"
      ),
      children: [
        m.photo ? /* @__PURE__ */ jsx("img", { src: m.photo, alt: m.title ?? "", className: "aspect-[4/3] w-full object-cover", loading: "lazy" }) : /* @__PURE__ */ jsx("div", { className: "aspect-[4/3] w-full bg-muted" }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-0.5 p-2", children: [
          /* @__PURE__ */ jsx("div", { className: "truncate text-xs font-semibold", children: m.title ?? "Room" }),
          /* @__PURE__ */ jsxs("div", { className: cn("flex items-center gap-1 text-[11px]", mine ? "opacity-90" : "text-muted-foreground"), children: [
            /* @__PURE__ */ jsx(MapPin, { className: "h-3 w-3" }),
            /* @__PURE__ */ jsx("span", { className: "truncate", children: m.city ?? "" }),
            m.rent_monthly ? /* @__PURE__ */ jsxs("span", { className: "ml-auto font-semibold", children: [
              m.rent_monthly,
              " ",
              m.currency
            ] }) : null
          ] })
        ] })
      ]
    }
  );
}
function ViewingBubble({
  metadata,
  conversationId,
  mine
}) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const m = metadata ?? {};
  const { data: viewing } = useQuery({
    queryKey: ["viewing", m.viewing_id],
    enabled: !!m.viewing_id,
    queryFn: async () => {
      const { data } = await supabase.from("viewings").select("id, proposed_by, proposed_for, status").eq("id", m.viewing_id).maybeSingle();
      return data;
    }
  });
  const respond = async (status2) => {
    if (!viewing || !user) return;
    const { error } = await supabase.from("viewings").update({ status: status2 }).eq("id", viewing.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    const when2 = new Date(viewing.proposed_for);
    const verb = status2 === "accepted" ? "Accepted" : status2 === "declined" ? "Declined" : "Cancelled";
    await supabase.from("messages").insert({
      conversation_id: conversationId,
      sender_id: user.id,
      body: `${verb} viewing for ${format(when2, "PPp")}`,
      kind: "viewing",
      metadata: { viewing_id: viewing.id, action: status2 }
    });
    qc.invalidateQueries({ queryKey: ["viewing", viewing.id] });
  };
  const when = viewing?.proposed_for ?? m.proposed_for;
  const status = viewing?.status ?? m.action ?? "proposed";
  const isProposer = viewing && user && viewing.proposed_by === user.id;
  const showActions = m.action === "proposed" && status === "proposed";
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: cn(
        "w-60 rounded-lg border p-3",
        mine ? "border-primary-foreground/20 bg-primary-foreground/10" : "border-border bg-background text-foreground"
      ),
      children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold", children: [
          /* @__PURE__ */ jsx(CalendarClock, { className: "h-4 w-4" }),
          "Viewing ",
          status !== "proposed" ? `(${status})` : ""
        ] }),
        when && /* @__PURE__ */ jsx("div", { className: "mt-1 text-sm", children: format(new Date(when), "PPp") }),
        showActions && /* @__PURE__ */ jsx("div", { className: "mt-2 flex gap-2", children: isProposer ? /* @__PURE__ */ jsx(Button, { size: "sm", variant: "outline", onClick: () => respond("cancelled"), children: "Cancel" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => respond("accepted"), children: "Accept" }),
          /* @__PURE__ */ jsx(Button, { size: "sm", variant: "outline", onClick: () => respond("declined"), children: "Decline" })
        ] }) })
      ]
    }
  );
}
function AttachmentBubble({ metadata, mine }) {
  const attachment = metadata?.attachment;
  const [url, setUrl] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  useEffect(() => {
    if (!attachment?.path) {
      setLoading(false);
      setError(true);
      return;
    }
    let isMounted = true;
    async function fetchAttachment() {
      try {
        const { data, error: downloadError } = await supabase.storage.from("chat-attachments").download(attachment.path);
        if (downloadError) {
          throw downloadError;
        }
        if (data && isMounted) {
          const objectUrl = URL.createObjectURL(data);
          setUrl(objectUrl);
          setLoading(false);
        }
      } catch (err) {
        console.error("Error downloading chat attachment:", err);
        if (isMounted) {
          setError(true);
          setLoading(false);
        }
      }
    }
    fetchAttachment();
    return () => {
      isMounted = false;
      if (url) {
        URL.revokeObjectURL(url);
      }
    };
  }, [attachment?.path]);
  if (loading) {
    return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 py-3 px-4 rounded-xl bg-muted/20", children: [
      /* @__PURE__ */ jsx(Loader2, { className: "h-4 w-4 animate-spin text-muted-foreground" }),
      /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground font-medium", children: "Loading attachment…" })
    ] });
  }
  if (error || !attachment) {
    return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 py-3 px-4 rounded-xl bg-destructive/10 text-destructive", children: [
      /* @__PURE__ */ jsx(FileText, { className: "h-4 w-4 shrink-0" }),
      /* @__PURE__ */ jsx("span", { className: "text-xs font-medium", children: "Failed to load attachment" })
    ] });
  }
  const isImage = attachment.type?.startsWith("image/");
  if (isImage && url) {
    return /* @__PURE__ */ jsxs("div", { className: "relative group max-w-full rounded-xl overflow-hidden shadow-sm border border-border/30", children: [
      /* @__PURE__ */ jsx(
        "img",
        {
          src: url,
          alt: attachment.name || "Attachment",
          className: "max-h-60 w-full object-cover rounded-xl transition-all duration-200 group-hover:brightness-95 cursor-zoom-in",
          onClick: () => {
            const w = window.open();
            if (w) {
              w.document.write(`<img src="${url}" style="max-width:100%; max-height:100dvh; display:block; margin:auto;" />`);
              w.document.title = attachment.name || "Image Preview";
            }
          }
        }
      ),
      /* @__PURE__ */ jsx(
        "a",
        {
          href: url,
          download: attachment.name,
          className: "absolute bottom-2 right-2 flex h-8 w-8 items-center justify-center rounded-full bg-black/60 text-white opacity-0 transition-opacity duration-200 group-hover:opacity-100 hover:bg-black/80",
          title: "Download image",
          onClick: (e) => e.stopPropagation(),
          children: /* @__PURE__ */ jsx(Download, { className: "h-4 w-4" })
        }
      )
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-4 py-2.5 px-3.5 rounded-xl border border-border/40 bg-card text-card-foreground shadow-sm", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
      /* @__PURE__ */ jsx("div", { className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary", children: /* @__PURE__ */ jsx(FileText, { className: "h-5 w-5" }) }),
      /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
        /* @__PURE__ */ jsx("div", { className: "truncate text-xs font-semibold", children: attachment.name }),
        /* @__PURE__ */ jsx("div", { className: "text-[10px] text-muted-foreground uppercase font-medium mt-0.5", children: attachment.type?.split("/")[1] || "file" })
      ] })
    ] }),
    url && /* @__PURE__ */ jsx(
      "a",
      {
        href: url,
        download: attachment.name,
        className: "flex h-8 w-8 items-center justify-center rounded-full bg-secondary hover:bg-secondary-hover text-secondary-foreground shadow-sm transition-colors shrink-0",
        title: "Download file",
        children: /* @__PURE__ */ jsx(Download, { className: "h-4 w-4" })
      }
    )
  ] });
}
const STEPS = [
  { id: "intro", title: "Introduce yourself", desc: "Share your daily routine, sleep schedule, and expectations." },
  { id: "call", title: "Schedule a virtual meet", desc: "A quick video call ensures you are a good match before meeting in person." },
  { id: "visit", title: "In-person visit", desc: "Check out the apartment together or meet at a cafe." },
  { id: "lease", title: "Review lease terms", desc: "Discuss bills, deposit, and sign the roommate agreement." }
];
function LeaseChecklist() {
  const [open, setOpen] = useState(false);
  const [completed, setCompleted] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("lease-checklist") || "[]");
    } catch {
      return [];
    }
  });
  const toggle = (id) => {
    const next = completed.includes(id) ? completed.filter((x) => x !== id) : [...completed, id];
    setCompleted(next);
    localStorage.setItem("lease-checklist", JSON.stringify(next));
  };
  const progress = Math.round(completed.length / STEPS.length * 100);
  return /* @__PURE__ */ jsxs("div", { className: "border-b border-border bg-accent/20", children: [
    /* @__PURE__ */ jsxs(
      "button",
      {
        onClick: () => setOpen(!open),
        className: "flex w-full items-center justify-between px-4 py-2 text-sm font-medium hover:bg-accent/40",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { children: "Roommate Checklist" }),
            /* @__PURE__ */ jsxs("span", { className: "text-xs text-muted-foreground", children: [
              progress,
              "%"
            ] })
          ] }),
          open ? /* @__PURE__ */ jsx(ChevronUp, { className: "h-4 w-4 text-muted-foreground" }) : /* @__PURE__ */ jsx(ChevronDown, { className: "h-4 w-4 text-muted-foreground" })
        ]
      }
    ),
    open && /* @__PURE__ */ jsxs("div", { className: "px-4 pb-3 pt-1", children: [
      /* @__PURE__ */ jsx("div", { className: "mb-3 h-1.5 w-full overflow-hidden rounded-full bg-secondary", children: /* @__PURE__ */ jsx("div", { className: "h-full bg-primary transition-all", style: { width: `${progress}%` } }) }),
      /* @__PURE__ */ jsx("div", { className: "space-y-2", children: STEPS.map((step) => {
        const isDone = completed.includes(step.id);
        return /* @__PURE__ */ jsxs(
          "div",
          {
            className: cn(
              "flex cursor-pointer gap-3 rounded-md p-2 transition-colors hover:bg-accent/50",
              isDone ? "opacity-60" : ""
            ),
            onClick: () => toggle(step.id),
            children: [
              /* @__PURE__ */ jsx("div", { className: "mt-0.5 shrink-0 text-primary", children: isDone ? /* @__PURE__ */ jsx(CheckCircle2, { className: "h-5 w-5" }) : /* @__PURE__ */ jsx(Circle, { className: "h-5 w-5" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("div", { className: cn("text-sm font-semibold", isDone && "line-through"), children: step.title }),
                /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: step.desc })
              ] })
            ]
          },
          step.id
        );
      }) })
    ] })
  ] });
}
function Chat() {
  const {
    id
  } = Route.useParams();
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const nav = useNavigate();
  const t = useT();
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);
  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };
  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !user || !conversation) return;
    setUploading(true);
    try {
      const fileExt = file.name.split(".").pop();
      const fileName = `${crypto.randomUUID()}.${fileExt}`;
      const filePath = `${id}/${fileName}`;
      const {
        data,
        error: uploadError
      } = await supabase.storage.from("chat-attachments").upload(filePath, file);
      if (uploadError) throw uploadError;
      const {
        error: msgError
      } = await supabase.from("messages").insert({
        conversation_id: id,
        sender_id: user.id,
        body: `Sent an attachment: ${file.name}`,
        metadata: {
          attachment: {
            path: filePath,
            type: file.type,
            name: file.name
          }
        }
      });
      if (msgError) throw msgError;
      toast.success("Attachment sent!");
    } catch (err) {
      console.error("Error uploading file:", err);
      toast.error(err.message || "Failed to upload file");
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };
  const safetyKey = `chat-safety-dismissed:${id}`;
  const [showSafety, setShowSafety] = useState(() => {
    if (typeof window === "undefined") return false;
    return !window.localStorage.getItem(safetyKey);
  });
  const dismissSafety = () => {
    try {
      window.localStorage.setItem(safetyKey, "1");
    } catch {
    }
    setShowSafety(false);
  };
  const scrollRef = useRef(null);
  const {
    data: conversation
  } = useQuery({
    queryKey: ["conversation", id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("conversations").select("id, user_a, user_b").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    }
  });
  const otherId = conversation ? conversation.user_a === user?.id ? conversation.user_b : conversation.user_a : null;
  const {
    data: other
  } = useQuery({
    queryKey: ["profile", otherId],
    enabled: !!otherId,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("profiles").select("id, display_name, photo_url").eq("id", otherId).maybeSingle();
      return data;
    }
  });
  const {
    data: messages
  } = useQuery({
    queryKey: ["messages", id],
    enabled: !!conversation,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("messages").select("*").eq("conversation_id", id).order("created_at", {
        ascending: true
      });
      if (error) throw error;
      return data;
    }
  });
  useEffect(() => {
    if (!conversation) return;
    const channel = supabase.channel(`messages:${id}`).on("postgres_changes", {
      event: "INSERT",
      schema: "public",
      table: "messages",
      filter: `conversation_id=eq.${id}`
    }, (payload) => {
      qc.setQueryData(["messages", id], (old) => {
        const m = payload.new;
        if (old?.some((x) => x.id === m.id)) return old;
        return [...old ?? [], m];
      });
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [conversation, id, qc]);
  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth"
    });
  }, [messages?.length]);
  useEffect(() => {
    if (!messages || !user) return;
    const unread = messages.filter((m) => m.sender_id !== user.id && !m.read_at).map((m) => m.id);
    if (unread.length === 0) return;
    supabase.from("messages").update({
      read_at: (/* @__PURE__ */ new Date()).toISOString()
    }).in("id", unread).then();
  }, [messages, user]);
  const send = async () => {
    const body = text.trim();
    if (!body || !user || !conversation || sending) return;
    setSending(true);
    const {
      error
    } = await supabase.from("messages").insert({
      conversation_id: id,
      sender_id: user.id,
      body
    });
    setSending(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setText("");
  };
  if (!conversation) {
    return /* @__PURE__ */ jsx("div", { className: "p-8 text-center text-muted-foreground", children: t("chat.loading") });
  }
  if (user && conversation.user_a !== user.id && conversation.user_b !== user.id) {
    return /* @__PURE__ */ jsx("div", { className: "p-8 text-center", children: t("chat.access") });
  }
  const blockOther = async () => {
    if (!user || !otherId) return;
    const {
      error
    } = await supabase.from("blocks").insert({
      blocker_id: user.id,
      blocked_id: otherId
    });
    if (error) return toast.error(error.message);
    toast.success(t("pd.blocked"));
    nav({
      to: "/chats"
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto flex h-[calc(100dvh-3.5rem-5rem)] max-w-md flex-col", children: [
    /* @__PURE__ */ jsxs("div", { className: "sticky top-0 z-10 flex items-center gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur", children: [
      /* @__PURE__ */ jsx("button", { onClick: () => nav({
        to: "/chats"
      }), className: "text-muted-foreground hover:text-foreground", "aria-label": t("chat.back"), children: /* @__PURE__ */ jsx(ArrowLeft, { className: "h-5 w-5" }) }),
      other && /* @__PURE__ */ jsxs(Link, { to: "/profile/$id", params: {
        id: other.id
      }, className: "flex flex-1 items-center gap-3", children: [
        /* @__PURE__ */ jsx("div", { className: "h-9 w-9 shrink-0 overflow-hidden rounded-full bg-gradient-to-br from-accent to-primary/40", children: other.photo_url ? /* @__PURE__ */ jsx("img", { src: other.photo_url, alt: other.display_name, className: "h-full w-full object-cover" }) : /* @__PURE__ */ jsx("div", { className: "flex h-full items-center justify-center font-semibold text-primary-foreground", children: other.display_name?.charAt(0)?.toUpperCase() }) }),
        /* @__PURE__ */ jsx("div", { className: "font-semibold", children: other.display_name })
      ] }),
      /* @__PURE__ */ jsxs(DropdownMenu, { children: [
        /* @__PURE__ */ jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsx("button", { className: "text-muted-foreground hover:text-foreground", "aria-label": t("chat.menu"), children: /* @__PURE__ */ jsx(MoreVertical, { className: "h-5 w-5" }) }) }),
        /* @__PURE__ */ jsxs(DropdownMenuContent, { align: "end", children: [
          /* @__PURE__ */ jsx(DropdownMenuItem, { asChild: true, children: /* @__PURE__ */ jsxs(Link, { to: "/safety", children: [
            /* @__PURE__ */ jsx(ShieldAlert, { className: "me-2 h-4 w-4" }),
            " ",
            t("chat.safety")
          ] }) }),
          otherId && /* @__PURE__ */ jsxs(DropdownMenuItem, { onClick: blockOther, className: "text-destructive focus:text-destructive", children: [
            /* @__PURE__ */ jsx(Ban, { className: "me-2 h-4 w-4" }),
            " ",
            t("pd.block")
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx(LeaseChecklist, {}),
    showSafety && /* @__PURE__ */ jsx("div", { className: "border-b border-border bg-accent/30 px-4 py-3 text-sm", children: /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2", children: [
      /* @__PURE__ */ jsx(ShieldAlert, { className: "mt-0.5 h-4 w-4 shrink-0 text-primary" }),
      /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
        /* @__PURE__ */ jsx("div", { className: "font-semibold", children: t("chat.safetyBanner.title") }),
        /* @__PURE__ */ jsx("p", { className: "mt-1 text-muted-foreground", children: t("chat.safetyBanner.body") }),
        /* @__PURE__ */ jsxs("div", { className: "mt-2 flex flex-wrap gap-2", children: [
          /* @__PURE__ */ jsx(Button, { asChild: true, size: "sm", variant: "secondary", className: "h-7 px-3 text-xs", children: /* @__PURE__ */ jsx(Link, { to: "/safety", children: t("chat.safetyBanner.cta") }) }),
          /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", className: "h-7 px-3 text-xs", onClick: dismissSafety, children: t("chat.safetyBanner.dismiss") })
        ] })
      ] }),
      /* @__PURE__ */ jsx("button", { onClick: dismissSafety, className: "text-muted-foreground hover:text-foreground", "aria-label": t("chat.safetyBanner.dismiss"), children: /* @__PURE__ */ jsx(X, { className: "h-4 w-4" }) })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { ref: scrollRef, className: "flex-1 space-y-2 overflow-y-auto px-4 py-4", children: [
      messages?.length === 0 && /* @__PURE__ */ jsx("p", { className: "mt-8 text-center text-sm text-muted-foreground", children: t("chat.sayHi", {
        name: other?.display_name ?? t("chat.match")
      }) }),
      messages?.map((m) => {
        const mine = m.sender_id === user?.id;
        const hasAttachment = !!m.metadata?.attachment;
        const isImage = hasAttachment && m.metadata?.attachment?.type?.startsWith("image/");
        return /* @__PURE__ */ jsx("div", { className: cn("flex", mine ? "justify-end" : "justify-start"), children: /* @__PURE__ */ jsx("div", { className: cn("max-w-[75%] rounded-2xl shadow-sm", isImage ? "" : cn("px-3 py-2 text-sm", mine ? "rounded-br-sm bg-primary text-primary-foreground" : "rounded-bl-sm bg-muted text-foreground")), children: m.kind === "place_ref" ? /* @__PURE__ */ jsx(PlaceRefBubble, { metadata: m.metadata, mine }) : m.kind === "viewing" ? /* @__PURE__ */ jsx(ViewingBubble, { metadata: m.metadata, conversationId: id, mine }) : hasAttachment ? /* @__PURE__ */ jsx(AttachmentBubble, { metadata: m.metadata, mine }) : m.body }) }, m.id);
      })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "sticky bottom-0 z-10 border-t border-border bg-background px-3 py-2", children: /* @__PURE__ */ jsxs("form", { onSubmit: (e) => {
      e.preventDefault();
      send();
    }, className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx(SharePlaceSheet, { conversationId: id, trigger: /* @__PURE__ */ jsx(Button, { type: "button", size: "icon", variant: "ghost", className: "rounded-full", "aria-label": t("chat.share"), children: /* @__PURE__ */ jsx(Home, { className: "h-4 w-4" }) }) }),
      /* @__PURE__ */ jsx(ProposeViewingSheet, { conversationId: id, trigger: /* @__PURE__ */ jsx(Button, { type: "button", size: "icon", variant: "ghost", className: "rounded-full", "aria-label": t("chat.propose"), children: /* @__PURE__ */ jsx(CalendarClock, { className: "h-4 w-4" }) }) }),
      /* @__PURE__ */ jsx(Button, { type: "button", size: "icon", variant: "ghost", className: "rounded-full", "aria-label": "Upload file", onClick: triggerFileUpload, disabled: uploading, children: uploading ? /* @__PURE__ */ jsx(Loader2, { className: "h-4 w-4 animate-spin text-muted-foreground" }) : /* @__PURE__ */ jsx(Paperclip, { className: "h-4 w-4" }) }),
      /* @__PURE__ */ jsx("input", { type: "file", ref: fileInputRef, onChange: handleFileUpload, className: "hidden", accept: "image/*,application/pdf" }),
      /* @__PURE__ */ jsx("input", { value: text, onChange: (e) => setText(e.target.value), placeholder: t("chat.placeholder"), className: "flex-1 rounded-full border border-input bg-background px-4 py-2 text-sm outline-none focus:ring-1 focus:ring-ring", maxLength: 4e3, "aria-label": t("chat.placeholder") }),
      /* @__PURE__ */ jsx(Button, { type: "submit", size: "icon", className: "rounded-full", disabled: !text.trim() || sending, children: /* @__PURE__ */ jsx(Send, { className: "h-4 w-4" }) })
    ] }) })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(Chat, {}) }) });
export {
  SplitComponent as component
};
