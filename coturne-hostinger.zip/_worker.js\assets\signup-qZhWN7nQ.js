import { jsx, jsxs } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { s as supabase } from "./client-BAiQKvvS.js";
import { u as useAuth, d as useT, L as LanguageSwitcher } from "./router-Ds3vjgN6.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { I as Input } from "./input-C0QjszdI.js";
import { L as Label } from "./label-JU3yqRBo.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { toast } from "sonner";
import { Heart } from "lucide-react";
import "@supabase/supabase-js";
import "@tanstack/react-query";
import "@lovable.dev/email-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
function SignupPage() {
  const nav = useNavigate();
  const {
    user,
    loading
  } = useAuth();
  const t = useT();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [signupError, setSignupError] = useState("");
  useEffect(() => {
    if (!loading && user) nav({
      to: "/"
    });
  }, [user, loading, nav]);
  const submit = async (e) => {
    e.preventDefault();
    setSignupError("");
    setBusy(true);
    const {
      error
    } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: window.location.origin,
        data: {
          display_name: name
        }
      }
    });
    setBusy(false);
    if (error) {
      const msg = error.message.toLowerCase().includes("already registered") ? t("auth.emailInUse") : error.message;
      setSignupError(msg);
      toast.error(msg);
      return;
    }
    toast.success(t("auth.createdToast"));
    nav({
      to: "/onboarding"
    });
  };
  return /* @__PURE__ */ jsx("main", { className: "flex min-h-screen items-center justify-center bg-gradient-to-br from-background via-background to-accent/30 p-4 sm:p-6", children: /* @__PURE__ */ jsxs(Card, { className: "w-full max-w-md p-8 sm:p-10", children: [
    /* @__PURE__ */ jsx("div", { className: "mb-4 flex justify-end", children: /* @__PURE__ */ jsx(LanguageSwitcher, {}) }),
    /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-col items-center gap-3 text-center", children: [
      /* @__PURE__ */ jsx("div", { className: "flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground", children: /* @__PURE__ */ jsx(Heart, { className: "h-6 w-6" }) }),
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: t("auth.createTitle") }),
      /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted-foreground", children: t("auth.createEmail") })
    ] }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "name", children: t("auth.firstName") }),
        /* @__PURE__ */ jsx(Input, { id: "name", autoFocus: true, required: true, value: name, onChange: (e) => {
          setName(e.target.value);
          setSignupError("");
        } })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "email", children: t("common.email") }),
        /* @__PURE__ */ jsx(Input, { id: "email", type: "email", required: true, value: email, onChange: (e) => {
          setEmail(e.target.value);
          setSignupError("");
        } })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "password", children: t("common.password") }),
        /* @__PURE__ */ jsx(Input, { id: "password", type: "password", required: true, minLength: 6, value: password, onChange: (e) => {
          setPassword(e.target.value);
          setSignupError("");
        } })
      ] }),
      signupError && /* @__PURE__ */ jsx("div", { className: "rounded-md bg-destructive/15 p-3 text-sm font-medium text-destructive", role: "alert", children: signupError }),
      /* @__PURE__ */ jsx(Button, { type: "submit", variant: "secondary", className: "w-full", disabled: busy, children: busy ? t("auth.creating") : t("auth.createEmail") })
    ] }),
    /* @__PURE__ */ jsxs("p", { className: "mt-6 text-center text-sm text-muted-foreground", children: [
      t("auth.alreadyHave"),
      " ",
      /* @__PURE__ */ jsx(Link, { to: "/login", className: "font-medium text-primary hover:underline", children: t("common.signin") })
    ] })
  ] }) });
}
export {
  SignupPage as component
};
