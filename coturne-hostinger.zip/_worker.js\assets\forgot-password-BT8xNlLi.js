import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { s as supabase } from "./client-BAiQKvvS.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { I as Input } from "./input-C0QjszdI.js";
import { L as Label } from "./label-JU3yqRBo.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { toast } from "sonner";
import { Heart } from "lucide-react";
import { d as useT, L as LanguageSwitcher } from "./router-Ds3vjgN6.js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
import "@tanstack/react-query";
import "@lovable.dev/email-js";
function ForgotPasswordPage() {
  const t = useT();
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const submittedEmail = String(new FormData(form).get("email") ?? "").trim().toLowerCase();
    if (!submittedEmail) {
      toast.error(t("fp.enterEmail"));
      return;
    }
    setBusy(true);
    const {
      error
    } = await supabase.auth.resetPasswordForEmail(submittedEmail, {
      redirectTo: `${window.location.origin}/reset-password`
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setEmail(submittedEmail);
    setSent(true);
    toast.success(t("fp.sent.success"));
  };
  return /* @__PURE__ */ jsx("main", { className: "flex min-h-screen items-center justify-center bg-gradient-to-br from-background via-background to-accent/30 p-4 sm:p-6", children: /* @__PURE__ */ jsxs(Card, { className: "w-full max-w-md p-8 sm:p-10", children: [
    /* @__PURE__ */ jsx("div", { className: "mb-4 flex justify-end", children: /* @__PURE__ */ jsx(LanguageSwitcher, {}) }),
    /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-col items-center gap-3 text-center", children: [
      /* @__PURE__ */ jsx("div", { className: "flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground", children: /* @__PURE__ */ jsx(Heart, { className: "h-6 w-6" }) }),
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: t("fp.title") }),
      /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted-foreground", children: t("fp.sub") })
    ] }),
    sent ? /* @__PURE__ */ jsxs("div", { className: "space-y-3 text-center", children: [
      /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted-foreground", children: t("fp.sent.line1", {
        email
      }) }),
      /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted-foreground", children: t("fp.sent.line2") })
    ] }) : /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "email", children: t("common.email") }),
        /* @__PURE__ */ jsx(Input, { id: "email", name: "email", type: "email", autoFocus: true, required: true, value: email, onChange: (e) => setEmail(e.target.value) })
      ] }),
      /* @__PURE__ */ jsx(Button, { type: "submit", className: "w-full", disabled: busy, children: busy ? t("fp.sending") : t("fp.send") })
    ] }),
    /* @__PURE__ */ jsxs("p", { className: "mt-6 text-center text-sm text-muted-foreground", children: [
      t("fp.remember"),
      " ",
      /* @__PURE__ */ jsx(Link, { to: "/login", className: "font-medium text-primary hover:underline", children: t("fp.back") })
    ] })
  ] }) });
}
export {
  ForgotPasswordPage as component
};
