import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { c as createSsrRpc, u as useServerFn } from "./createSsrRpc-Bq9xzjGt.js";
import { u as useAuth } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { B as Badge } from "./badge-DyfXZgLs.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { ShieldAlert, MapPin, Briefcase, X } from "lucide-react";
import { toast } from "sonner";
import { r as requireSupabaseAuth } from "./auth-middleware-d8RM-K96.js";
import { a as createServerFn } from "./server-qG6n3Utp.js";
import { c as cn } from "./utils-H80jjgLf.js";
import { u as useCities } from "./cities-JYrO-Wlx.js";
import { I as Input } from "./input-C0QjszdI.js";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "class-variance-authority";
import "@radix-ui/react-slot";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "clsx";
import "tailwind-merge";
const decideMinorReview = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => {
  if (!input || typeof input.id !== "string" || typeof input.approve !== "boolean") {
    throw new Response("Bad request", {
      status: 400
    });
  }
  return input;
}).handler(createSsrRpc("49380aad1e4856f1443b65254d4c724c214218137546ce9ab1cadd1cfaf00e87"));
const BANNER_TEXT = {
  EN: {
    text: "Two-factor authentication is strongly recommended for admin accounts. Enroll a TOTP factor from your profile to add a second layer of protection.",
    cta: "Enroll 2FA →"
  },
  FR: {
    text: "L'authentification à deux facteurs est fortement recommandée pour les comptes administrateurs. Activez un facteur TOTP depuis votre profil pour ajouter une couche de protection supplémentaire.",
    cta: "Activer la 2FA →"
  },
  AR: {
    text: "يُنصح بشدة باستخدام المصادقة ثنائية العامل لحسابات المسؤولين. قم بتنشيط عامل TOTP من ملفك الشخصي لإضافة طبقة حماية ثانية.",
    cta: "تفعيل المصادقة ثنائية العامل ←"
  }
};
function Admin() {
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const [isAdmin, setIsAdmin] = useState(null);
  const [bannerLang, setBannerLang] = useState("EN");
  const {
    cities,
    saveCities,
    isSaving
  } = useCities();
  const [newCity, setNewCity] = useState("");
  const handleAddCity = async () => {
    if (!newCity.trim() || !user) return;
    const city = newCity.trim();
    if (cities.includes(city)) return toast.error("City already exists");
    try {
      await saveCities({
        cities: [...cities, city],
        userId: user.id
      });
      setNewCity("");
      toast.success("City added successfully");
    } catch (e) {
      toast.error(e.message || "Failed to add city");
    }
  };
  const handleRemoveCity = async (cityToRemove) => {
    if (!user) return;
    try {
      await saveCities({
        cities: cities.filter((c) => c !== cityToRemove),
        userId: user.id
      });
      toast.success("City removed successfully");
    } catch (e) {
      toast.error(e.message || "Failed to remove city");
    }
  };
  useEffect(() => {
    if (!user) return;
    supabase.from("user_roles").select("role").eq("user_id", user.id).eq("role", "admin").maybeSingle().then(({
      data
    }) => setIsAdmin(!!data));
  }, [user]);
  const {
    data: mfaFactors
  } = useQuery({
    queryKey: ["admin-mfa-factors", user?.id],
    enabled: isAdmin === true,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.auth.mfa.listFactors();
      if (error) throw error;
      return data;
    }
  });
  const has2FA = !!(mfaFactors?.totp && mfaFactors.totp.length > 0);
  const {
    data: reports
  } = useQuery({
    queryKey: ["admin-reports"],
    enabled: isAdmin === true,
    queryFn: async () => {
      const {
        data: rs,
        error
      } = await supabase.from("reports").select("*").order("created_at", {
        ascending: false
      });
      if (error) throw error;
      const ids = Array.from(new Set((rs ?? []).flatMap((r) => [r.reporter_id, r.reported_id])));
      const {
        data: profiles
      } = ids.length ? await supabase.from("profiles").select("id, display_name").in("id", ids) : {
        data: []
      };
      const byId = Object.fromEntries((profiles ?? []).map((p) => [p.id, p.display_name]));
      return (rs ?? []).map((r) => ({
        ...r,
        reporter_name: byId[r.reporter_id] ?? "—",
        reported_name: byId[r.reported_id] ?? "—"
      }));
    }
  });
  const {
    data: minorQueue
  } = useQuery({
    queryKey: ["admin-minor-queue"],
    enabled: isAdmin === true,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("profiles").select("*").eq("review_status", "pending_minor_review").order("created_at", {
        ascending: true
      });
      if (error) throw error;
      return data ?? [];
    }
  });
  const decideFn = useServerFn(decideMinorReview);
  const decide = useMutation({
    mutationFn: async ({
      id,
      approve
    }) => {
      await decideFn({
        data: {
          id,
          approve
        }
      });
    },
    onSuccess: (_d, v) => {
      toast.success(v.approve ? "Profile approved" : "Profile rejected");
      qc.invalidateQueries({
        queryKey: ["admin-minor-queue"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  if (isAdmin === null) return /* @__PURE__ */ jsx("div", { className: "p-8 text-center text-muted-foreground", children: "Checking…" });
  if (!isAdmin) {
    return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md p-6 pt-12 text-center", children: [
      /* @__PURE__ */ jsx(ShieldAlert, { className: "mx-auto h-10 w-10 text-muted-foreground" }),
      /* @__PURE__ */ jsx("h2", { className: "mt-3 text-lg font-semibold", children: "Admins only" }),
      /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "You don't have access to this page." })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-2xl space-y-6 p-4", children: [
    !has2FA && /* @__PURE__ */ jsxs(Card, { className: "relative border-amber-500/20 bg-amber-500/5 dark:bg-amber-500/10 p-5 text-amber-900 dark:text-amber-200", children: [
      /* @__PURE__ */ jsxs("div", { className: "absolute top-3 right-3 flex items-center gap-1.5 text-[10px] font-bold", children: [
        /* @__PURE__ */ jsx("button", { onClick: () => setBannerLang("EN"), className: cn("px-2 py-0.5 rounded transition-colors cursor-pointer", bannerLang === "EN" ? "bg-amber-500/25 text-amber-900 dark:text-amber-200" : "opacity-55 hover:opacity-100"), children: "EN" }),
        /* @__PURE__ */ jsx("button", { onClick: () => setBannerLang("AR"), className: cn("px-2 py-0.5 rounded transition-colors cursor-pointer", bannerLang === "AR" ? "bg-amber-500/25 text-amber-900 dark:text-amber-200" : "opacity-55 hover:opacity-100"), children: "ع" }),
        /* @__PURE__ */ jsx("button", { onClick: () => setBannerLang("FR"), className: cn("px-2 py-0.5 rounded transition-colors cursor-pointer", bannerLang === "FR" ? "bg-amber-500/25 text-amber-900 dark:text-amber-200" : "opacity-55 hover:opacity-100"), children: "FR" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3.5 pr-20", children: [
        /* @__PURE__ */ jsx(ShieldAlert, { className: "h-5 w-5 shrink-0 mt-0.5 text-amber-600 dark:text-amber-400" }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsx("p", { className: "text-sm font-medium leading-relaxed", children: BANNER_TEXT[bannerLang].text }),
          /* @__PURE__ */ jsx(Link, { to: "/profile", className: "inline-block text-sm font-bold text-amber-700 hover:text-amber-800 dark:text-amber-400 dark:hover:text-amber-300 underline underline-offset-4 decoration-2 transition-colors", children: BANNER_TEXT[bannerLang].cta })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "space-y-3", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: "Minor review queue" }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Profiles of users under 18 are held here until you approve or reject them." }),
      (!minorQueue || minorQueue.length === 0) && /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Queue is empty." }),
      minorQueue?.map((p) => /* @__PURE__ */ jsxs(Card, { className: "space-y-2 p-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-baseline gap-2", children: [
              /* @__PURE__ */ jsx("h2", { className: "text-base font-semibold", children: p.display_name || "(no name)" }),
              p.age != null && /* @__PURE__ */ jsxs(Badge, { variant: "secondary", children: [
                "Age ",
                p.age
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "mt-0.5 flex flex-wrap gap-3 text-xs text-muted-foreground", children: [
              p.city && /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
                /* @__PURE__ */ jsx(MapPin, { className: "h-3 w-3" }),
                " ",
                p.city
              ] }),
              p.occupation && /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
                /* @__PURE__ */ jsx(Briefcase, { className: "h-3 w-3" }),
                " ",
                p.occupation
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex shrink-0 gap-2", children: [
            /* @__PURE__ */ jsx(Button, { size: "sm", variant: "outline", onClick: () => decide.mutate({
              id: p.id,
              approve: false
            }), disabled: decide.isPending, children: "Reject" }),
            /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => decide.mutate({
              id: p.id,
              approve: true
            }), disabled: decide.isPending, children: "Approve" })
          ] })
        ] }),
        p.bio && /* @__PURE__ */ jsx("p", { className: "text-sm text-foreground/80", children: p.bio })
      ] }, p.id))
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "space-y-3", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-xl font-semibold tracking-tight", children: "Reports" }),
      (!reports || reports.length === 0) && /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "No reports yet." }),
      reports?.map((r) => /* @__PURE__ */ jsxs(Card, { className: "space-y-2 p-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsx(Badge, { variant: "secondary", children: r.reason }),
          /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: new Date(r.created_at).toLocaleString() })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-sm", children: [
          /* @__PURE__ */ jsx("span", { className: "font-medium", children: r.reporter_name }),
          /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: " reported " }),
          /* @__PURE__ */ jsx("span", { className: "font-medium", children: r.reported_name })
        ] }),
        r.details && /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: r.details })
      ] }, r.id))
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "space-y-3", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-xl font-semibold tracking-tight", children: "Manage Cities" }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Add or remove cities available for selection across the app." }),
      /* @__PURE__ */ jsxs(Card, { className: "p-4 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Input, { placeholder: "e.g. Agadir", value: newCity, onChange: (e) => setNewCity(e.target.value), onKeyDown: (e) => e.key === "Enter" && handleAddCity() }),
          /* @__PURE__ */ jsx(Button, { onClick: handleAddCity, disabled: !newCity.trim() || isSaving, children: "Add City" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2", children: [
          cities.map((city) => /* @__PURE__ */ jsxs(Badge, { variant: "secondary", className: "px-3 py-1 text-sm flex items-center gap-2", children: [
            city,
            /* @__PURE__ */ jsx("button", { onClick: () => handleRemoveCity(city), disabled: isSaving, className: "text-muted-foreground hover:text-foreground hover:bg-muted p-0.5 rounded-full", "aria-label": `Remove ${city}`, children: /* @__PURE__ */ jsx(X, { className: "h-3 w-3" }) })
          ] }, city)),
          cities.length === 0 && /* @__PURE__ */ jsx("span", { className: "text-sm text-muted-foreground", children: "No cities configured." })
        ] })
      ] })
    ] })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { requireOnboarded: false, children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(Admin, {}) }) });
export {
  SplitComponent as component
};
