import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { ShieldCheck } from "lucide-react";
import { d as useT } from "./router-Ds3vjgN6.js";
import "react";
import "@tanstack/react-query";
import "./client-BAiQKvvS.js";
import "@supabase/supabase-js";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "sonner";
import "@lovable.dev/email-js";
function Pending() {
  const t = useT();
  return /* @__PURE__ */ jsx("div", { className: "mx-auto max-w-md p-6 pt-12", children: /* @__PURE__ */ jsxs(Card, { className: "p-6 text-center", children: [
    /* @__PURE__ */ jsx(ShieldCheck, { className: "mx-auto h-10 w-10 text-primary" }),
    /* @__PURE__ */ jsx("h1", { className: "mt-4 text-xl font-semibold", children: t("pending.title") }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: t("pending.body") }),
    /* @__PURE__ */ jsx(Link, { to: "/", className: "mt-4 inline-block text-sm font-medium text-primary hover:underline", children: t("pending.home") })
  ] }) });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { requireOnboarded: false, children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(Pending, {}) }) });
export {
  SplitComponent as component
};
