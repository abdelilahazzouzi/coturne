import { jsxs, jsx } from "react/jsx-runtime";
import * as React from "react";
import * as SliderPrimitive from "@radix-ui/react-slider";
import { c as cn } from "./utils-H80jjgLf.js";
import { Command as Command$1 } from "cmdk";
import { Search } from "lucide-react";
import "./cultural-Cw3GplEn.js";
const Slider = React.forwardRef(({ className, ...props }, ref) => {
  const values = props.value ?? props.defaultValue ?? [0];
  return /* @__PURE__ */ jsxs(
    SliderPrimitive.Root,
    {
      ref,
      className: cn("relative flex w-full touch-none select-none items-center", className),
      ...props,
      children: [
        /* @__PURE__ */ jsx(SliderPrimitive.Track, { className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20", children: /* @__PURE__ */ jsx(SliderPrimitive.Range, { className: "absolute h-full bg-primary" }) }),
        values.map((_, i) => /* @__PURE__ */ jsx(
          SliderPrimitive.Thumb,
          {
            className: "block h-5 w-5 rounded-full border-2 border-primary bg-background shadow-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
          },
          i
        ))
      ]
    }
  );
});
Slider.displayName = SliderPrimitive.Root.displayName;
const Command = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  Command$1,
  {
    ref,
    className: cn(
      "flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground",
      className
    ),
    ...props
  }
));
Command.displayName = Command$1.displayName;
const CommandInput = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxs("div", { className: "flex items-center border-b px-3", "cmdk-input-wrapper": "", children: [
  /* @__PURE__ */ jsx(Search, { className: "mr-2 h-4 w-4 shrink-0 opacity-50" }),
  /* @__PURE__ */ jsx(
    Command$1.Input,
    {
      ref,
      className: cn(
        "flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50",
        className
      ),
      ...props
    }
  )
] }));
CommandInput.displayName = Command$1.Input.displayName;
const CommandList = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  Command$1.List,
  {
    ref,
    className: cn("max-h-[300px] overflow-y-auto overflow-x-hidden", className),
    ...props
  }
));
CommandList.displayName = Command$1.List.displayName;
const CommandEmpty = React.forwardRef((props, ref) => /* @__PURE__ */ jsx(Command$1.Empty, { ref, className: "py-6 text-center text-sm", ...props }));
CommandEmpty.displayName = Command$1.Empty.displayName;
const CommandGroup = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  Command$1.Group,
  {
    ref,
    className: cn(
      "overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground",
      className
    ),
    ...props
  }
));
CommandGroup.displayName = Command$1.Group.displayName;
const CommandSeparator = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  Command$1.Separator,
  {
    ref,
    className: cn("-mx-1 h-px bg-border", className),
    ...props
  }
));
CommandSeparator.displayName = Command$1.Separator.displayName;
const CommandItem = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  Command$1.Item,
  {
    ref,
    className: cn(
      "relative flex cursor-default gap-2 select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
      className
    ),
    ...props
  }
));
CommandItem.displayName = Command$1.Item.displayName;
const NEIGHBORHOODS = {
  Casablanca: [
    { name: "Maarif", coords: { lat: 33.5822, lng: -7.6322 } },
    { name: "Gauthier", coords: { lat: 33.5898, lng: -7.6256 } },
    { name: "Sidi Maarouf", coords: { lat: 33.5358, lng: -7.6433 } },
    { name: "Ain Diab", coords: { lat: 33.5962, lng: -7.6834 } },
    { name: "Oulfa", coords: { lat: 33.558, lng: -7.6745 } },
    { name: "Bourgogne", coords: { lat: 33.5933, lng: -7.645 } },
    { name: "Belvédère", coords: { lat: 33.5956, lng: -7.6033 } },
    { name: "California", coords: { lat: 33.5434, lng: -7.62 } }
  ],
  Rabat: [
    { name: "Agdal", coords: { lat: 33.9984, lng: -6.8483 } },
    { name: "Hay Riad", coords: { lat: 33.9688, lng: -6.8778 } },
    { name: "Hassan", coords: { lat: 34.0205, lng: -6.8285 } },
    { name: "Souissi", coords: { lat: 33.978, lng: -6.829 } },
    { name: "L'Ocean", coords: { lat: 34.026, lng: -6.848 } }
  ],
  Marrakech: [
    { name: "Gueliz", coords: { lat: 31.6348, lng: -8.015 } },
    { name: "Hivernage", coords: { lat: 31.6215, lng: -8.0143 } },
    { name: "Medina", coords: { lat: 31.6295, lng: -7.9811 } },
    { name: "Daoudiate", coords: { lat: 31.6534, lng: -7.9944 } }
  ],
  Tangier: [
    { name: "City Center", coords: { lat: 35.7725, lng: -5.801 } },
    { name: "Malabata", coords: { lat: 35.7798, lng: -5.7765 } },
    { name: "Iberia", coords: { lat: 35.7788, lng: -5.8115 } },
    { name: "Val Fleuri", coords: { lat: 35.768, lng: -5.815 } }
  ]
};
function getCoordinatesForNeighborhood(city, neighborhood) {
  const list = NEIGHBORHOODS[city];
  if (!list) return null;
  const found = list.find((n) => n.name.toLowerCase() === neighborhood.toLowerCase());
  return found ? found.coords : null;
}
function getDistanceInKm(coords1, coords2) {
  const R = 6371;
  const dLat = (coords2.lat - coords1.lat) * Math.PI / 180;
  const dLon = (coords2.lng - coords1.lng) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(coords1.lat * Math.PI / 180) * Math.cos(coords2.lat * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
export {
  Command as C,
  NEIGHBORHOODS as N,
  Slider as S,
  CommandEmpty as a,
  CommandGroup as b,
  CommandInput as c,
  CommandItem as d,
  CommandList as e,
  getDistanceInKm as f,
  getCoordinatesForNeighborhood as g
};
