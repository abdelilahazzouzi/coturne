function canSeePhoto(viewerGender, targetGender) {
  if (targetGender !== "female") return true;
  return viewerGender === "female";
}
function canMatch(viewerGender, targetGender) {
  if (!viewerGender || !targetGender) return false;
  return viewerGender === targetGender;
}
export {
  canSeePhoto as a,
  canMatch as c
};
