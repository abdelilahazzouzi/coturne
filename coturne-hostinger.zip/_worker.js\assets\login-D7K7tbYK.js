import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { s as supabase } from "./client-BAiQKvvS.js";
import { u as useAuth, d as useT, L as LanguageSwitcher } from "./router-Ds3vjgN6.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { I as Input } from "./input-C0QjszdI.js";
import { L as Label } from "./label-JU3yqRBo.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { toast } from "sonner";
import { Heart } from "lucide-react";
import "@supabase/supabase-js";
import "@tanstack/react-query";
import "@lovable.dev/email-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
function LoginPage() {
  const nav = useNavigate();
  const {
    user,
    loading
  } = useAuth();
  const t = useT();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [needsMfa, setNeedsMfa] = useState(false);
  const [mfaCode, setMfaCode] = useState("");
  useEffect(() => {
    if (!loading && user) {
      supabase.auth.mfa.getAuthenticatorAssuranceLevel().then(({
        data
      }) => {
        if (data?.nextLevel === "aal2" && data?.currentLevel === "aal1") {
          setNeedsMfa(true);
        } else {
          nav({
            to: "/"
          });
        }
      });
    }
  }, [user, loading, nav]);
  const submit = async (e) => {
    e.preventDefault();
    setLoginError("");
    if (!password) {
      const msg = t("auth.passwordRequired");
      setLoginError(msg);
      toast.error(msg);
      return;
    }
    setBusy(true);
    const {
      error
    } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    setBusy(false);
    if (error) {
      const msg = t("auth.invalidCredentials");
      setLoginError(msg);
      toast.error(msg);
      return;
    }
  };
  const submitMfa = async (e) => {
    e.preventDefault();
    setBusy(true);
    const {
      data: factors
    } = await supabase.auth.mfa.listFactors();
    const totpFactor = factors?.totp?.[0];
    if (!totpFactor) {
      setBusy(false);
      return toast.error("No TOTP factor found");
    }
    const {
      data: challenge,
      error: challengeErr
    } = await supabase.auth.mfa.challenge({
      factorId: totpFactor.id
    });
    if (challengeErr) {
      setBusy(false);
      return toast.error(challengeErr.message);
    }
    const {
      error: verifyErr
    } = await supabase.auth.mfa.verify({
      factorId: totpFactor.id,
      challengeId: challenge.id,
      code: mfaCode
    });
    setBusy(false);
    if (verifyErr) {
      return toast.error(verifyErr.message);
    }
    nav({
      to: "/"
    });
  };
  return /* @__PURE__ */ jsx("main", { className: "flex min-h-screen items-center justify-center bg-gradient-to-br from-background via-background to-accent/30 p-4 sm:p-6", children: /* @__PURE__ */ jsxs(Card, { className: "w-full max-w-md p-8 sm:p-10", children: [
    /* @__PURE__ */ jsx("div", { className: "mb-4 flex justify-end", children: /* @__PURE__ */ jsx(LanguageSwitcher, {}) }),
    /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-col items-center gap-3 text-center", children: [
      /* @__PURE__ */ jsx("div", { className: "flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground", children: /* @__PURE__ */ jsx(Heart, { className: "h-6 w-6" }) }),
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: t("auth.welcomeBack") }),
      /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted-foreground", children: t("auth.signinEmail") })
    ] }),
    needsMfa ? /* @__PURE__ */ jsxs("form", { onSubmit: submitMfa, className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "mfa", children: "Enter 6-digit code from your authenticator app" }),
        /* @__PURE__ */ jsx(Input, { id: "mfa", type: "text", autoFocus: true, required: true, value: mfaCode, onChange: (e) => setMfaCode(e.target.value.replace(/\D/g, "").slice(0, 6)), className: "text-center text-lg tracking-widest font-mono", placeholder: "000000" })
      ] }),
      /* @__PURE__ */ jsx(Button, { type: "submit", className: "w-full", disabled: busy || mfaCode.length !== 6, children: busy ? "Verifying..." : "Verify" }),
      /* @__PURE__ */ jsx(Button, { type: "button", variant: "ghost", className: "w-full text-xs text-muted-foreground", onClick: () => supabase.auth.signOut(), children: "Cancel and sign out" })
    ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "email", children: t("common.email") }),
          /* @__PURE__ */ jsx(Input, { id: "email", type: "email", autoFocus: true, required: true, value: email, onChange: (e) => {
            setEmail(e.target.value);
            setLoginError("");
          } })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsx(Label, { htmlFor: "password", children: t("common.password") }),
            /* @__PURE__ */ jsx(Link, { to: "/forgot-password", className: "text-xs font-medium text-primary hover:underline", children: t("auth.forgot") })
          ] }),
          /* @__PURE__ */ jsx(Input, { id: "password", type: "password", value: password, onChange: (e) => {
            setPassword(e.target.value);
            setLoginError("");
          } })
        ] }),
        loginError && /* @__PURE__ */ jsx("div", { className: "rounded-md bg-destructive/15 p-3 text-sm font-medium text-destructive", role: "alert", children: loginError }),
        /* @__PURE__ */ jsx(Button, { type: "submit", variant: "secondary", className: "w-full", disabled: busy, children: busy ? t("auth.signingIn") : t("auth.signinEmail") })
      ] }),
      /* @__PURE__ */ jsxs("p", { className: "mt-6 text-center text-sm text-muted-foreground", children: [
        t("auth.newHere"),
        " ",
        /* @__PURE__ */ jsx(Link, { to: "/signup", className: "font-medium text-primary hover:underline", children: t("auth.createAccount") })
      ] })
    ] })
  ] }) });
}
export {
  LoginPage as component
};
