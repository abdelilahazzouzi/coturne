function t(a,n){return n!=="female"?!0:a==="female"}function f(a,n){return!a||!n?!1:a===n}export{t as a,f as c};
