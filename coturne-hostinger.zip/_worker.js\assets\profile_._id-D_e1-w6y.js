import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { R as Route, u as useAuth, d as useT } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { B as Badge } from "./badge-DyfXZgLs.js";
import { g as labelGuests, l as labelAlcohol, h as labelPrayer, f as labelFood, D as Dialog, a as DialogContent, d as DialogHeader, e as DialogTitle, c as DialogFooter } from "./cultural-Cw3GplEn.js";
import { T as Textarea } from "./textarea-DSyJ1nlY.js";
import { S as Select, c as SelectTrigger, d as SelectValue, a as SelectContent, b as SelectItem } from "./select-DPaGlibP.js";
import { PartyPopper, ArrowRight, ArrowLeft, BadgeCheck, MapPin, Briefcase, Check, X, MessageCircle, Flag, Ban } from "lucide-react";
import { a as canSeePhoto } from "./visibility-CyWC4grH.js";
import { a as scoreDetail } from "./matching-4bBZR9XT.js";
import { toast } from "sonner";
import { c as cn } from "./utils-H80jjgLf.js";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-select";
import "clsx";
import "tailwind-merge";
function ProfileDetail() {
  const {
    id
  } = Route.useParams();
  const search = Route.useSearch();
  const {
    user
  } = useAuth();
  const nav = useNavigate();
  const t = useT();
  const [reportOpen, setReportOpen] = useState(false);
  const [reason, setReason] = useState("inappropriate");
  const [details, setDetails] = useState("");
  const isOwner = !!user && user.id === id;
  const showWelcome = isOwner && search.welcome === 1;
  const {
    data: profile,
    isLoading
  } = useQuery({
    queryKey: ["profile", id],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("profiles").select("*, profile_contacts(phone_verified)").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    }
  });
  const {
    data: viewer
  } = useQuery({
    queryKey: ["profile-full", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
      return data;
    }
  });
  const {
    data: isMatched
  } = useQuery({
    queryKey: ["matched", user?.id, id],
    enabled: !!user && !!id && id !== user?.id,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("matches").select("id").or(`and(user_a.eq.${user.id},user_b.eq.${id}),and(user_a.eq.${id},user_b.eq.${user.id})`).maybeSingle();
      return !!data;
    }
  });
  const {
    data: conversationId
  } = useQuery({
    queryKey: ["conversation-for", user?.id, id],
    enabled: !!user && !!id && id !== user?.id && !!isMatched,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("conversations").select("id").or(`and(user_a.eq.${user.id},user_b.eq.${id}),and(user_a.eq.${id},user_b.eq.${user.id})`).maybeSingle();
      return data?.id ?? null;
    }
  });
  const {
    data: contacts
  } = useQuery({
    queryKey: ["profile-contacts", id],
    enabled: !!user && !!id && (isOwner || !!isMatched),
    queryFn: async () => {
      const {
        data
      } = await supabase.from("profile_contacts_view").select("*").eq("user_id", id).maybeSingle();
      return data;
    }
  });
  if (isLoading) return /* @__PURE__ */ jsx("div", { className: "p-8 text-center text-muted-foreground", children: t("chat.loading") });
  if (!profile) return /* @__PURE__ */ jsx("div", { className: "p-8 text-center", children: t("pd.notFound") });
  if (!isOwner && profile.review_status && profile.review_status !== "approved") {
    return /* @__PURE__ */ jsx("div", { className: "p-8 text-center text-muted-foreground", children: t("chat.unavailable") });
  }
  const block = async () => {
    if (!user) return;
    const {
      error
    } = await supabase.from("blocks").insert({
      blocker_id: user.id,
      blocked_id: id
    });
    if (error) return toast.error(error.message);
    toast.success(t("pd.blocked"));
    nav({
      to: "/"
    });
  };
  const submitReport = async () => {
    if (!user) return;
    const {
      error
    } = await supabase.from("reports").insert({
      reporter_id: user.id,
      reported_id: id,
      reason,
      details
    });
    if (error) return toast.error(error.message);
    setReportOpen(false);
    toast.success(t("pd.report.thanks"));
  };
  const tags = [];
  if (profile.smoking) tags.push(profile.smoking === "no" ? "Non-smoker" : profile.smoking === "yes" ? "Smoker" : "Smokes occasionally");
  if (profile.drinking) tags.push(profile.drinking === "no" ? "No alcohol" : profile.drinking === "often" ? "Drinks often" : "Drinks socially");
  if (profile.sleep_schedule) tags.push(profile.sleep_schedule === "early" ? "Early bird" : profile.sleep_schedule === "late" ? "Night owl" : "Flexible sleeper");
  if (profile.social_level) tags.push(profile.social_level === "homebody" ? "Homebody" : profile.social_level === "social" ? "Very social" : "Balanced");
  if (profile.cleanliness != null) tags.push(`Cleanliness ${profile.cleanliness}/5`);
  if (profile.pets) tags.push(profile.pets === "have" ? "Has a pet" : profile.pets === "ok_with" ? "OK with pets" : "No pets");
  const p = profile;
  [labelGuests(p.guests_frequency), labelAlcohol(p.alcohol_in_house), labelPrayer(p.prayer_at_home), labelFood(p.food_sharing)].forEach((l) => {
    if (l) tags.push(l);
  });
  const langs = profile.languages ?? [];
  if (langs.length) tags.push(`Speaks ${langs.join(", ")}`);
  const breakdown = !isOwner && viewer ? scoreDetail(viewer, profile) : null;
  const scoreClass = breakdown && breakdown.score >= 80 ? "bg-emerald-500 text-white" : breakdown && breakdown.score >= 60 ? "bg-amber-500 text-white" : "bg-muted text-foreground";
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md space-y-4 p-4", children: [
    showWelcome ? /* @__PURE__ */ jsx(Card, { className: "border-primary/30 bg-primary/5 p-4", children: /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
      /* @__PURE__ */ jsx("div", { className: "flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground", children: /* @__PURE__ */ jsx(PartyPopper, { className: "h-4 w-4" }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-sm font-semibold text-foreground", children: t("pd.welcome.title") }),
        /* @__PURE__ */ jsx("p", { className: "mt-0.5 text-sm text-muted-foreground", children: t("pd.welcome.sub") }),
        /* @__PURE__ */ jsxs("div", { className: "mt-3 flex flex-wrap gap-2", children: [
          /* @__PURE__ */ jsxs(Link, { to: "/discover", className: "inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90", children: [
            t("pd.welcome.start"),
            " ",
            /* @__PURE__ */ jsx(ArrowRight, { className: "h-3.5 w-3.5" })
          ] }),
          /* @__PURE__ */ jsx(Link, { to: "/profile", className: "inline-flex items-center rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium text-foreground hover:bg-accent", children: t("pd.welcome.edit") })
        ] })
      ] })
    ] }) }) : /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxs("button", { onClick: () => history.back(), className: "flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground", children: [
        /* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }),
        " ",
        t("common.back")
      ] }),
      !isOwner && /* @__PURE__ */ jsx("div", { className: "text-xs font-medium uppercase tracking-wide text-muted-foreground", children: t("pd.viewing", {
        name: profile.display_name
      }) })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "overflow-hidden", children: [
      /* @__PURE__ */ jsxs("div", { className: "relative aspect-[3/4] bg-gradient-to-br from-accent to-primary/30", children: [
        canSeePhoto(isOwner ? profile.gender : viewer?.gender, profile.gender) && profile.photo_url ? /* @__PURE__ */ jsx("img", { src: profile.photo_url, alt: profile.display_name, className: "h-full w-full object-cover" }) : /* @__PURE__ */ jsx("div", { className: "flex h-full items-center justify-center text-6xl font-semibold text-primary-foreground", children: profile.display_name?.charAt(0)?.toUpperCase() }),
        /* @__PURE__ */ jsxs("div", { className: "absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 text-white", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-baseline gap-2", children: [
            /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-semibold flex items-center gap-1.5", children: [
              profile.display_name,
              profile.profile_contacts?.[0]?.phone_verified && /* @__PURE__ */ jsx(BadgeCheck, { className: "h-5 w-5 text-blue-400 fill-blue-400/20", "aria-label": "Verified" })
            ] }),
            profile.age && /* @__PURE__ */ jsx("span", { className: "text-lg", children: profile.age })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-1 flex flex-wrap gap-3 text-sm opacity-90", children: [
            profile.city && /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsx(MapPin, { className: "h-3.5 w-3.5" }),
              " ",
              profile.city
            ] }),
            profile.occupation && /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsx(Briefcase, { className: "h-3.5 w-3.5" }),
              " ",
              profile.occupation
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3 p-4", children: [
        profile.budget_min != null && profile.budget_max != null && /* @__PURE__ */ jsxs("div", { className: "text-sm", children: [
          /* @__PURE__ */ jsx("span", { className: "font-medium", children: t("pd.budget") }),
          " ",
          /* @__PURE__ */ jsxs("span", { className: "text-muted-foreground", children: [
            profile.budget_min,
            " – ",
            profile.budget_max,
            " MAD",
            t("ob.budget.mo")
          ] })
        ] }),
        profile.bio && /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed", children: profile.bio }),
        tags.length > 0 && /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-1.5", children: tags.map((tag) => /* @__PURE__ */ jsx(Badge, { variant: "secondary", className: "font-normal", children: tag }, tag)) })
      ] })
    ] }),
    breakdown && /* @__PURE__ */ jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: cn("flex h-16 w-16 shrink-0 items-center justify-center rounded-full text-lg font-bold shadow", scoreClass), children: [
          breakdown.score,
          "%"
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold", children: t("pd.compat.title") }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: t("pd.compat.sub") })
        ] })
      ] }),
      breakdown.reasons.length > 0 && /* @__PURE__ */ jsx("ul", { className: "mt-4 space-y-1.5", children: breakdown.reasons.map((r, i) => /* @__PURE__ */ jsxs("li", { className: "flex items-start gap-2 text-sm", children: [
        r.ok ? /* @__PURE__ */ jsx(Check, { className: "mt-0.5 h-4 w-4 shrink-0 text-emerald-500" }) : /* @__PURE__ */ jsx(X, { className: "mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" }),
        /* @__PURE__ */ jsx("span", { className: r.ok ? "text-foreground" : "text-muted-foreground", children: r.label })
      ] }, i)) })
    ] }),
    isMatched && /* @__PURE__ */ jsxs(Card, { className: "space-y-3 border-primary/30 bg-primary/5 p-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2", children: [
        /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold text-primary", children: t("pd.matched") }),
        conversationId && /* @__PURE__ */ jsxs(Link, { to: "/chat/$id", params: {
          id: conversationId
        }, className: "inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90", children: [
          /* @__PURE__ */ jsx(MessageCircle, { className: "h-4 w-4" }),
          " ",
          t("pd.message")
        ] })
      ] }),
      contacts?.contact_visible_to_matches !== false ? /* @__PURE__ */ jsxs(Fragment, { children: [
        contacts?.email_contact && /* @__PURE__ */ jsx(ContactRow, { label: t("common.email"), value: contacts.email_contact, href: `mailto:${contacts.email_contact}` }),
        contacts?.phone && contacts?.phone_visible_to_matches && /* @__PURE__ */ jsx(ContactRow, { label: t("common.phone"), value: contacts.phone, href: `tel:${contacts.phone}` }),
        contacts?.contact_handle && /* @__PURE__ */ jsx(ContactRow, { label: t("pd.handle"), value: contacts.contact_handle }),
        !(contacts?.email_contact || contacts?.phone && contacts?.phone_visible_to_matches || contacts?.contact_handle) && /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: t("pd.noContactYet") })
      ] }) : /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: t("pd.privateContacts") })
    ] }),
    user && id !== user.id && /* @__PURE__ */ jsxs(Card, { className: "flex gap-2 p-4", children: [
      /* @__PURE__ */ jsxs(Button, { variant: "outline", className: "flex-1", onClick: () => setReportOpen(true), children: [
        /* @__PURE__ */ jsx(Flag, { className: "me-1 h-4 w-4" }),
        " ",
        t("pd.report")
      ] }),
      /* @__PURE__ */ jsxs(Button, { variant: "outline", className: "flex-1 text-destructive hover:text-destructive", onClick: block, children: [
        /* @__PURE__ */ jsx(Ban, { className: "me-1 h-4 w-4" }),
        " ",
        t("pd.block")
      ] })
    ] }),
    /* @__PURE__ */ jsx(Dialog, { open: reportOpen, onOpenChange: setReportOpen, children: /* @__PURE__ */ jsxs(DialogContent, { children: [
      /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: t("pd.report.title") }) }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxs(Select, { value: reason, onValueChange: setReason, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { "aria-label": t("pd.report.title"), children: /* @__PURE__ */ jsx(SelectValue, {}) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "inappropriate", children: t("pd.report.reason.inappropriate") }),
            /* @__PURE__ */ jsx(SelectItem, { value: "fake", children: t("pd.report.reason.fake") }),
            /* @__PURE__ */ jsx(SelectItem, { value: "harassment", children: t("pd.report.reason.harassment") }),
            /* @__PURE__ */ jsx(SelectItem, { value: "spam", children: t("pd.report.reason.spam") }),
            /* @__PURE__ */ jsx(SelectItem, { value: "other", children: t("pd.report.reason.other") })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Textarea, { rows: 3, placeholder: t("pd.report.details.ph"), value: details, onChange: (e) => setDetails(e.target.value), "aria-label": t("pd.report.details.ph") })
      ] }),
      /* @__PURE__ */ jsxs(DialogFooter, { children: [
        /* @__PURE__ */ jsx(Button, { variant: "outline", onClick: () => setReportOpen(false), children: t("common.cancel") }),
        /* @__PURE__ */ jsx(Button, { onClick: submitReport, children: t("pd.report.submit") })
      ] })
    ] }) })
  ] });
}
function ContactRow({
  label,
  value,
  href
}) {
  const t = useT();
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success(t("common.copied", {
        label
      }));
    } catch {
      toast.error(t("common.copyFail"));
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2 rounded-md border border-border bg-card p-2", children: [
    /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
      /* @__PURE__ */ jsx("div", { className: "text-[10px] font-medium uppercase tracking-wide text-muted-foreground", children: label }),
      href ? /* @__PURE__ */ jsx("a", { href, className: "block truncate font-mono text-sm text-primary hover:underline", children: value }) : /* @__PURE__ */ jsx("div", { className: "truncate font-mono text-sm", children: value })
    ] }),
    /* @__PURE__ */ jsx(Button, { size: "sm", variant: "outline", onClick: copy, children: t("common.copy") })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(ProfileDetail, {}) }) });
export {
  SplitComponent as component
};
