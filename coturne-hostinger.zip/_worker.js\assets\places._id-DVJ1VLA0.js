import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { a as Route, u as useAuth, d as useT } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { ArrowLeft, Pencil, BookmarkCheck, Bookmark, Home, MapPin, Calendar, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-slot";
import "class-variance-authority";
function PlaceDetail() {
  const {
    id
  } = Route.useParams();
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const nav = useNavigate();
  const t = useT();
  const [photoIdx, setPhotoIdx] = useState(0);
  const {
    data: place,
    isLoading
  } = useQuery({
    queryKey: ["place", id],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("places").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    }
  });
  const {
    data: host
  } = useQuery({
    queryKey: ["host", place?.host_id],
    enabled: !!place?.host_id,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("profiles").select("id, display_name, photo_url, city, age").eq("id", place.host_id).maybeSingle();
      return data;
    }
  });
  const {
    data: saved
  } = useQuery({
    queryKey: ["place-save", id, user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("place_saves").select("place_id").eq("place_id", id).eq("user_id", user.id).maybeSingle();
      return !!data;
    }
  });
  const toggleSave = async () => {
    if (!user) return;
    if (saved) {
      await supabase.from("place_saves").delete().eq("place_id", id).eq("user_id", user.id);
    } else {
      await supabase.from("place_saves").insert({
        place_id: id,
        user_id: user.id
      });
    }
    qc.invalidateQueries({
      queryKey: ["place-save", id]
    });
  };
  const messageHost = async () => {
    if (!user || !place) return;
    const {
      data: match
    } = await supabase.from("matches").select("id").or(`and(user_a.eq.${user.id},user_b.eq.${place.host_id}),and(user_a.eq.${place.host_id},user_b.eq.${user.id})`).maybeSingle();
    if (!match) {
      const {
        error
      } = await supabase.from("likes").insert({
        from_user: user.id,
        to_user: place.host_id,
        kind: "like"
      });
      if (error && !error.message.includes("duplicate")) {
        toast.error(error.message);
        return;
      }
      toast.success("Interest sent! You'll be able to chat once they like you back.");
      return;
    }
    const {
      data: convo
    } = await supabase.from("conversations").select("id").eq("match_id", match.id).maybeSingle();
    if (convo) nav({
      to: "/chat/$id",
      params: {
        id: convo.id
      }
    });
  };
  if (isLoading) {
    return /* @__PURE__ */ jsx("div", { className: "p-8 text-center text-muted-foreground", children: "Loading…" });
  }
  if (!place) {
    return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md p-6 text-center", children: [
      /* @__PURE__ */ jsx("p", { children: "Listing not found." }),
      /* @__PURE__ */ jsx(Button, { asChild: true, variant: "link", className: "mt-4", children: /* @__PURE__ */ jsx(Link, { to: "/places", children: "Back to rooms" }) })
    ] });
  }
  const isOwner = user?.id === place.host_id;
  const cover = place.photos[photoIdx] ?? place.photos[0];
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md", children: [
    /* @__PURE__ */ jsxs("div", { className: "sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background/80 px-4 py-3 backdrop-blur", children: [
      /* @__PURE__ */ jsx("button", { onClick: () => nav({
        to: "/places"
      }), className: "text-muted-foreground hover:text-foreground", "aria-label": "Back", children: /* @__PURE__ */ jsx(ArrowLeft, { className: "h-5 w-5" }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        isOwner && /* @__PURE__ */ jsx(Button, { asChild: true, variant: "outline", size: "sm", children: /* @__PURE__ */ jsxs(Link, { to: "/places/$id/edit", params: {
          id: place.id
        }, children: [
          /* @__PURE__ */ jsx(Pencil, { className: "me-1 h-3 w-3" }),
          " Edit"
        ] }) }),
        !isOwner && /* @__PURE__ */ jsx(Button, { onClick: toggleSave, variant: "outline", size: "sm", children: saved ? /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(BookmarkCheck, { className: "me-1 h-4 w-4" }),
          " Saved"
        ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(Bookmark, { className: "me-1 h-4 w-4" }),
          " Save"
        ] }) })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "aspect-[4/3] w-full bg-muted", children: cover ? /* @__PURE__ */ jsx("img", { src: cover, alt: place.title, className: "h-full w-full object-cover" }) : /* @__PURE__ */ jsxs("div", { className: "flex h-full w-full flex-col items-center justify-center gap-2 bg-gradient-to-br from-primary/10 via-accent/20 to-primary/5 text-primary/70", children: [
      /* @__PURE__ */ jsx(Home, { className: "h-12 w-12" }),
      /* @__PURE__ */ jsx("span", { className: "text-xs font-medium uppercase tracking-wide", children: t("place.photosComingSoon") ?? "Photos coming soon" })
    ] }) }),
    place.photos.length > 1 && /* @__PURE__ */ jsx("div", { className: "flex gap-2 overflow-x-auto px-4 py-2", children: place.photos.map((p, i) => /* @__PURE__ */ jsx("button", { onClick: () => setPhotoIdx(i), className: `h-14 w-14 shrink-0 overflow-hidden rounded-md border-2 ${i === photoIdx ? "border-primary" : "border-transparent"}`, children: /* @__PURE__ */ jsx("img", { src: p, alt: "", loading: "lazy", className: "h-full w-full object-cover" }) }, p)) }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-4 p-4", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-baseline justify-between", children: [
          /* @__PURE__ */ jsx("h1", { className: "text-xl font-semibold", children: place.title }),
          /* @__PURE__ */ jsxs("div", { className: "text-lg font-bold text-primary", children: [
            place.rent_monthly,
            " ",
            place.currency,
            /* @__PURE__ */ jsx("span", { className: "text-sm font-normal text-muted-foreground", children: "/mo" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "mt-1 flex items-center gap-1 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsx(MapPin, { className: "h-4 w-4" }),
          place.neighborhood ? `${place.neighborhood}, ` : "",
          place.city
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2 text-xs", children: [
        /* @__PURE__ */ jsxs("span", { className: "rounded-full bg-muted px-2 py-1 capitalize", children: [
          place.room_type,
          " room"
        ] }),
        place.furnished && /* @__PURE__ */ jsx("span", { className: "rounded-full bg-muted px-2 py-1", children: "Furnished" }),
        place.bills_included && /* @__PURE__ */ jsx("span", { className: "rounded-full bg-muted px-2 py-1", children: "Bills included" }),
        place.min_stay_months && /* @__PURE__ */ jsxs("span", { className: "rounded-full bg-muted px-2 py-1", children: [
          "Min ",
          place.min_stay_months,
          " mo"
        ] })
      ] }),
      place.available_from && /* @__PURE__ */ jsxs("p", { className: "flex items-center gap-2 text-sm", children: [
        /* @__PURE__ */ jsx(Calendar, { className: "h-4 w-4 text-muted-foreground" }),
        "Available from ",
        new Date(place.available_from).toLocaleDateString()
      ] }),
      place.description && /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h2", { className: "mb-1 text-sm font-semibold", children: "About this place" }),
        /* @__PURE__ */ jsx("p", { className: "whitespace-pre-wrap text-sm text-muted-foreground", children: place.description })
      ] }),
      host && !isOwner && /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-border p-3", children: [
        /* @__PURE__ */ jsx("h2", { className: "mb-2 text-sm font-semibold", children: "Hosted by" }),
        /* @__PURE__ */ jsxs(Link, { to: "/profile/$id", params: {
          id: host.id
        }, className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx("div", { className: "h-12 w-12 shrink-0 overflow-hidden rounded-full bg-gradient-to-br from-accent to-primary/40", children: host.photo_url ? /* @__PURE__ */ jsx("img", { src: host.photo_url, alt: host.display_name, className: "h-full w-full object-cover" }) : /* @__PURE__ */ jsx("div", { className: "flex h-full items-center justify-center font-semibold text-primary-foreground", children: host.display_name?.charAt(0)?.toUpperCase() }) }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "font-medium", children: [
              host.display_name,
              host.age ? `, ${host.age}` : ""
            ] }),
            /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: host.city })
          ] })
        ] }),
        /* @__PURE__ */ jsxs(Button, { onClick: messageHost, className: "mt-3 w-full", children: [
          /* @__PURE__ */ jsx(MessageCircle, { className: "me-2 h-4 w-4" }),
          " Message host"
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "h-4" })
    ] })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(PlaceDetail, {}) }) });
export {
  SplitComponent as component
};
