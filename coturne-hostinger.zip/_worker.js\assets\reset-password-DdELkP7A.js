import { jsx, jsxs } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { s as supabase } from "./client-BAiQKvvS.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { I as Input } from "./input-C0QjszdI.js";
import { L as Label } from "./label-JU3yqRBo.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { toast } from "sonner";
import { Heart } from "lucide-react";
import { d as useT } from "./router-Ds3vjgN6.js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-label";
import "@tanstack/react-query";
import "@lovable.dev/email-js";
function ResetPasswordPage() {
  const nav = useNavigate();
  const t = useT();
  const [status, setStatus] = useState("loading");
  const [errorMsg, setErrorMsg] = useState(null);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let cancelled = false;
    const markReady = () => {
      if (!cancelled) setStatus("ready");
    };
    const markError = (msg) => {
      if (!cancelled) {
        setErrorMsg(msg);
        setStatus("error");
      }
    };
    const {
      data: {
        subscription
      }
    } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN" && session) markReady();
    });
    const init = async () => {
      const url = new URL(window.location.href);
      const hash = new URLSearchParams(window.location.hash.replace(/^#/, ""));
      const errDesc = url.searchParams.get("error_description") || hash.get("error_description");
      if (errDesc) return markError(errDesc);
      const code = url.searchParams.get("code");
      if (code) {
        const {
          error
        } = await supabase.auth.exchangeCodeForSession(code);
        if (cancelled) return;
        if (error) return markError(error.message);
        window.history.replaceState({}, "", url.pathname);
        return markReady();
      }
      const tokenHash = url.searchParams.get("token_hash");
      const type = url.searchParams.get("type");
      if (tokenHash && type) {
        const {
          error
        } = await supabase.auth.verifyOtp({
          token_hash: tokenHash,
          type
        });
        if (cancelled) return;
        if (error) return markError(error.message);
        window.history.replaceState({}, "", url.pathname);
        return markReady();
      }
      const hasHashTokens = hash.get("access_token") || hash.get("refresh_token") || hash.get("type");
      const deadline = Date.now() + (hasHashTokens ? 5e3 : 1500);
      while (!cancelled && Date.now() < deadline) {
        const {
          data
        } = await supabase.auth.getSession();
        if (data.session) return markReady();
        await new Promise((r) => setTimeout(r, 150));
      }
      if (!cancelled) markError(t("rp.invalid"));
    };
    init();
    return () => {
      cancelled = true;
      subscription.unsubscribe();
    };
  }, []);
  const submit = async (e) => {
    e.preventDefault();
    if (password.length < 6) return toast.error(t("rp.tooShort"));
    if (password !== confirm) return toast.error(t("rp.mismatch"));
    setBusy(true);
    const {
      error
    } = await supabase.auth.updateUser({
      password
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(t("rp.updated"));
    await supabase.auth.signOut();
    nav({
      to: "/login"
    });
  };
  return /* @__PURE__ */ jsx("main", { className: "flex min-h-screen items-center justify-center bg-gradient-to-br from-background via-background to-accent/30 p-4 sm:p-6", children: /* @__PURE__ */ jsxs(Card, { className: "w-full max-w-md p-8 sm:p-10", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-col items-center gap-3 text-center", children: [
      /* @__PURE__ */ jsx("div", { className: "flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground", children: /* @__PURE__ */ jsx(Heart, { className: "h-6 w-6" }) }),
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: t("rp.title") })
    ] }),
    status === "loading" ? /* @__PURE__ */ jsx("p", { className: "text-center text-sm text-muted-foreground", children: t("rp.verifying") }) : status === "error" ? /* @__PURE__ */ jsxs("p", { className: "text-center text-sm leading-relaxed text-muted-foreground", children: [
      errorMsg ?? t("rp.invalid"),
      " ",
      /* @__PURE__ */ jsx(Link, { to: "/forgot-password", className: "font-medium text-primary hover:underline", children: t("rp.requestNew") })
    ] }) : /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "password", children: t("rp.newPwd") }),
        /* @__PURE__ */ jsx(Input, { id: "password", type: "password", autoFocus: true, required: true, value: password, onChange: (e) => setPassword(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "confirm", children: t("rp.confirmPwd") }),
        /* @__PURE__ */ jsx(Input, { id: "confirm", type: "password", required: true, value: confirm, onChange: (e) => setConfirm(e.target.value) })
      ] }),
      /* @__PURE__ */ jsx(Button, { type: "submit", className: "w-full", disabled: busy, children: busy ? t("common.saving") : t("rp.update") })
    ] })
  ] }) });
}
export {
  ResetPasswordPage as component
};
