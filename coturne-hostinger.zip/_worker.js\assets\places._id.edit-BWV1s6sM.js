import { jsx } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { P as PlaceEditor } from "./PlaceEditor-BDs4X3SB.js";
import { c as Route } from "./router-Ds3vjgN6.js";
import "@supabase/supabase-js";
import "@tanstack/react-router";
import "react";
import "lucide-react";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "./button-DWfIo_Ug.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "./input-C0QjszdI.js";
import "./textarea-DSyJ1nlY.js";
import "./label-JU3yqRBo.js";
import "@radix-ui/react-label";
import "./cities-JYrO-Wlx.js";
import "sonner";
import "@lovable.dev/email-js";
function EditPlace() {
  const {
    id
  } = Route.useParams();
  const {
    data,
    isLoading
  } = useQuery({
    queryKey: ["place-edit", id],
    queryFn: async () => {
      const {
        data: data2,
        error
      } = await supabase.from("places").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data2;
    }
  });
  if (isLoading) return /* @__PURE__ */ jsx("p", { className: "p-8 text-center text-muted-foreground", children: "Loading…" });
  if (!data) return /* @__PURE__ */ jsx("p", { className: "p-8 text-center", children: "Not found." });
  const initial = {
    id: data.id,
    title: data.title,
    description: data.description ?? "",
    city: data.city,
    neighborhood: data.neighborhood ?? "",
    rent_monthly: data.rent_monthly,
    currency: data.currency,
    available_from: data.available_from ?? "",
    min_stay_months: data.min_stay_months,
    room_type: data.room_type,
    furnished: data.furnished,
    bills_included: data.bills_included,
    photos: data.photos ?? [],
    status: data.status
  };
  return /* @__PURE__ */ jsx(PlaceEditor, { initial });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(EditPlace, {}) }) });
export {
  SplitComponent as component
};
