import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { u as useAuth, d as useT } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { Heart, MessageCircle } from "lucide-react";
import { a as canSeePhoto } from "./visibility-CyWC4grH.js";
import "react";
import "sonner";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
function Matches() {
  const {
    user
  } = useAuth();
  const t = useT();
  const {
    data,
    isLoading
  } = useQuery({
    queryKey: ["matches", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data: matches,
        error
      } = await supabase.from("matches").select("id, user_a, user_b, created_at").or(`user_a.eq.${user.id},user_b.eq.${user.id}`).order("created_at", {
        ascending: false
      });
      if (error) throw error;
      const otherIds = (matches ?? []).map((m) => m.user_a === user.id ? m.user_b : m.user_a);
      if (otherIds.length === 0) return {
        rows: [],
        viewerGender: null
      };
      const matchIds = (matches ?? []).map((m) => m.id);
      const [{
        data: profiles
      }, {
        data: me
      }, {
        data: convos
      }, {
        data: blocksOut
      }, {
        data: blocksIn
      }] = await Promise.all([supabase.from("profiles").select("*").in("id", otherIds), supabase.from("profiles").select("gender").eq("id", user.id).maybeSingle(), supabase.from("conversations").select("id, match_id").in("match_id", matchIds), supabase.from("blocks").select("blocked_id").eq("blocker_id", user.id), supabase.from("blocks").select("blocker_id").eq("blocked_id", user.id)]);
      const hidden = /* @__PURE__ */ new Set([...(blocksOut ?? []).map((b) => b.blocked_id), ...(blocksIn ?? []).map((b) => b.blocker_id)]);
      const convoByMatch = new Map((convos ?? []).map((c) => [c.match_id, c.id]));
      const rows = (matches ?? []).map((m) => {
        const otherId = m.user_a === user.id ? m.user_b : m.user_a;
        return {
          match: m,
          otherId,
          profile: (profiles ?? []).find((p) => p.id === otherId),
          conversationId: convoByMatch.get(m.id) ?? null
        };
      }).filter((x) => x.profile && !hidden.has(x.otherId) && (!x.profile.review_status || x.profile.review_status === "approved"));
      return {
        rows,
        viewerGender: me?.gender ?? null
      };
    }
  });
  if (isLoading) return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md p-4", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: t("matches.title") }),
    /* @__PURE__ */ jsx("p", { className: "mt-4 text-center text-muted-foreground", children: t("common.loading") })
  ] });
  if (!data || data.rows.length === 0) {
    return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md p-6 pt-12 text-center", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: t("matches.title") }),
      /* @__PURE__ */ jsx(Heart, { className: "mx-auto mt-6 h-12 w-12 text-primary" }),
      /* @__PURE__ */ jsx("h2", { className: "mt-4 text-xl font-semibold", children: t("matches.empty") }),
      /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: t("matches.empty.sub") })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md space-y-3 p-4", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: t("matches.title") }),
    data.rows.map(({
      match,
      profile,
      conversationId
    }) => {
      const showPhoto = canSeePhoto(data.viewerGender, profile.gender);
      return /* @__PURE__ */ jsxs(Card, { className: "flex items-center gap-3 p-3 transition-colors hover:bg-accent/40", children: [
        /* @__PURE__ */ jsxs(Link, { to: "/profile/$id", params: {
          id: profile.id
        }, className: "flex min-w-0 flex-1 items-center gap-3", children: [
          /* @__PURE__ */ jsx("div", { className: "h-14 w-14 shrink-0 overflow-hidden rounded-full bg-gradient-to-br from-accent to-primary/40", children: showPhoto && profile.photo_url ? /* @__PURE__ */ jsx("img", { src: profile.photo_url, alt: profile.display_name, className: "h-full w-full object-cover" }) : /* @__PURE__ */ jsx("div", { className: "flex h-full items-center justify-center text-xl font-semibold text-primary-foreground", children: profile.display_name?.charAt(0)?.toUpperCase() }) }),
          /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxs("div", { className: "font-semibold", children: [
              profile.display_name,
              profile.age ? `, ${profile.age}` : ""
            ] }),
            /* @__PURE__ */ jsx("div", { className: "truncate text-sm text-muted-foreground", children: profile.city ?? "" })
          ] })
        ] }),
        conversationId && /* @__PURE__ */ jsx(Link, { to: "/chat/$id", params: {
          id: conversationId
        }, className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground transition-colors hover:bg-primary/90", "aria-label": t("matches.message", {
          name: profile.display_name
        }), children: /* @__PURE__ */ jsx(MessageCircle, { className: "h-5 w-5" }) })
      ] }, match.id);
    })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(Matches, {}) }) });
export {
  SplitComponent as component
};
