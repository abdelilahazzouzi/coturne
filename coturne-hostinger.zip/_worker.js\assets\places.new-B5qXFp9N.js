import { jsx } from "react/jsx-runtime";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { P as PlaceEditor } from "./PlaceEditor-BDs4X3SB.js";
import "@tanstack/react-router";
import "react";
import "./router-Ds3vjgN6.js";
import "@tanstack/react-query";
import "./client-BAiQKvvS.js";
import "@supabase/supabase-js";
import "sonner";
import "@lovable.dev/email-js";
import "lucide-react";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
import "./button-DWfIo_Ug.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "./input-C0QjszdI.js";
import "./textarea-DSyJ1nlY.js";
import "./label-JU3yqRBo.js";
import "@radix-ui/react-label";
import "./cities-JYrO-Wlx.js";
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(PlaceEditor, {}) }) });
export {
  SplitComponent as component
};
