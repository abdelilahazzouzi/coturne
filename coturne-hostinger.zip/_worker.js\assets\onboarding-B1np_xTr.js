import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useNavigate } from "@tanstack/react-router";
import * as React from "react";
import { useState, useEffect, useId, isValidElement, cloneElement, useCallback, useMemo } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { c as createSsrRpc, u as useServerFn } from "./createSsrRpc-Bq9xzjGt.js";
import { u as useAuth } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { r as requireSupabaseAuth } from "./auth-middleware-d8RM-K96.js";
import { z } from "zod";
import { a as createServerFn } from "./server-qG6n3Utp.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { I as Input } from "./input-C0QjszdI.js";
import { L as Label } from "./label-JU3yqRBo.js";
import { T as Textarea } from "./textarea-DSyJ1nlY.js";
import { C as Card } from "./card-RGlIzTYo.js";
import * as ProgressPrimitive from "@radix-ui/react-progress";
import { c as cn } from "./utils-H80jjgLf.js";
import { S as Select, c as SelectTrigger, d as SelectValue, a as SelectContent, b as SelectItem } from "./select-DPaGlibP.js";
import { N as NEIGHBORHOODS, S as Slider, d as CommandItem, C as Command, c as CommandInput, e as CommandList, a as CommandEmpty, b as CommandGroup, g as getCoordinatesForNeighborhood } from "./neighborhoods-Bw6Dh3u2.js";
import { P as Popover, b as PopoverTrigger, a as PopoverContent } from "./popover-Cx-UuE1R.js";
import { Check, ChevronsUpDown } from "lucide-react";
import { u as useCities } from "./cities-JYrO-Wlx.js";
import { G as GUESTS_OPTIONS, A as ALCOHOL_OPTIONS, P as PRAYER_OPTIONS, F as FOOD_OPTIONS, L as LANGUAGE_OPTIONS } from "./cultural-Cw3GplEn.js";
import { toast } from "sonner";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-label";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-select";
import "@radix-ui/react-slider";
import "cmdk";
import "@radix-ui/react-popover";
import "@radix-ui/react-dialog";
const ProfileSchema = z.object({
  display_name: z.string().min(1).max(120),
  age: z.number().int().min(13).max(120).nullable(),
  gender: z.enum(["female", "male", "nonbinary", "other"]).nullable(),
  occupation: z.string().max(200).optional().default(""),
  city: z.string().max(120).optional().default(""),
  neighborhood: z.string().max(120).nullable().optional(),
  latitude: z.number().nullable().optional(),
  longitude: z.number().nullable().optional(),
  cndp_consent_accepted: z.boolean().optional().default(false),
  budget_min: z.number().int().min(0).max(1e5),
  budget_max: z.number().int().min(0).max(1e5),
  smoking: z.enum(["no", "occasionally", "yes"]).nullable(),
  drinking: z.enum(["no", "socially", "often"]).nullable(),
  sleep_schedule: z.enum(["early", "late", "flexible"]).nullable(),
  social_level: z.enum(["homebody", "balanced", "social"]).nullable(),
  cleanliness: z.number().int().min(1).max(5),
  pets: z.enum(["none", "have", "ok_with"]).nullable(),
  guests_frequency: z.string().max(60).nullable(),
  alcohol_in_house: z.string().max(60).nullable(),
  prayer_at_home: z.string().max(60).nullable(),
  food_sharing: z.string().max(60).nullable(),
  languages: z.array(z.string().min(1).max(60)).max(30),
  bio: z.string().max(2e3).optional().default("")
});
const ContactsSchema = z.object({
  email_contact: z.string().email().max(320).nullable(),
  phone: z.string().max(40).nullable(),
  contact_handle: z.string().max(120).nullable(),
  contact_visible_to_matches: z.boolean()
});
const submitOnboarding = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({
  profile: ProfileSchema,
  contacts: ContactsSchema
}).parse(input)).handler(createSsrRpc("a74e0f785debdb0c1924bcd34fc53aa47ebebc4c3eb27f1e219ce3426cc9b32b"));
const Progress = React.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ jsx(
  ProgressPrimitive.Root,
  {
    ref,
    className: cn("relative h-2 w-full overflow-hidden rounded-full bg-primary/20", className),
    ...props,
    children: /* @__PURE__ */ jsx(
      ProgressPrimitive.Indicator,
      {
        className: "h-full w-full flex-1 bg-primary transition-all",
        style: { transform: `translateX(-${100 - (value || 0)}%)` }
      }
    )
  }
));
Progress.displayName = ProgressPrimitive.Root.displayName;
const STEPS = ["About you", "Where & budget", "Lifestyle", "Cultural fit", "Bio & contact"];
function Onboarding() {
  const {
    user,
    loading
  } = useAuth();
  const nav = useNavigate();
  const queryClient = useQueryClient();
  const submitFn = useServerFn(submitOnboarding);
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    display_name: "",
    age: "",
    gender: "",
    occupation: "",
    city: "",
    neighborhood: "",
    latitude: null,
    longitude: null,
    cndp_consent_accepted: false,
    budget_min: 500,
    budget_max: 1500,
    smoking: "",
    drinking: "",
    sleep_schedule: "",
    social_level: "",
    cleanliness: 3,
    pets: "",
    guests_frequency: "",
    alcohol_in_house: "",
    prayer_at_home: "",
    food_sharing: "",
    languages: [],
    bio: "",
    email_contact: "",
    phone: "",
    contact_handle: "",
    contact_visible_to_matches: true
  });
  useEffect(() => {
    if (!loading && !user) nav({
      to: "/login"
    });
  }, [user, loading, nav]);
  useEffect(() => {
    if (!user) return;
    Promise.all([supabase.from("profiles").select("*").eq("id", user.id).maybeSingle(), supabase.from("profile_contacts").select("*").eq("user_id", user.id).maybeSingle()]).then(([{
      data
    }, {
      data: c
    }]) => {
      setForm((f) => ({
        ...f,
        display_name: data?.display_name || f.display_name,
        bio: data?.bio || f.bio,
        city: data?.city || f.city,
        neighborhood: data?.neighborhood || f.neighborhood,
        latitude: data?.latitude ?? f.latitude,
        longitude: data?.longitude ?? f.longitude,
        cndp_consent_accepted: data?.cndp_consent_accepted ?? f.cndp_consent_accepted,
        email_contact: c?.email_contact || user.email || "",
        phone: c?.phone || "",
        contact_handle: c?.contact_handle || "",
        contact_visible_to_matches: c?.contact_visible_to_matches ?? f.contact_visible_to_matches
      }));
    });
  }, [user]);
  const set = (k, v) => setForm((f) => ({
    ...f,
    [k]: v
  }));
  const stepValid = (s) => {
    if (s === 0) return !!form.display_name.trim() && form.age !== "" && Number(form.age) >= 13 && !!form.gender && !!form.occupation.trim();
    if (s === 1) {
      const cityHasNeighborhoods = form.city in NEIGHBORHOODS;
      if (cityHasNeighborhoods) {
        return !!form.city && !!form.neighborhood;
      }
      return !!form.city;
    }
    if (s === 2) return !!form.smoking && !!form.drinking && !!form.sleep_schedule && !!form.social_level && !!form.pets;
    if (s === 3) return true;
    if (s === 4) return (!!form.email_contact.trim() || !!form.phone.trim()) && form.cndp_consent_accepted;
    return true;
  };
  const handleNeighborhoodChange = (n) => {
    set("neighborhood", n);
    const coords = getCoordinatesForNeighborhood(form.city, n);
    if (coords) {
      set("latitude", coords.lat);
      set("longitude", coords.lng);
    } else {
      set("latitude", null);
      set("longitude", null);
    }
  };
  useCities();
  const next = () => setStep((s) => Math.min(STEPS.length - 1, s + 1));
  const back = () => setStep((s) => Math.max(0, s - 1));
  const submit = async () => {
    if (!user) return;
    setBusy(true);
    const ageNum = form.age === "" ? null : Number(form.age);
    try {
      const res = await submitFn({
        data: {
          profile: {
            display_name: form.display_name,
            age: ageNum,
            gender: form.gender || null,
            occupation: form.occupation,
            city: form.city,
            neighborhood: form.neighborhood || null,
            latitude: form.latitude,
            longitude: form.longitude,
            cndp_consent_accepted: form.cndp_consent_accepted,
            budget_min: form.budget_min,
            budget_max: form.budget_max,
            smoking: form.smoking || null,
            drinking: form.drinking || null,
            sleep_schedule: form.sleep_schedule || null,
            social_level: form.social_level || null,
            cleanliness: form.cleanliness,
            pets: form.pets || null,
            guests_frequency: form.guests_frequency || null,
            alcohol_in_house: form.alcohol_in_house || null,
            prayer_at_home: form.prayer_at_home || null,
            food_sharing: form.food_sharing || null,
            languages: form.languages,
            bio: form.bio
          },
          contacts: {
            email_contact: form.email_contact || null,
            phone: form.phone || null,
            contact_handle: form.contact_handle || null,
            contact_visible_to_matches: form.contact_visible_to_matches
          }
        }
      });
      queryClient.setQueryData(["profile", user.id], (old) => ({
        ...old,
        onboarded: true
      }));
      await queryClient.invalidateQueries({
        queryKey: ["profile", user.id]
      });
      setBusy(false);
      if (res.isMinor) {
        toast.success("Profile submitted for review");
        nav({
          to: "/pending-review"
        });
      } else {
        toast.success("Profile saved!");
        nav({
          to: "/profile/$id",
          params: {
            id: user.id
          },
          search: {
            welcome: 1
          }
        });
      }
    } catch (e) {
      setBusy(false);
      toast.error(e?.message || "Could not save profile");
    }
  };
  if (!user) return null;
  const canContinue = stepValid(step);
  const onSubmit = (e) => {
    e.preventDefault();
    if (!canContinue || busy) return;
    if (step < STEPS.length - 1) next();
    else submit();
  };
  return /* @__PURE__ */ jsx("div", { className: "min-h-screen bg-gradient-to-br from-background via-background to-accent/30 px-4 py-10", children: /* @__PURE__ */ jsxs(Card, { className: "mx-auto max-w-md p-8 sm:p-10", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxs("p", { className: "text-xs font-medium text-muted-foreground", children: [
        "Step ",
        step + 1,
        " of ",
        STEPS.length
      ] }),
      /* @__PURE__ */ jsx("h1", { className: "mt-2 text-2xl font-semibold tracking-tight", children: STEPS[step] }),
      /* @__PURE__ */ jsx(Progress, { className: "mt-4", value: (step + 1) / STEPS.length * 100 })
    ] }),
    /* @__PURE__ */ jsxs("form", { onSubmit, className: "space-y-5", children: [
      step === 0 && /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
        /* @__PURE__ */ jsx(Field, { label: "Display name", children: /* @__PURE__ */ jsx(Input, { autoFocus: true, value: form.display_name, onChange: (e) => set("display_name", e.target.value) }) }),
        /* @__PURE__ */ jsx(Field, { label: "Age", children: /* @__PURE__ */ jsx(Input, { type: "number", min: 18, max: 99, value: form.age, onChange: (e) => set("age", e.target.value === "" ? "" : Number(e.target.value)) }) }),
        /* @__PURE__ */ jsx(Field, { label: "Gender", children: /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(SelectField, { label: "Gender", value: form.gender, onValueChange: (v) => set("gender", v), options: [["female", "Female"], ["male", "Male"], ["nonbinary", "Non-binary"], ["other", "Other"]] }),
          /* @__PURE__ */ jsx("p", { className: "mt-1.5 text-xs text-muted-foreground", children: "Roomies only matches roommates of the same gender. Photos of female members are only visible to other female members." })
        ] }) }),
        /* @__PURE__ */ jsx(Field, { label: "Occupation", children: /* @__PURE__ */ jsx(Input, { value: form.occupation, onChange: (e) => set("occupation", e.target.value), placeholder: "Student, designer, nurse…" }) })
      ] }),
      step === 1 && /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "City" }),
          /* @__PURE__ */ jsx(CityCombobox, { value: form.city, onChange: (v) => {
            set("city", v);
            set("neighborhood", "");
          } })
        ] }),
        form.city in NEIGHBORHOODS && /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Neighborhood" }),
          /* @__PURE__ */ jsxs(Select, { value: form.neighborhood, onValueChange: handleNeighborhoodChange, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { "aria-label": "Neighborhood", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Select a neighborhood…" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: NEIGHBORHOODS[form.city].map((n) => /* @__PURE__ */ jsx(SelectItem, { value: n.name, children: n.name }, n.name)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { className: "mb-3 block", children: "Budget range (per month)" }),
          /* @__PURE__ */ jsxs("div", { className: "mb-3 flex items-center justify-between text-sm", children: [
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "From" }),
            /* @__PURE__ */ jsxs("span", { className: "font-semibold", children: [
              form.budget_min,
              " – ",
              form.budget_max,
              " MAD"
            ] }),
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "/mo" })
          ] }),
          /* @__PURE__ */ jsx(Slider, { min: 100, max: 5e3, step: 50, minStepsBetweenThumbs: 1, value: [form.budget_min, form.budget_max], onValueChange: ([a, b]) => setForm((f) => ({
            ...f,
            budget_min: Math.min(a, b),
            budget_max: Math.max(a, b)
          })) })
        ] })
      ] }),
      step === 2 && /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
        /* @__PURE__ */ jsx(Field, { label: "Smoking", children: /* @__PURE__ */ jsx(SelectField, { label: "Smoking", value: form.smoking, onValueChange: (v) => set("smoking", v), options: [["no", "No"], ["occasionally", "Occasionally"], ["yes", "Yes"]] }) }),
        /* @__PURE__ */ jsx(Field, { label: "Drinking", children: /* @__PURE__ */ jsx(SelectField, { label: "Drinking", value: form.drinking, onValueChange: (v) => set("drinking", v), options: [["no", "No"], ["socially", "Socially"], ["often", "Often"]] }) }),
        /* @__PURE__ */ jsx(Field, { label: "Sleep schedule", children: /* @__PURE__ */ jsx(SelectField, { label: "Sleep schedule", value: form.sleep_schedule, onValueChange: (v) => set("sleep_schedule", v), options: [["early", "Early bird"], ["late", "Night owl"], ["flexible", "Flexible"]] }) }),
        /* @__PURE__ */ jsx(Field, { label: "Social level", children: /* @__PURE__ */ jsx(SelectField, { label: "Social level", value: form.social_level, onValueChange: (v) => set("social_level", v), options: [["homebody", "Homebody"], ["balanced", "Balanced"], ["social", "Very social"]] }) }),
        /* @__PURE__ */ jsx(Field, { label: "Pets", children: /* @__PURE__ */ jsx(SelectField, { label: "Pets", value: form.pets, onValueChange: (v) => set("pets", v), options: [["none", "No pets"], ["have", "I have a pet"], ["ok_with", "OK with pets"]] }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs(Label, { className: "mb-3 block", children: [
            "Cleanliness (",
            form.cleanliness,
            "/5)"
          ] }),
          /* @__PURE__ */ jsx(Slider, { min: 1, max: 5, step: 1, value: [form.cleanliness], onValueChange: ([v]) => set("cleanliness", v) })
        ] })
      ] }),
      step === 3 && /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
        /* @__PURE__ */ jsx("p", { className: "rounded-lg border border-border bg-muted/40 p-3 text-xs text-muted-foreground", children: "All optional, but answering helps us find someone you'd actually live well with." }),
        /* @__PURE__ */ jsx(Field, { label: "Guests at home", children: /* @__PURE__ */ jsx(SelectField, { label: "Guests", value: form.guests_frequency, onValueChange: (v) => set("guests_frequency", v), options: GUESTS_OPTIONS }) }),
        /* @__PURE__ */ jsx(Field, { label: "Alcohol in the house", children: /* @__PURE__ */ jsx(SelectField, { label: "Alcohol", value: form.alcohol_in_house, onValueChange: (v) => set("alcohol_in_house", v), options: ALCOHOL_OPTIONS }) }),
        /* @__PURE__ */ jsx(Field, { label: "Prayer at home", children: /* @__PURE__ */ jsx(SelectField, { label: "Prayer", value: form.prayer_at_home, onValueChange: (v) => set("prayer_at_home", v), options: PRAYER_OPTIONS }) }),
        /* @__PURE__ */ jsx(Field, { label: "Food sharing", children: /* @__PURE__ */ jsx(SelectField, { label: "Food", value: form.food_sharing, onValueChange: (v) => set("food_sharing", v), options: FOOD_OPTIONS }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { className: "mb-2 block", children: "Languages you speak" }),
          /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: LANGUAGE_OPTIONS.map((l) => {
            const active = form.languages.includes(l);
            return /* @__PURE__ */ jsx("button", { type: "button", onClick: () => set("languages", active ? form.languages.filter((x) => x !== l) : [...form.languages, l]), className: cn("rounded-full border px-3 py-1.5 text-xs transition-colors", active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:bg-accent"), children: l }, l);
          }) })
        ] })
      ] }),
      step === 4 && /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
        /* @__PURE__ */ jsx(Field, { label: "Bio", children: /* @__PURE__ */ jsx(Textarea, { rows: 5, value: form.bio, onChange: (e) => set("bio", e.target.value), placeholder: "A few sentences about you and what you're looking for…" }) }),
        /* @__PURE__ */ jsx(Field, { label: "Contact email", children: /* @__PURE__ */ jsx(Input, { type: "email", value: form.email_contact, onChange: (e) => set("email_contact", e.target.value), placeholder: "you@example.com" }) }),
        /* @__PURE__ */ jsx(Field, { label: "Phone (optional)", children: /* @__PURE__ */ jsx(Input, { type: "tel", value: form.phone, onChange: (e) => set("phone", e.target.value), placeholder: "+212 600 000 000" }) }),
        /* @__PURE__ */ jsx(Field, { label: "Other handle (optional)", children: /* @__PURE__ */ jsx(Input, { value: form.contact_handle, onChange: (e) => set("contact_handle", e.target.value), placeholder: "@telegram, WhatsApp, Instagram…" }) }),
        /* @__PURE__ */ jsxs("label", { className: "flex items-start gap-3 rounded-lg border border-border bg-muted/30 p-4 text-sm animate-pulse", children: [
          /* @__PURE__ */ jsx("input", { type: "checkbox", className: "mt-0.5 h-4 w-4 accent-primary", checked: form.contact_visible_to_matches, onChange: (e) => set("contact_visible_to_matches", e.target.checked) }),
          /* @__PURE__ */ jsx("span", { className: "text-muted-foreground text-xs leading-relaxed", children: "Share my contact details with confirmed matches. You can change this any time." })
        ] }),
        /* @__PURE__ */ jsxs("label", { className: "flex items-start gap-3 rounded-lg border border-border bg-muted/30 p-4 text-sm", children: [
          /* @__PURE__ */ jsx("input", { type: "checkbox", className: "mt-0.5 h-4 w-4 accent-primary", checked: form.cndp_consent_accepted, onChange: (e) => set("cndp_consent_accepted", e.target.checked), required: true }),
          /* @__PURE__ */ jsx("span", { className: "text-[11px] leading-relaxed text-muted-foreground", children: "Je consens explicitement au traitement de mes données personnelles (nom, âge, coordonnées) par Roomies, conformément à la loi marocaine 09-08 de la CNDP relative à la protection des personnes physiques à l'égard du traitement des données à caractère personnel." })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "At least one of email or phone is required so matches can reach you." })
      ] }),
      !canContinue && /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Please fill in all fields on this step to continue." }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-3 pt-2", children: [
        step > 0 && /* @__PURE__ */ jsx(Button, { type: "button", variant: "outline", onClick: back, className: "flex-1", children: "Back" }),
        step < STEPS.length - 1 ? /* @__PURE__ */ jsx(Button, { type: "submit", disabled: !canContinue, className: "flex-1", children: "Continue" }) : /* @__PURE__ */ jsx(Button, { type: "submit", disabled: busy || !canContinue, className: "flex-1", children: busy ? "Saving…" : "Finish" })
      ] })
    ] })
  ] }) });
}
function Field({
  label,
  children
}) {
  const id = useId();
  const child = isValidElement(children) ? cloneElement(children, {
    id,
    "aria-label": label
  }) : children;
  return /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
    /* @__PURE__ */ jsx(Label, { htmlFor: id, children: label }),
    child
  ] });
}
function SelectField({
  value,
  onValueChange,
  options,
  label
}) {
  return /* @__PURE__ */ jsxs(Select, { value, onValueChange, children: [
    /* @__PURE__ */ jsx(SelectTrigger, { "aria-label": label, children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Select…" }) }),
    /* @__PURE__ */ jsx(SelectContent, { children: options.map(([v, l]) => /* @__PURE__ */ jsx(SelectItem, { value: v, children: l }, v)) })
  ] });
}
function CityCombobox({
  value,
  onChange
}) {
  const [open, setOpen] = useState(false);
  const {
    cities: dynamicCities
  } = useCities();
  const handleSelect = useCallback((c) => {
    onChange(c);
    setOpen(false);
  }, [onChange]);
  const items = useMemo(() => dynamicCities.map((c) => /* @__PURE__ */ jsxs(CommandItem, { value: c, onSelect: () => handleSelect(c), children: [
    /* @__PURE__ */ jsx(Check, { className: cn("me-2 h-4 w-4", value === c ? "opacity-100" : "opacity-0") }),
    c
  ] }, c)), [value, handleSelect, dynamicCities]);
  return /* @__PURE__ */ jsxs(Popover, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { variant: "outline", role: "combobox", "aria-expanded": open, "aria-label": "City", className: cn("w-full justify-between font-normal", !value && "text-muted-foreground"), children: [
      value || "Select a city…",
      /* @__PURE__ */ jsx(ChevronsUpDown, { className: "ms-2 h-4 w-4 shrink-0 opacity-50" })
    ] }) }),
    /* @__PURE__ */ jsx(PopoverContent, { className: "w-[--radix-popover-trigger-width] p-0", align: "start", children: /* @__PURE__ */ jsxs(Command, { children: [
      /* @__PURE__ */ jsx(CommandInput, { placeholder: "Search city…" }),
      /* @__PURE__ */ jsxs(CommandList, { children: [
        /* @__PURE__ */ jsx(CommandEmpty, { children: "No city found." }),
        /* @__PURE__ */ jsx(CommandGroup, { children: items })
      ] })
    ] }) })
  ] });
}
export {
  Onboarding as component
};
