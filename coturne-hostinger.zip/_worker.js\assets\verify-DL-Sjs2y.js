import { jsx, jsxs } from "react/jsx-runtime";
import { useNavigate } from "@tanstack/react-router";
import * as React from "react";
import { useState, useEffect } from "react";
import { u as useAuth, d as useT } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { I as Input } from "./input-C0QjszdI.js";
import { L as Label } from "./label-JU3yqRBo.js";
import { OTPInput, OTPInputContext } from "input-otp";
import { Minus, Phone, ShieldCheck } from "lucide-react";
import { c as cn } from "./utils-H80jjgLf.js";
import { toast } from "sonner";
import "@tanstack/react-query";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-label";
import "clsx";
import "tailwind-merge";
const InputOTP = React.forwardRef(({ className, containerClassName, ...props }, ref) => /* @__PURE__ */ jsx(
  OTPInput,
  {
    ref,
    containerClassName: cn(
      "flex items-center gap-2 has-[:disabled]:opacity-50",
      containerClassName
    ),
    className: cn("disabled:cursor-not-allowed", className),
    ...props
  }
));
InputOTP.displayName = "InputOTP";
const InputOTPGroup = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx("div", { ref, className: cn("flex items-center", className), ...props }));
InputOTPGroup.displayName = "InputOTPGroup";
const InputOTPSlot = React.forwardRef(({ index, className, ...props }, ref) => {
  const inputOTPContext = React.useContext(OTPInputContext);
  const { char, hasFakeCaret, isActive } = inputOTPContext.slots[index];
  return /* @__PURE__ */ jsxs(
    "div",
    {
      ref,
      className: cn(
        "relative flex h-9 w-9 items-center justify-center border-y border-r border-input text-sm shadow-sm transition-all first:rounded-l-md first:border-l last:rounded-r-md",
        isActive && "z-10 ring-1 ring-ring",
        className
      ),
      ...props,
      children: [
        char,
        hasFakeCaret && /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-0 flex items-center justify-center", children: /* @__PURE__ */ jsx("div", { className: "h-4 w-px animate-caret-blink bg-foreground duration-1000" }) })
      ]
    }
  );
});
InputOTPSlot.displayName = "InputOTPSlot";
const InputOTPSeparator = React.forwardRef(({ ...props }, ref) => /* @__PURE__ */ jsx("div", { ref, role: "separator", ...props, children: /* @__PURE__ */ jsx(Minus, {}) }));
InputOTPSeparator.displayName = "InputOTPSeparator";
function Verify() {
  const {
    user
  } = useAuth();
  const nav = useNavigate();
  const t = useT();
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [stage, setStage] = useState("enter");
  const [busy, setBusy] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  useEffect(() => {
    const storedTime = localStorage.getItem("otp-cooldown-time");
    if (storedTime) {
      const remaining = Math.ceil((Number(storedTime) - Date.now()) / 1e3);
      if (remaining > 0) {
        setCooldown(remaining);
      } else {
        localStorage.removeItem("otp-cooldown-time");
      }
    }
  }, []);
  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown((prev) => {
        if (prev <= 1) {
          localStorage.removeItem("otp-cooldown-time");
          return 0;
        }
        return prev - 1;
      });
    }, 1e3);
    return () => clearInterval(timer);
  }, [cooldown]);
  const sendCode = async () => {
    if (cooldown > 0) return;
    if (!phone.match(/^\+\d{8,15}$/)) {
      return toast.error(t("verify.intl"));
    }
    setBusy(true);
    const {
      error
    } = await supabase.auth.updateUser({
      phone
    });
    setBusy(false);
    let isSimulated = false;
    if (error) {
      const msg = error.message.toLowerCase();
      if (msg.includes("provider") || msg.includes("twilio") || msg.includes("sms")) {
        toast.info("Backend SMS provider not configured. Simulating verification! Use code: 000000", {
          duration: 8e3
        });
        isSimulated = true;
      } else {
        return toast.error(error.message);
      }
    }
    if (isSimulated) {
      window.__SIMULATED_OTP_PHONE__ = phone;
    }
    const expireTime = Date.now() + 60 * 1e3;
    localStorage.setItem("otp-cooldown-time", String(expireTime));
    setCooldown(60);
    toast.success(t("verify.codeSent"));
    setStage("code");
  };
  const verify = async () => {
    if (code.length !== 6) return;
    setBusy(true);
    if (window.__SIMULATED_OTP_PHONE__ === phone && code === "000000") {
      await supabase.from("profile_contacts").upsert({
        user_id: user.id,
        phone,
        phone_verified: true
      }, {
        onConflict: "user_id"
      });
      setBusy(false);
      toast.success(t("verify.verified"));
      nav({
        to: "/"
      });
      return;
    }
    const {
      error
    } = await supabase.auth.verifyOtp({
      phone,
      token: code,
      type: "phone_change"
    });
    if (error) {
      setBusy(false);
      return toast.error(error.message);
    }
    await supabase.from("profile_contacts").upsert({
      user_id: user.id,
      phone,
      phone_verified: true
    }, {
      onConflict: "user_id"
    });
    setBusy(false);
    toast.success(t("verify.verified"));
    nav({
      to: "/"
    });
  };
  return /* @__PURE__ */ jsx("div", { className: "mx-auto max-w-md p-4 sm:p-6", children: /* @__PURE__ */ jsxs(Card, { className: "space-y-6 p-8", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-3 text-center", children: [
      /* @__PURE__ */ jsx("div", { className: "flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground", children: stage === "enter" ? /* @__PURE__ */ jsx(Phone, { className: "h-6 w-6" }) : /* @__PURE__ */ jsx(ShieldCheck, { className: "h-6 w-6" }) }),
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: stage === "enter" ? t("verify.titleEnter") : t("verify.titleCode") }),
      /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-muted-foreground", children: stage === "enter" ? t("verify.subEnter") : t("verify.subCode", {
        phone
      }) })
    ] }),
    stage === "enter" ? /* @__PURE__ */ jsxs("form", { onSubmit: (e) => {
      e.preventDefault();
      if (!busy) sendCode();
    }, className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "phone", children: t("verify.phoneLabel") }),
        /* @__PURE__ */ jsx(Input, { id: "phone", type: "tel", inputMode: "tel", autoFocus: true, placeholder: "+212612345678", value: phone, onChange: (e) => setPhone(e.target.value) })
      ] }),
      /* @__PURE__ */ jsx(Button, { type: "submit", disabled: busy || cooldown > 0, className: "w-full", children: cooldown > 0 ? `Please wait (${cooldown}s)` : busy ? t("verify.sending") : t("verify.sendCode") }),
      /* @__PURE__ */ jsx("button", { type: "button", onClick: () => nav({
        to: "/"
      }), className: "block w-full text-center text-sm text-muted-foreground hover:text-foreground", children: t("verify.skip") })
    ] }) : /* @__PURE__ */ jsxs("form", { onSubmit: (e) => {
      e.preventDefault();
      if (!busy && code.length === 6) verify();
    }, className: "space-y-5", children: [
      /* @__PURE__ */ jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ jsx(InputOTP, { maxLength: 6, value: code, onChange: setCode, autoFocus: true, children: /* @__PURE__ */ jsx(InputOTPGroup, { children: [0, 1, 2, 3, 4, 5].map((i) => /* @__PURE__ */ jsx(InputOTPSlot, { index: i }, i)) }) }) }),
      /* @__PURE__ */ jsx(Button, { type: "submit", disabled: busy || code.length !== 6, className: "w-full", children: busy ? t("verify.verifying") : t("verify.verify") }),
      /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setStage("enter"), className: "block w-full text-center text-sm text-muted-foreground hover:text-foreground", children: t("verify.useOther") })
    ] })
  ] }) });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { requireOnboarded: false, children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(Verify, {}) }) });
export {
  SplitComponent as component
};
