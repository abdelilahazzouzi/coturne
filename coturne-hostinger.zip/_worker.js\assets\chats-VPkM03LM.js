import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { u as useAuth, d as useT } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { MessageCircle } from "lucide-react";
import "react";
import "sonner";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "./utils-H80jjgLf.js";
import "clsx";
import "tailwind-merge";
function Chats() {
  const {
    user
  } = useAuth();
  const t = useT();
  const {
    data,
    isLoading
  } = useQuery({
    queryKey: ["chats", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data: convos,
        error
      } = await supabase.from("conversations").select("id, user_a, user_b, last_message_at").or(`user_a.eq.${user.id},user_b.eq.${user.id}`).order("last_message_at", {
        ascending: false
      });
      if (error) throw error;
      const otherIds = (convos ?? []).map((c) => c.user_a === user.id ? c.user_b : c.user_a);
      if (otherIds.length === 0) return [];
      const [{
        data: profiles
      }, {
        data: lastMsgs
      }, {
        data: unread
      }, {
        data: blocksOut
      }, {
        data: blocksIn
      }] = await Promise.all([supabase.from("profiles").select("id, display_name, photo_url, review_status").in("id", otherIds), supabase.from("messages").select("conversation_id, body, created_at, sender_id").in("conversation_id", (convos ?? []).map((c) => c.id)).order("created_at", {
        ascending: false
      }), supabase.from("messages").select("conversation_id").in("conversation_id", (convos ?? []).map((c) => c.id)).is("read_at", null).neq("sender_id", user.id), supabase.from("blocks").select("blocked_id").eq("blocker_id", user.id), supabase.from("blocks").select("blocker_id").eq("blocked_id", user.id)]);
      const hidden = /* @__PURE__ */ new Set([...(blocksOut ?? []).map((b) => b.blocked_id), ...(blocksIn ?? []).map((b) => b.blocker_id)]);
      const lastByConvo = /* @__PURE__ */ new Map();
      (lastMsgs ?? []).forEach((m) => {
        if (!lastByConvo.has(m.conversation_id)) lastByConvo.set(m.conversation_id, m);
      });
      const unreadCount = /* @__PURE__ */ new Map();
      (unread ?? []).forEach((m) => {
        unreadCount.set(m.conversation_id, (unreadCount.get(m.conversation_id) ?? 0) + 1);
      });
      return (convos ?? []).map((c) => {
        const otherId = c.user_a === user.id ? c.user_b : c.user_a;
        const profile = (profiles ?? []).find((p) => p.id === otherId);
        return {
          id: c.id,
          otherId,
          profile,
          last: lastByConvo.get(c.id),
          unread: unreadCount.get(c.id) ?? 0
        };
      }).filter((x) => x.profile && !hidden.has(x.otherId) && (!x.profile.review_status || x.profile.review_status === "approved"));
    }
  });
  if (isLoading) {
    return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md p-4", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: t("chats.title") }),
      /* @__PURE__ */ jsx("p", { className: "mt-4 text-center text-muted-foreground", children: t("common.loading") })
    ] });
  }
  if (!data || data.length === 0) {
    return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md p-6 pt-12 text-center", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: t("chats.title") }),
      /* @__PURE__ */ jsx(MessageCircle, { className: "mx-auto mt-6 h-12 w-12 text-primary" }),
      /* @__PURE__ */ jsx("h2", { className: "mt-4 text-xl font-semibold", children: t("chats.empty") }),
      /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: t("chats.empty.sub") })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md space-y-3 p-4", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-2xl font-semibold tracking-tight", children: t("chats.title") }),
    data.map((row) => {
      const p = row.profile;
      return /* @__PURE__ */ jsx(Link, { to: "/chat/$id", params: {
        id: row.id
      }, children: /* @__PURE__ */ jsxs(Card, { className: "flex items-center gap-3 p-3 transition-colors hover:bg-accent/40", children: [
        /* @__PURE__ */ jsx("div", { className: "h-12 w-12 shrink-0 overflow-hidden rounded-full bg-gradient-to-br from-accent to-primary/40", children: p.photo_url ? /* @__PURE__ */ jsx("img", { src: p.photo_url, alt: p.display_name, className: "h-full w-full object-cover" }) : /* @__PURE__ */ jsx("div", { className: "flex h-full items-center justify-center font-semibold text-primary-foreground", children: p.display_name?.charAt(0)?.toUpperCase() }) }),
        /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsx("div", { className: "truncate font-semibold", children: p.display_name }),
            row.unread > 0 && /* @__PURE__ */ jsx("span", { className: "rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground", children: row.unread })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "truncate text-sm text-muted-foreground", children: row.last ? row.last.body : t("chats.noMessages") })
        ] })
      ] }) }, row.id);
    })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(Chats, {}) }) });
export {
  SplitComponent as component
};
