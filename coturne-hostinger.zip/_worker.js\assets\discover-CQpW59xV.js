import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { useState, useEffect, useMemo } from "react";
import { u as useAuth, d as useT } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { B as Badge } from "./badge-DyfXZgLs.js";
import { f as getDistanceInKm, S as Slider, C as Command, c as CommandInput, e as CommandList, a as CommandEmpty, b as CommandGroup, d as CommandItem } from "./neighborhoods-Bw6Dh3u2.js";
import { I as Input } from "./input-C0QjszdI.js";
import { L as Label } from "./label-JU3yqRBo.js";
import { P as Popover, b as PopoverTrigger, a as PopoverContent } from "./popover-Cx-UuE1R.js";
import { Crown, Zap, Heart, ShieldCheck, Sparkles, SlidersHorizontal, X, BadgeCheck, MapPin, Briefcase, ChevronsUpDown, Check } from "lucide-react";
import { c as cn } from "./utils-H80jjgLf.js";
import { u as useCities } from "./cities-JYrO-Wlx.js";
import { c as canMatch, a as canSeePhoto } from "./visibility-CyWC4grH.js";
import { s as score } from "./matching-4bBZR9XT.js";
import { D as Dialog, a as DialogContent, e as DialogTitle, b as DialogDescription, c as DialogFooter, g as labelGuests, l as labelAlcohol, h as labelPrayer, f as labelFood } from "./cultural-Cw3GplEn.js";
import { toast } from "sonner";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-slider";
import "cmdk";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
function PaywallModal({ open, onOpenChange, userId }) {
  const [loading, setLoading] = useState(false);
  const qc = useQueryClient();
  const handleUpgrade = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.from("subscriptions").upsert({
        user_id: userId,
        tier: "premium",
        status: "active",
        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3).toISOString()
        // 30 days
      });
      if (error) throw error;
      toast.success("Upgrade successful!", {
        description: "Welcome to Roomies Premium! You now have unlimited swiping."
      });
      qc.invalidateQueries({ queryKey: ["subscription"] });
      qc.invalidateQueries({ queryKey: ["candidates"] });
      onOpenChange(false);
    } catch (err) {
      console.error("Upgrade error:", err);
      toast.error(err.message || "Failed to complete premium upgrade");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsx(Dialog, { open, onOpenChange, children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-md p-0 overflow-hidden border border-border/80 bg-background rounded-2xl shadow-2xl", children: [
    /* @__PURE__ */ jsxs("div", { className: "relative p-6 text-center text-white bg-gradient-to-tr from-violet-600 via-primary to-rose-500 overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-black/10 backdrop-blur-[1px]" }),
      /* @__PURE__ */ jsxs("div", { className: "relative z-10 flex flex-col items-center gap-3", children: [
        /* @__PURE__ */ jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-full bg-white/20 backdrop-blur-md text-yellow-300 animate-pulse border border-white/10", children: /* @__PURE__ */ jsx(Crown, { className: "h-6 w-6", fill: "currentColor" }) }),
        /* @__PURE__ */ jsx(DialogTitle, { className: "text-2xl font-bold tracking-tight text-white", children: "Upgrade to Premium" }),
        /* @__PURE__ */ jsx(DialogDescription, { className: "text-white/90 text-sm max-w-xs mx-auto", children: "You've swiped all your free daily matches. Go premium to keep searching!" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "p-6 space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-border/60 bg-muted/40 p-4 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-0.5", children: [
          /* @__PURE__ */ jsx("div", { className: "text-xs font-semibold text-primary uppercase tracking-wider", children: "Premium Access" }),
          /* @__PURE__ */ jsx("div", { className: "text-sm text-muted-foreground", children: "Monthly Plan" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
          /* @__PURE__ */ jsx("div", { className: "text-2xl font-extrabold text-foreground", children: "49 MAD" }),
          /* @__PURE__ */ jsx("div", { className: "text-[10px] text-muted-foreground", children: "per month" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3.5", children: [
        /* @__PURE__ */ jsx("h3", { className: "text-xs font-bold uppercase tracking-wider text-muted-foreground", children: "What's Included:" }),
        /* @__PURE__ */ jsxs("ul", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxs("li", { className: "flex items-start gap-3 text-sm", children: [
            /* @__PURE__ */ jsx("div", { className: "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary", children: /* @__PURE__ */ jsx(Zap, { className: "h-3 w-3", fill: "currentColor" }) }),
            /* @__PURE__ */ jsxs("span", { children: [
              /* @__PURE__ */ jsx("strong", { children: "Unlimited Swiping:" }),
              " Find the perfect roommate without daily limits."
            ] })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-start gap-3 text-sm", children: [
            /* @__PURE__ */ jsx("div", { className: "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary", children: /* @__PURE__ */ jsx(Heart, { className: "h-3 w-3", fill: "currentColor" }) }),
            /* @__PURE__ */ jsxs("span", { children: [
              /* @__PURE__ */ jsx("strong", { children: "See Who Liked You:" }),
              " Match instantly with roommates seeking your lifestyle."
            ] })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-start gap-3 text-sm", children: [
            /* @__PURE__ */ jsx("div", { className: "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary", children: /* @__PURE__ */ jsx(ShieldCheck, { className: "h-3 w-3", fill: "currentColor" }) }),
            /* @__PURE__ */ jsxs("span", { children: [
              /* @__PURE__ */ jsx("strong", { children: "Verified Premium Badge:" }),
              " Gain trust and attract matches 3x faster."
            ] })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(DialogFooter, { className: "p-6 pt-0 flex flex-col sm:flex-row gap-2", children: [
      /* @__PURE__ */ jsx(
        Button,
        {
          variant: "ghost",
          onClick: () => onOpenChange(false),
          className: "flex-1 rounded-xl text-sm",
          children: "Maybe Later"
        }
      ),
      /* @__PURE__ */ jsx(
        Button,
        {
          onClick: handleUpgrade,
          disabled: loading,
          className: "flex-1 rounded-xl text-sm bg-gradient-to-r from-violet-600 to-rose-500 hover:from-violet-500 hover:to-rose-400 text-white font-semibold shadow-lg shadow-primary/20 border-0",
          children: loading ? /* @__PURE__ */ jsx(Loader2, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
            "Upgrade Now ",
            /* @__PURE__ */ jsx(Sparkles, { className: "ms-1.5 h-4 w-4 fill-white/20" })
          ] })
        }
      )
    ] })
  ] }) });
}
function Loader2({ className }) {
  return /* @__PURE__ */ jsx("div", { className: `h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent ${className}` });
}
const DEFAULT_FILTERS = {
  city: "",
  budget: [0, 5e3],
  ageMin: 18,
  ageMax: 99,
  smoking: [],
  pets: [],
  sleep: [],
  social: [],
  maxDistance: 30
};
function Discover() {
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const t = useT();
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [paywallOpen, setPaywallOpen] = useState(false);
  const {
    data: me
  } = useQuery({
    queryKey: ["profile", user?.id],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("profiles").select("*").eq("id", user.id).single();
      if (error) throw error;
      return data;
    },
    enabled: !!user
  });
  const {
    data: subscription
  } = useQuery({
    queryKey: ["subscription", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("subscriptions").select("tier, status").eq("user_id", user.id).maybeSingle();
      if (error && !error.message.includes("does not exist")) throw error;
      return data ?? {
        tier: "free",
        status: "active"
      };
    }
  });
  const {
    data: swipeCount = 0
  } = useQuery({
    queryKey: ["swipes-24h", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1e3).toISOString();
      const {
        count,
        error
      } = await supabase.from("likes").select("*", {
        count: "exact",
        head: true
      }).eq("from_user", user.id).gte("created_at", yesterday);
      if (error) throw error;
      return count ?? 0;
    }
  });
  useEffect(() => {
    if (!me) return;
    setFilters((f) => ({
      ...f,
      city: f.city || me.city || "",
      budget: [me.budget_min ?? 0, me.budget_max ?? 5e3]
    }));
  }, [me]);
  const filterKey = JSON.stringify(filters);
  const {
    data: candidates,
    isLoading
  } = useQuery({
    queryKey: ["candidates", user?.id, filterKey],
    enabled: !!user && !!me,
    queryFn: async () => {
      const [{
        data: profiles
      }, {
        data: likes
      }, {
        data: blocks
      }] = await Promise.all([supabase.from("profiles").select("*, profile_contacts(phone_verified)").eq("onboarded", true).neq("id", user.id), supabase.from("likes").select("to_user").eq("from_user", user.id), supabase.from("blocks").select("blocked_id").eq("blocker_id", user.id)]);
      const skip = /* @__PURE__ */ new Set([...(likes ?? []).map((l) => l.to_user), ...(blocks ?? []).map((b) => b.blocked_id)]);
      const filtered = (profiles ?? []).filter((p) => !skip.has(p.id));
      const matched = filtered.filter((p) => {
        if (p.review_status && p.review_status !== "approved") return false;
        if (filters.city && p.city && filters.city.trim().toLowerCase() !== p.city.trim().toLowerCase()) return false;
        if (me?.latitude && me?.longitude && p.latitude && p.longitude) {
          const dist = getDistanceInKm({
            lat: me.latitude,
            lng: me.longitude
          }, {
            lat: p.latitude,
            lng: p.longitude
          });
          if (dist > filters.maxDistance) return false;
        }
        const [bMin, bMax] = filters.budget;
        if (p.budget_min != null && p.budget_max != null) {
          if (Math.min(bMax, p.budget_max) < Math.max(bMin, p.budget_min)) return false;
        }
        if (p.age != null && (p.age < filters.ageMin || p.age > filters.ageMax)) return false;
        if (!canMatch(me?.gender, p.gender)) return false;
        if (filters.smoking.length && (!p.smoking || !filters.smoking.includes(p.smoking))) return false;
        if (filters.pets.length && (!p.pets || !filters.pets.includes(p.pets))) return false;
        if (filters.sleep.length && (!p.sleep_schedule || !filters.sleep.includes(p.sleep_schedule))) return false;
        if (filters.social.length && (!p.social_level || !filters.social.includes(p.social_level))) return false;
        return true;
      });
      let myEmbedding = null;
      try {
        if (me?.bio) {
          const {
            AIEmbeddings
          } = await import("./embeddings-C5X3PTss.js");
          myEmbedding = await AIEmbeddings.getEmbedding(me.bio);
        }
      } catch (e) {
        console.error("AI embeddings not available", e);
      }
      const scored = await Promise.all(matched.map(async (p) => {
        let distance = null;
        if (me?.latitude && me?.longitude && p.latitude && p.longitude) {
          distance = getDistanceInKm({
            lat: me.latitude,
            lng: me.longitude
          }, {
            lat: p.latitude,
            lng: p.longitude
          });
        }
        let baseScore = score(me, p);
        if (myEmbedding && p.bio) {
          try {
            const {
              AIEmbeddings
            } = await import("./embeddings-C5X3PTss.js");
            const theirEmbedding = await AIEmbeddings.getEmbedding(p.bio);
            const similarity = AIEmbeddings.cosineSimilarity(myEmbedding, theirEmbedding);
            if (similarity > 0) {
              baseScore = Math.min(100, Math.round(baseScore + similarity * 20));
            }
          } catch (e) {
          }
        }
        return {
          p,
          s: baseScore,
          distance
        };
      }));
      return scored.sort((a, b) => b.s - a.s);
    }
  });
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    setIdx(0);
  }, [filterKey]);
  const stack = candidates ?? [];
  const current = stack[idx];
  const act = useMutation({
    mutationFn: async ({
      to_user,
      kind
    }) => {
      const {
        error
      } = await supabase.from("likes").insert({
        from_user: user.id,
        to_user,
        kind
      });
      if (error) throw error;
      if (kind === "like") {
        const {
          data
        } = await supabase.from("matches").select("id").or(`and(user_a.eq.${user.id},user_b.eq.${to_user}),and(user_a.eq.${to_user},user_b.eq.${user.id})`).maybeSingle();
        return !!data;
      }
      return false;
    },
    onSuccess: (isMatch) => {
      if (isMatch) toast.success(t("disc.match.toast"), {
        description: t("disc.match.toast.sub")
      });
      setIdx((i) => i + 1);
      qc.invalidateQueries({
        queryKey: ["candidates"]
      });
      qc.invalidateQueries({
        queryKey: ["swipes-24h", user?.id]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const handleSwipe = (to_user, kind) => {
    if (subscription?.tier !== "premium" && swipeCount >= 5) {
      setPaywallOpen(true);
      return;
    }
    act.mutate({
      to_user,
      kind
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md p-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-3 flex items-center justify-between", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-lg font-semibold tracking-tight", children: t("disc.title") }),
      /* @__PURE__ */ jsxs(Button, { variant: "outline", size: "sm", onClick: () => setShowFilters((s) => !s), children: [
        /* @__PURE__ */ jsx(SlidersHorizontal, { className: "me-1.5 h-4 w-4" }),
        " ",
        t("disc.filters")
      ] })
    ] }),
    showFilters && /* @__PURE__ */ jsx(FiltersPanel, { filters, onChange: setFilters, onReset: () => setFilters({
      ...DEFAULT_FILTERS,
      city: me?.city ?? "",
      budget: [me?.budget_min ?? 0, me?.budget_max ?? 5e3]
    }), me }),
    isLoading ? /* @__PURE__ */ jsx(Loader, {}) : !current ? /* @__PURE__ */ jsxs("div", { className: "p-6 pt-12 text-center", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-xl font-semibold", children: t("disc.allCaught") }),
      /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: t("disc.allCaught.sub") }),
      /* @__PURE__ */ jsx(Button, { variant: "outline", className: "mt-4", onClick: () => setFilters(DEFAULT_FILTERS), children: t("disc.loosen") })
    ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(CandidateCard, { profile: current.p, score: current.s, distance: current.distance, viewerGender: me?.gender }),
      subscription?.tier !== "premium" && swipeCount >= 5 && /* @__PURE__ */ jsxs("div", { className: "mt-4 flex items-center justify-between rounded-xl border border-yellow-500/30 bg-yellow-500/5 p-3 text-xs text-yellow-600 dark:text-yellow-500", children: [
        /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1.5 font-medium", children: [
          /* @__PURE__ */ jsx(Crown, { className: "h-4 w-4" }),
          " Daily limit reached (",
          swipeCount,
          "/5)"
        ] }),
        /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", className: "h-7 text-xs font-semibold text-yellow-700 hover:text-yellow-800 dark:text-yellow-400 dark:hover:text-yellow-300", onClick: () => setPaywallOpen(true), children: "Upgrade" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-6 flex justify-center gap-4", children: [
        /* @__PURE__ */ jsx("button", { onClick: () => handleSwipe(current.p.id, "pass"), className: "flex h-16 w-16 items-center justify-center rounded-full border border-border bg-card shadow transition-transform hover:scale-105 active:scale-95", "aria-label": t("disc.pass"), children: /* @__PURE__ */ jsx(X, { className: "h-7 w-7 text-muted-foreground" }) }),
        /* @__PURE__ */ jsx("button", { onClick: () => handleSwipe(current.p.id, "like"), className: "flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-transform hover:scale-105 active:scale-95", "aria-label": t("disc.like"), children: /* @__PURE__ */ jsx(Heart, { className: "h-7 w-7", fill: "currentColor" }) })
      ] }),
      user && /* @__PURE__ */ jsx(PaywallModal, { open: paywallOpen, onOpenChange: setPaywallOpen, userId: user.id })
    ] })
  ] });
}
function FiltersPanel({
  filters,
  onChange,
  onReset,
  me
}) {
  const t = useT();
  const set = (k, v) => onChange({
    ...filters,
    [k]: v
  });
  return /* @__PURE__ */ jsxs(Card, { className: "mb-4 space-y-4 p-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { children: t("ob.city") }),
      /* @__PURE__ */ jsx(CityCombobox, { value: filters.city, onChange: (v) => set("city", v) })
    ] }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-2 flex items-center justify-between", children: [
        /* @__PURE__ */ jsx(Label, { children: t("disc.budget") }),
        /* @__PURE__ */ jsxs("span", { className: "text-sm font-medium", children: [
          filters.budget[0],
          " – ",
          filters.budget[1],
          " MAD"
        ] })
      ] }),
      /* @__PURE__ */ jsx(Slider, { min: 0, max: 5e3, step: 50, minStepsBetweenThumbs: 1, value: filters.budget, onValueChange: ([a, b]) => set("budget", [Math.min(a, b), Math.max(a, b)]) })
    ] }),
    me?.latitude && me?.longitude && /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-2 flex items-center justify-between", children: [
        /* @__PURE__ */ jsx(Label, { children: t("disc.maxDistance") }),
        /* @__PURE__ */ jsxs("span", { className: "text-sm font-medium", children: [
          filters.maxDistance,
          " km"
        ] })
      ] }),
      /* @__PURE__ */ jsx(Slider, { min: 1, max: 50, step: 1, value: [filters.maxDistance], onValueChange: ([val]) => set("maxDistance", val) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { children: t("disc.ageMin") }),
        /* @__PURE__ */ jsx(Input, { type: "number", min: 18, max: 99, value: filters.ageMin, onChange: (e) => set("ageMin", Math.max(18, Number(e.target.value) || 18)) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { children: t("disc.ageMax") }),
        /* @__PURE__ */ jsx(Input, { type: "number", min: 18, max: 99, value: filters.ageMax, onChange: (e) => set("ageMax", Math.min(99, Number(e.target.value) || 99)) })
      ] })
    ] }),
    /* @__PURE__ */ jsx("p", { className: "rounded-md border border-border bg-muted/40 p-2.5 text-xs text-muted-foreground", children: t("disc.sameGender") }),
    /* @__PURE__ */ jsx(ChipGroup, { label: t("disc.chip.smoking"), options: [["no", t("ob.smoking.no")], ["occasionally", t("ob.smoking.occasionally")], ["yes", t("ob.smoking.yes")]], selected: filters.smoking, onToggle: (v) => set("smoking", filters.smoking.includes(v) ? [] : [v]) }),
    /* @__PURE__ */ jsx(ChipGroup, { label: t("disc.chip.pets"), options: [["none", t("ob.pets.none")], ["have", t("ob.pets.have")], ["ok_with", t("ob.pets.ok_with")]], selected: filters.pets, onToggle: (v) => set("pets", filters.pets.includes(v) ? [] : [v]) }),
    /* @__PURE__ */ jsx(ChipGroup, { label: t("disc.chip.sleep"), options: [["early", t("ob.sleep.early")], ["flexible", t("ob.sleep.flexible")], ["late", t("ob.sleep.late")]], selected: filters.sleep, onToggle: (v) => set("sleep", filters.sleep.includes(v) ? [] : [v]) }),
    /* @__PURE__ */ jsx(ChipGroup, { label: t("disc.chip.social"), options: [["homebody", t("ob.social.homebody")], ["balanced", t("ob.social.balanced")], ["social", t("ob.social.social")]], selected: filters.social, onToggle: (v) => set("social", filters.social.includes(v) ? [] : [v]) }),
    /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "sm", onClick: onReset, children: t("disc.reset") }) })
  ] });
}
function ChipGroup({
  label,
  options,
  selected,
  onToggle
}) {
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx(Label, { className: "mb-1.5 block", children: label }),
    /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-1.5", children: options.map(([v, l]) => {
      const active = selected.includes(v);
      return /* @__PURE__ */ jsx("button", { type: "button", onClick: () => onToggle(v), className: cn("rounded-full border px-3 py-1 text-xs transition-colors", active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:bg-accent"), children: l }, v);
    }) })
  ] });
}
function CityCombobox({
  value,
  onChange
}) {
  const [open, setOpen] = useState(false);
  const t = useT();
  const {
    cities: dynamicCities
  } = useCities();
  return /* @__PURE__ */ jsxs(Popover, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { variant: "outline", role: "combobox", "aria-expanded": open, className: cn("w-full justify-between font-normal", !value && "text-muted-foreground"), children: [
      value || t("disc.anyCity"),
      /* @__PURE__ */ jsx(ChevronsUpDown, { className: "ms-2 h-4 w-4 shrink-0 opacity-50" })
    ] }) }),
    /* @__PURE__ */ jsx(PopoverContent, { className: "w-[--radix-popover-trigger-width] p-0", align: "start", children: /* @__PURE__ */ jsxs(Command, { children: [
      /* @__PURE__ */ jsx(CommandInput, { placeholder: t("ob.city.search") }),
      /* @__PURE__ */ jsxs(CommandList, { children: [
        /* @__PURE__ */ jsx(CommandEmpty, { children: t("ob.city.none") }),
        /* @__PURE__ */ jsxs(CommandGroup, { children: [
          /* @__PURE__ */ jsxs(CommandItem, { value: "__any", onSelect: () => {
            onChange("");
            setOpen(false);
          }, children: [
            /* @__PURE__ */ jsx(Check, { className: cn("me-2 h-4 w-4", value === "" ? "opacity-100" : "opacity-0") }),
            t("disc.anyCity")
          ] }),
          dynamicCities.map((c) => /* @__PURE__ */ jsxs(CommandItem, { value: c, onSelect: () => {
            onChange(c);
            setOpen(false);
          }, children: [
            /* @__PURE__ */ jsx(Check, { className: cn("me-2 h-4 w-4", value === c ? "opacity-100" : "opacity-0") }),
            c
          ] }, c))
        ] })
      ] })
    ] }) })
  ] });
}
function CandidateCard({
  profile,
  score: score2,
  distance,
  viewerGender
}) {
  const t = useT();
  const lifestyle = useMemo(() => {
    const tags = [];
    if (profile.smoking) tags.push(t(`tag.smoking.${profile.smoking}`));
    if (profile.sleep_schedule) tags.push(t(`tag.sleep.${profile.sleep_schedule}`));
    if (profile.social_level) tags.push(t(`tag.social.${profile.social_level}`));
    if (profile.pets) tags.push(t(`tag.pets.${profile.pets}`));
    const p = profile;
    [labelGuests(p.guests_frequency), labelAlcohol(p.alcohol_in_house), labelPrayer(p.prayer_at_home), labelFood(p.food_sharing)].forEach((l) => {
      if (l) tags.push(l);
    });
    const langs = profile.languages ?? [];
    if (langs.length) tags.push(t("tag.languages", {
      v: langs.slice(0, 3).join(", ")
    }));
    return tags;
  }, [profile, t]);
  const showPhoto = canSeePhoto(viewerGender, profile.gender);
  const scoreClass = score2 >= 80 ? "bg-emerald-500 text-white" : score2 >= 60 ? "bg-amber-500 text-white" : "bg-background/90 text-muted-foreground";
  return /* @__PURE__ */ jsxs(Card, { className: "overflow-hidden", children: [
    /* @__PURE__ */ jsxs("div", { className: "relative aspect-[3/4] w-full bg-gradient-to-br from-accent to-primary/30", children: [
      showPhoto && profile.photo_url ? /* @__PURE__ */ jsx("img", { src: profile.photo_url, alt: profile.display_name, className: "h-full w-full object-cover" }) : /* @__PURE__ */ jsx("div", { className: "flex h-full items-center justify-center text-6xl font-semibold text-primary-foreground", children: profile.display_name?.charAt(0)?.toUpperCase() }),
      /* @__PURE__ */ jsxs("div", { className: cn("absolute right-3 top-3 rounded-full px-3 py-1 text-xs font-semibold shadow backdrop-blur", scoreClass), children: [
        score2,
        "% ",
        t("disc.match")
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 text-white", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-baseline gap-2", children: [
          /* @__PURE__ */ jsxs("h2", { className: "text-2xl font-semibold flex items-center gap-1.5", children: [
            profile.display_name,
            profile.profile_contacts?.[0]?.phone_verified && /* @__PURE__ */ jsx(BadgeCheck, { className: "h-5 w-5 text-blue-400 fill-blue-400/20", "aria-label": "Verified" })
          ] }),
          profile.age && /* @__PURE__ */ jsx("span", { className: "text-lg", children: profile.age })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-1 flex flex-wrap items-center gap-3 text-sm opacity-90", children: [
          profile.city && /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsx(MapPin, { className: "h-3.5 w-3.5" }),
            " ",
            profile.city,
            profile.neighborhood ? `, ${profile.neighborhood}` : "",
            distance !== null && distance !== void 0 ? ` (${distance.toFixed(1)} km)` : ""
          ] }),
          profile.occupation && /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsx(Briefcase, { className: "h-3.5 w-3.5" }),
            " ",
            profile.occupation
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-3 p-4", children: [
      profile.budget_min != null && profile.budget_max != null && /* @__PURE__ */ jsxs("div", { className: "text-sm", children: [
        /* @__PURE__ */ jsx("span", { className: "font-medium", children: t("disc.budgetLabel") }),
        " ",
        /* @__PURE__ */ jsxs("span", { className: "text-muted-foreground", children: [
          profile.budget_min,
          " – ",
          profile.budget_max,
          " MAD",
          t("ob.budget.mo")
        ] })
      ] }),
      profile.bio && /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-foreground", children: profile.bio }),
      lifestyle.length > 0 && /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-1.5", children: lifestyle.map((tag) => /* @__PURE__ */ jsx(Badge, { variant: "secondary", className: "font-normal", children: tag }, tag)) }),
      /* @__PURE__ */ jsx(Link, { to: "/profile/$id", params: {
        id: profile.id
      }, className: "block text-center text-sm font-medium text-primary hover:underline", children: t("disc.viewFull") })
    ] })
  ] });
}
function Loader() {
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-[40vh] items-center justify-center", children: /* @__PURE__ */ jsx("div", { className: "h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" }) });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(Discover, {}) }) });
export {
  SplitComponent as component
};
