import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { Home, MapPin } from "lucide-react";
import { d as useT } from "./router-Ds3vjgN6.js";
function PlaceCard({ place }) {
  const cover = place.photos[0];
  const t = useT();
  return /* @__PURE__ */ jsxs(
    Link,
    {
      to: "/places/$id",
      params: { id: place.id },
      className: "group overflow-hidden rounded-xl border border-border bg-card transition-shadow hover:shadow-md",
      children: [
        /* @__PURE__ */ jsx("div", { className: "aspect-[4/3] w-full overflow-hidden bg-muted", children: cover ? /* @__PURE__ */ jsx(
          "img",
          {
            src: cover,
            alt: place.title,
            loading: "lazy",
            className: "h-full w-full object-cover transition-transform group-hover:scale-[1.02]"
          }
        ) : /* @__PURE__ */ jsxs("div", { className: "flex h-full w-full flex-col items-center justify-center gap-1 bg-gradient-to-br from-primary/10 via-accent/20 to-primary/5 text-primary/70", children: [
          /* @__PURE__ */ jsx(Home, { className: "h-8 w-8" }),
          /* @__PURE__ */ jsx("span", { className: "text-[10px] font-medium uppercase tracking-wide", children: t("place.photosComingSoon") ?? "Photos coming soon" })
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1 p-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-baseline justify-between gap-2", children: [
            /* @__PURE__ */ jsx("h3", { className: "truncate text-sm font-semibold", children: place.title }),
            /* @__PURE__ */ jsxs("span", { className: "shrink-0 text-sm font-semibold text-primary", children: [
              place.rent_monthly,
              " ",
              place.currency
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsx(MapPin, { className: "h-3 w-3" }),
            /* @__PURE__ */ jsxs("span", { className: "truncate", children: [
              place.neighborhood ? `${place.neighborhood}, ` : "",
              place.city
            ] }),
            /* @__PURE__ */ jsxs("span", { className: "ml-auto capitalize", children: [
              place.room_type,
              " room"
            ] })
          ] })
        ] })
      ]
    }
  );
}
export {
  PlaceCard as P
};
