import { jsx, jsxs } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import * as React from "react";
import { useRef, useState, useEffect } from "react";
import { u as useAuth, d as useT } from "./router-Ds3vjgN6.js";
import { s as supabase } from "./client-BAiQKvvS.js";
import { R as RequireAuth, A as AppLayout } from "./AppLayout-Rbb8c-qU.js";
import { C as Card } from "./card-RGlIzTYo.js";
import { B as Button } from "./button-DWfIo_Ug.js";
import { I as Input } from "./input-C0QjszdI.js";
import { L as Label } from "./label-JU3yqRBo.js";
import { T as Textarea } from "./textarea-DSyJ1nlY.js";
import * as SwitchPrimitives from "@radix-ui/react-switch";
import { c as cn } from "./utils-H80jjgLf.js";
import { Camera, Home, Bookmark } from "lucide-react";
import { toast } from "sonner";
import "@lovable.dev/email-js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-label";
import "clsx";
import "tailwind-merge";
const Switch = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  SwitchPrimitives.Root,
  {
    className: cn(
      "peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
      className
    ),
    ...props,
    ref,
    children: /* @__PURE__ */ jsx(
      SwitchPrimitives.Thumb,
      {
        className: cn(
          "pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0 rtl:data-[state=checked]:-translate-x-4"
        )
      }
    )
  }
));
Switch.displayName = SwitchPrimitives.Root.displayName;
function ProfilePage() {
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const nav = useNavigate();
  const fileRef = useRef(null);
  const t = useT();
  const [enrollData, setEnrollData] = useState(null);
  const [verificationCode, setVerificationCode] = useState("");
  const [verifyingMfa, setVerifyingMfa] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [updatingPassword, setUpdatingPassword] = useState(false);
  const updatePassword = async (e) => {
    e.preventDefault();
    if (newPassword.length < 6) return toast.error(t("rp.tooShort") || "Password too short");
    setUpdatingPassword(true);
    const {
      error
    } = await supabase.auth.updateUser({
      password: newPassword
    });
    setUpdatingPassword(false);
    if (error) return toast.error(error.message);
    toast.success("Password updated successfully");
    setNewPassword("");
  };
  const {
    data: mfaFactors,
    refetch: refetchMfa
  } = useQuery({
    queryKey: ["mfa-factors", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.auth.mfa.listFactors();
      if (error) throw error;
      return data;
    }
  });
  const activeTotp = mfaFactors?.totp?.[0];
  const startEnrollMfa = async () => {
    try {
      const {
        data,
        error
      } = await supabase.auth.mfa.enroll({
        factorType: "totp",
        issuer: "Roomies",
        friendlyName: user?.email || "Roomies Admin"
      });
      if (error) throw error;
      setEnrollData({
        id: data.id,
        qr_code: data.totp.qr_code,
        secret: data.totp.secret
      });
    } catch (e) {
      toast.error(e.message);
    }
  };
  const verifyMfaCode = async () => {
    if (!enrollData) return;
    setVerifyingMfa(true);
    try {
      const {
        data: challengeData,
        error: challengeError
      } = await supabase.auth.mfa.challenge({
        factorId: enrollData.id
      });
      if (challengeError) throw challengeError;
      const {
        error: verifyError
      } = await supabase.auth.mfa.verify({
        factorId: enrollData.id,
        challengeId: challengeData.id,
        code: verificationCode
      });
      if (verifyError) throw verifyError;
      toast.success("Two-factor authentication enrolled successfully!");
      setEnrollData(null);
      setVerificationCode("");
      refetchMfa();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setVerifyingMfa(false);
    }
  };
  const unenrollMfa = async (factorId) => {
    if (!confirm("Are you sure you want to disable 2FA? This will reduce your account security.")) return;
    try {
      const {
        error
      } = await supabase.auth.mfa.unenroll({
        factorId
      });
      if (error) throw error;
      toast.success("Two-factor authentication disabled.");
      refetchMfa();
    } catch (e) {
      toast.error(e.message);
    }
  };
  const {
    data: profile
  } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("profiles").select("*").eq("id", user.id).single();
      if (error) throw error;
      return data;
    }
  });
  const {
    data: contacts
  } = useQuery({
    queryKey: ["profile-contacts", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("profile_contacts").select("*").eq("user_id", user.id).maybeSingle();
      return data;
    }
  });
  const [bio, setBio] = useState("");
  const [contact, setContact] = useState("");
  const [name, setName] = useState("");
  useEffect(() => {
    if (profile) {
      setBio(profile.bio ?? "");
      setName(profile.display_name ?? "");
    }
  }, [profile]);
  useEffect(() => {
    if (contacts) setContact(contacts.contact_handle ?? "");
  }, [contacts]);
  const upload = async (file) => {
    if (!user) return;
    const ext = file.name.split(".").pop();
    const path = `${user.id}/avatar.${ext}`;
    const {
      error
    } = await supabase.storage.from("avatars").upload(path, file, {
      upsert: true
    });
    if (error) return toast.error(error.message);
    const {
      data
    } = supabase.storage.from("avatars").getPublicUrl(path);
    const url = `${data.publicUrl}?t=${Date.now()}`;
    await supabase.from("profiles").update({
      photo_url: url
    }).eq("id", user.id);
    qc.invalidateQueries({
      queryKey: ["profile"]
    });
    toast.success(t("profile.photoUpdated"));
  };
  const save = async () => {
    if (!user) return;
    const {
      error
    } = await supabase.from("profiles").update({
      display_name: name,
      bio
    }).eq("id", user.id);
    if (error) return toast.error(error.message);
    const {
      error: cErr
    } = await supabase.from("profile_contacts").upsert({
      user_id: user.id,
      contact_handle: contact
    }, {
      onConflict: "user_id"
    });
    if (cErr) return toast.error(cErr.message);
    toast.success(t("profile.saveChanges"));
    qc.invalidateQueries({
      queryKey: ["profile"]
    });
    qc.invalidateQueries({
      queryKey: ["profile-contacts"]
    });
  };
  if (!profile) return null;
  const [saving, setSaving] = useState(false);
  const onAboutSubmit = async (e) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    await save();
    setSaving(false);
  };
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-md space-y-5 p-5 sm:p-6", children: [
    /* @__PURE__ */ jsxs(Card, { className: "p-8 text-center", children: [
      /* @__PURE__ */ jsxs("button", { onClick: () => fileRef.current?.click(), "aria-label": t("profile.photoUpdated"), className: "group relative mx-auto block h-28 w-28", children: [
        /* @__PURE__ */ jsx("div", { className: "h-28 w-28 overflow-hidden rounded-full bg-gradient-to-br from-accent to-primary/40", children: profile.photo_url ? /* @__PURE__ */ jsx("img", { src: profile.photo_url, alt: profile.display_name, className: "h-full w-full object-cover" }) : /* @__PURE__ */ jsx("div", { className: "flex h-full items-center justify-center text-3xl font-semibold text-primary-foreground", children: profile.display_name?.charAt(0)?.toUpperCase() }) }),
        /* @__PURE__ */ jsx("div", { className: "absolute inset-0 flex items-center justify-center rounded-full bg-black/40 opacity-0 transition-opacity group-hover:opacity-100", children: /* @__PURE__ */ jsx(Camera, { className: "h-6 w-6 text-white" }) })
      ] }),
      /* @__PURE__ */ jsx("input", { ref: fileRef, type: "file", accept: "image/*", className: "hidden", onChange: (e) => e.target.files?.[0] && upload(e.target.files[0]) }),
      /* @__PURE__ */ jsx("h1", { className: "mt-4 text-xl font-semibold", children: profile.display_name }),
      /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground", children: [
        profile.city,
        profile.age ? ` · ${profile.age}` : ""
      ] })
    ] }),
    /* @__PURE__ */ jsx(Card, { className: "p-6", children: /* @__PURE__ */ jsxs("form", { onSubmit: onAboutSubmit, className: "space-y-4", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-base font-semibold", children: t("profile.about") }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "profile-name", children: t("profile.name") }),
        /* @__PURE__ */ jsx(Input, { id: "profile-name", autoFocus: true, value: name, onChange: (e) => setName(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "profile-bio", children: t("profile.bio") }),
        /* @__PURE__ */ jsx(Textarea, { id: "profile-bio", rows: 4, value: bio, onChange: (e) => setBio(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "profile-contact", children: t("profile.contactHandle") }),
        /* @__PURE__ */ jsx(Input, { id: "profile-contact", value: contact, onChange: (e) => setContact(e.target.value), placeholder: t("profile.contactHandle.ph") })
      ] }),
      /* @__PURE__ */ jsx(Button, { type: "submit", disabled: saving, className: "w-full", children: saving ? "Saving…" : t("profile.saveChanges") })
    ] }) }),
    /* @__PURE__ */ jsxs(Card, { className: "space-y-3 p-4", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-base font-semibold", children: t("profile.privacy") }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { className: "text-sm font-medium", children: t("profile.showPhone") }),
          /* @__PURE__ */ jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: contacts?.phone_verified ? t("profile.showPhone.on") : t("profile.showPhone.verifyFirst") })
        ] }),
        /* @__PURE__ */ jsx(Switch, { checked: !!contacts?.phone_visible_to_matches, disabled: !contacts?.phone_verified, onCheckedChange: async (checked) => {
          const {
            error
          } = await supabase.from("profile_contacts").update({
            phone_visible_to_matches: checked
          }).eq("user_id", user.id);
          if (error) return toast.error(error.message);
          qc.invalidateQueries({
            queryKey: ["profile-contacts"]
          });
          toast.success(checked ? t("profile.phoneVisible") : t("profile.phoneHidden"));
        } })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "space-y-3 p-4", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-base font-semibold", children: t("profile.situation") }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: t("profile.situation.sub") }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-3 gap-2", children: ["searching", "has_place", "both"].map((v) => /* @__PURE__ */ jsx("button", { onClick: async () => {
        const {
          error
        } = await supabase.from("profiles").update({
          user_intent: v
        }).eq("id", user.id);
        if (error) return toast.error(error.message);
        qc.invalidateQueries({
          queryKey: ["profile"]
        });
        qc.invalidateQueries({
          queryKey: ["me-intent"]
        });
      }, className: `rounded-md border px-2 py-2 text-xs ${profile.user_intent === v ? "border-primary bg-primary/10 text-primary" : "border-border"}`, children: v === "searching" ? t("profile.situation.searching") : v === "has_place" ? t("profile.situation.has") : t("profile.situation.both") }, v)) }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-2 pt-1", children: [
        /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", asChild: true, children: /* @__PURE__ */ jsxs(Link, { to: "/profile/listings", children: [
          /* @__PURE__ */ jsx(Home, { className: "me-1 h-4 w-4" }),
          " ",
          t("profile.myListings")
        ] }) }),
        /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", asChild: true, children: /* @__PURE__ */ jsxs(Link, { to: "/profile/saved", children: [
          /* @__PURE__ */ jsx(Bookmark, { className: "me-1 h-4 w-4" }),
          " ",
          t("profile.saved")
        ] }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "space-y-3 p-4", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-base font-semibold", children: t("profile.notifications") }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { className: "text-sm font-medium", children: t("profile.matchEmail") }),
          /* @__PURE__ */ jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: t("profile.matchEmail.desc") })
        ] }),
        /* @__PURE__ */ jsx(Switch, { checked: !!profile.email_match_notif, onCheckedChange: async (checked) => {
          const {
            error
          } = await supabase.from("profiles").update({
            email_match_notif: checked
          }).eq("id", user.id);
          if (error) return toast.error(error.message);
          qc.invalidateQueries({
            queryKey: ["profile"]
          });
        } })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { className: "text-sm font-medium", children: t("profile.messageEmail") }),
          /* @__PURE__ */ jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: t("profile.messageEmail.desc") })
        ] }),
        /* @__PURE__ */ jsx(Switch, { checked: !!profile.email_message_notif, onCheckedChange: async (checked) => {
          const {
            error
          } = await supabase.from("profiles").update({
            email_message_notif: checked
          }).eq("id", user.id);
          if (error) return toast.error(error.message);
          qc.invalidateQueries({
            queryKey: ["profile"]
          });
        } })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "space-y-3 p-4", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-base font-semibold", children: t("profile.mfa.title") }),
      activeTotp ? /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("p", { className: "text-sm font-medium text-emerald-600 dark:text-emerald-500", children: t("profile.mfa.enabled") }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: t("profile.mfa.desc.enabled") })
        ] }),
        /* @__PURE__ */ jsx(Button, { variant: "destructive", size: "sm", onClick: () => unenrollMfa(activeTotp.id), children: t("profile.mfa.disable") })
      ] }) : enrollData ? /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: t("profile.mfa.scanHint") }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-center bg-white p-3 rounded-lg border border-border", children: enrollData.qr_code && /* @__PURE__ */ jsx("img", { src: enrollData.qr_code, alt: "QR Code", className: "mx-auto h-40 w-40" }) }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs text-muted-foreground", children: t("profile.mfa.secret") }),
          /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsx(Input, { readOnly: true, value: enrollData.secret, className: "font-mono text-xs select-all bg-muted" }),
            /* @__PURE__ */ jsx(Button, { size: "sm", variant: "outline", type: "button", onClick: () => {
              navigator.clipboard.writeText(enrollData.secret);
              toast.success("Copied!");
            }, children: t("common.copy") })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "mfa-code", children: t("profile.mfa.code") }),
          /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsx(Input, { id: "mfa-code", placeholder: "000000", value: verificationCode, onChange: (e) => setVerificationCode(e.target.value.replace(/\D/g, "").slice(0, 6)), className: "text-center font-mono tracking-widest" }),
            /* @__PURE__ */ jsx(Button, { onClick: verifyMfaCode, disabled: verificationCode.length !== 6 || verifyingMfa, children: verifyingMfa ? t("profile.mfa.verifying") : t("profile.mfa.verify") })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "sm", className: "w-full text-xs text-muted-foreground", type: "button", onClick: () => setEnrollData(null), children: t("common.cancel") })
      ] }) : /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground mb-3", children: t("profile.mfa.desc") }),
        /* @__PURE__ */ jsx(Button, { variant: "outline", className: "w-full", onClick: startEnrollMfa, children: t("profile.mfa.enroll") })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "space-y-2 p-4", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-base font-semibold", children: t("profile.preferences") }),
      /* @__PURE__ */ jsx(Button, { variant: "outline", className: "w-full", onClick: () => nav({
        to: "/onboarding"
      }), children: t("profile.editLifestyle") })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "space-y-3 p-4 border-destructive/20", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-base font-semibold", children: "Change Password" }),
      /* @__PURE__ */ jsxs("form", { onSubmit: updatePassword, className: "space-y-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "new-password", children: "New Password" }),
          /* @__PURE__ */ jsx(Input, { id: "new-password", type: "password", value: newPassword, onChange: (e) => setNewPassword(e.target.value), placeholder: "Minimum 6 characters" })
        ] }),
        /* @__PURE__ */ jsx(Button, { type: "submit", variant: "secondary", disabled: updatingPassword || !newPassword, className: "w-full", children: updatingPassword ? "Updating..." : "Update Password" })
      ] })
    ] }),
    !contacts?.phone_verified && /* @__PURE__ */ jsxs(Card, { className: "space-y-2 border-primary/30 bg-primary/5 p-4 text-center", children: [
      /* @__PURE__ */ jsx("p", { className: "text-sm font-medium", children: t("profile.verifyTrust") }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: t("profile.verifyTrust.sub") }),
      /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => nav({
        to: "/verify"
      }), className: "mt-1", children: t("profile.verifyNow") })
    ] })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsx(RequireAuth, { children: /* @__PURE__ */ jsx(AppLayout, { children: /* @__PURE__ */ jsx(ProfilePage, {}) }) });
export {
  SplitComponent as component
};
