import { jsxs, jsx } from "react/jsx-runtime";
import * as React from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { c as cn } from "./utils-H80jjgLf.js";
import "./router-Ds3vjgN6.js";
const Dialog = DialogPrimitive.Root;
const DialogPortal = DialogPrimitive.Portal;
const DialogOverlay = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DialogPrimitive.Overlay,
  {
    ref,
    className: cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    ),
    ...props
  }
));
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName;
const DialogContent = React.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxs(DialogPortal, { children: [
  /* @__PURE__ */ jsx(DialogOverlay, {}),
  /* @__PURE__ */ jsxs(
    DialogPrimitive.Content,
    {
      ref,
      className: cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsxs(DialogPrimitive.Close, { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground", children: [
          /* @__PURE__ */ jsx(X, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Close" })
        ] })
      ]
    }
  )
] }));
DialogContent.displayName = DialogPrimitive.Content.displayName;
const DialogHeader = ({ className, ...props }) => /* @__PURE__ */ jsx("div", { className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className), ...props });
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({ className, ...props }) => /* @__PURE__ */ jsx(
  "div",
  {
    className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
    ...props
  }
);
DialogFooter.displayName = "DialogFooter";
const DialogTitle = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DialogPrimitive.Title,
  {
    ref,
    className: cn("text-lg font-semibold leading-none tracking-tight", className),
    ...props
  }
));
DialogTitle.displayName = DialogPrimitive.Title.displayName;
const DialogDescription = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DialogPrimitive.Description,
  {
    ref,
    className: cn("text-sm text-muted-foreground", className),
    ...props
  }
));
DialogDescription.displayName = DialogPrimitive.Description.displayName;
const LANGUAGE_OPTIONS = ["Darija", "Arabic", "French", "English", "Amazigh", "Spanish"];
const GUESTS_OPTIONS = [
  ["rarely", "Rarely"],
  ["occasionally", "Occasionally"],
  ["often", "Often"]
];
const ALCOHOL_OPTIONS = [
  ["not_ok", "Not OK"],
  ["discreet", "OK if discreet"],
  ["fine", "Fine"]
];
const PRAYER_OPTIONS = [
  ["yes", "Yes — I pray at home"],
  ["no", "I don't"],
  ["no_pref", "No preference"]
];
const FOOD_OPTIONS = [
  ["share_all", "Share everything"],
  ["share_some", "Share some"],
  ["separate", "Separate"]
];
const lookup = (opts, v) => v ? opts.find((o) => o[0] === v)?.[1] ?? v : null;
function labelGuests(v, t) {
  if (!v) return null;
  const l = lookup(GUESTS_OPTIONS, v);
  return l ? `Guests: ${l.toLowerCase()}` : null;
}
function labelAlcohol(v, t) {
  if (!v) return null;
  const l = lookup(ALCOHOL_OPTIONS, v);
  return l ? `Alcohol: ${l.toLowerCase()}` : null;
}
function labelPrayer(v, t) {
  if (v === "yes") return "Prays at home";
  if (v === "no") return "Doesn't pray at home";
  if (v === "no_pref") return "Prayer: no preference";
  return null;
}
function labelFood(v, t) {
  if (!v) return null;
  const l = lookup(FOOD_OPTIONS, v);
  return l ? `Food: ${l.toLowerCase()}` : null;
}
export {
  ALCOHOL_OPTIONS as A,
  Dialog as D,
  FOOD_OPTIONS as F,
  GUESTS_OPTIONS as G,
  LANGUAGE_OPTIONS as L,
  PRAYER_OPTIONS as P,
  DialogContent as a,
  DialogDescription as b,
  DialogFooter as c,
  DialogHeader as d,
  DialogTitle as e,
  labelFood as f,
  labelGuests as g,
  labelPrayer as h,
  labelAlcohol as l
};
